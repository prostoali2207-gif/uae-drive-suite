import { useCallback, useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import {
  ArrowLeft,
  Pencil,
  Save,
  X,
  Download,
  FileDown,
  Plus,
  CalendarPlus,
  CheckCircle2,
  FileText,
  Receipt,
  Clock,
  LayoutGrid,
  Wallet,
  AlertCircle,
  History,
  Trash2,
  Tag,
  Camera,
  Search,
  Filter,
  ExternalLink,
  CalendarDays,
  Route,
  CarFront,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  RotateCcw,
} from "lucide-react";
import { RecordPaymentModal, type PaymentAllocationLine } from "@/components/RecordPaymentModal";
import AddFeeInline, { type AddFeeInlineFee } from "@/components/contracts/AddFeeInline";
import { ReplaceVehicleModal } from "@/components/ReplaceVehicleModal";
import { VehicleHistorySheet } from "@/components/VehicleHistorySheet";
import SalikModal from "@/components/SalikModal";
import SalikDetailModal from "@/components/SalikDetailModal";
import { InspectionPhotosTab } from "@/components/inspection/InspectionPhotosTab";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import { findVehicleContractOverlap, formatContractOverlapMessage } from "@/lib/contractOverlap";
import { addDaysToDateInputValue, diffCalendarDays } from "@/lib/dateUtils";
import { generateContractPdf } from "@/lib/contractPdf";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

interface ContractRecord {
  id: string;
  owner_id: string;
  client_id: string;
  car_id: string;
  start_date: string;
  start_time: string;
  end_date: string;
  end_time: string;
  rate_type: string;
  rate_amount: number;
  total_amount: number;
  deposit_amount: number;
  initial_mileage: number;
  fuel_level: string;
  status: string;
  payment_status: string;
  created_at: string;
  notes?: string | null;
  clients: {
    full_name: string;
    phone: string;
    email: string | null;
    emirates_id: string | null;
    passport_number: string | null;
    nationality: string;
    client_type: string;
  } | null;
  cars: {
    plate: string;
    make: string;
    model: string;
    year: number;
  } | null;
}

interface AvailableCarRow {
  id: string;
  plate: string;
  make: string;
  model: string;
  year: number;
  status: string;
}

interface FineRow {
  id: string;
  fine_date: string;
  created_at?: string | null;
  fine_number?: string | null;
  fine_type: string;
  amount: number;
  status: string;
  source: string;
  notes?: string | null;
  car_id: string | null;
  cars: {
    plate: string;
    make: string;
    model: string;
  } | null;
}

interface SalikRow {
  id: string;
  charge_date: string;
  trip_time?: string | null;
  created_at?: string | null;
  transaction_id?: string | null;
  toll_gate?: string | null;
  direction?: string | null;
  trips: number;
  amount: number;
  status: string;
  notes?: string | null;
  car_id: string | null;
  cars: {
    plate: string;
    make: string;
    model: string;
  } | null;
}

interface PaymentRow {
  id: string;
  payment_date: string;
  amount: number;
  method: string;
  status: string;
  allocations?: unknown;
}

interface ContractDocumentRow {
  id: string;
  document_type: string;
  title: string;
  storage_bucket: string;
  storage_path: string;
  public_url: string | null;
  created_at: string;
}

type PaymentMethod = "Cash" | "Card" | "Transfer";
type InlinePaymentMethod = "Cash" | "Card" | "Bank Transfer" | "Cheque";

type InlinePaymentDraft = {
  amount: string;
  taxRate: string;
  method: InlinePaymentMethod;
};

interface ExtensionCandidateRow {
  id: string;
  start_date: string;
  start_time: string;
  end_date: string;
  end_time: string;
  status: string;
  clients: { full_name: string } | null;
}

type FeeCategory =
  | "delivery"
  | "pickup"
  | "fuel"
  | "extra_mileage"
  | "damage"
  | "detailing"
  | "other";

interface ContractFeeRow {
  id: string;
  category: FeeCategory;
  label: string;
  amount: number;
  note?: string | null;
  extension_start?: string | null;
  extension_end?: string | null;
  created_at?: string | null;
}

type AmountEditTarget =
  | { type: "rental"; label: string; amount: number }
  | { type: "payment"; label: string; amount: number; payment: PaymentRow }
  | { type: "fee"; label: string; amount: number; fee: ContractFeeRow };

type RentalPeriodEditTarget =
  | { type: "contract"; startDate: string; endDate: string; amount: number }
  | { type: "extension"; startDate: string; endDate: string; amount: number; fee: ContractFeeRow };

type ContractFinancialTotals = {
  charges: number;
  credits: number;
  outstanding: number;
  overdue: number;
};

type ChargeImportEvidence = {
  finesLastImportAt: string | null;
  salikLastImportAt: string | null;
};

type ContractPaymentAllocationLine = PaymentAllocationLine & {
  dueDate?: string | null;
  overdueImmediately?: boolean;
};

type DepositCloseAction =
  | "return_full"
  | "apply_to_balance"
  | "retain_partial"
  | "retain_full";

type DepositReconciliationInfo = {
  status: string;
  depositHeld: number;
  appliedToBalance: number;
  retained: number;
  pendingReturn: number;
  returnDue: string | null;
  reason: string | null;
  returnedAmount: number;
  returnedDate: string | null;
};

type LedgerEntry = {
  id: string;
  date: string;
  type: "Rental" | "Salik" | "Payment" | "Fine" | "Deposit";
  description: string;
  debit: number;
  credit: number;
  status: string;
};

type PdfImage = { dataUrl: string; w: number; h: number };

const cleanPdfValue = (value: unknown) => {
  if (typeof value !== "string") return "";
  const trimmed = value.trim();
  if (!trimmed || trimmed.toLowerCase() === "null" || trimmed.toLowerCase() === "undefined") return "";
  return trimmed;
};

const loadPdfImage = async (url: string): Promise<PdfImage | null> => {
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    const blob = await res.blob();
    return await new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = () => {
        const dataUrl = reader.result as string;
        const img = new Image();
        img.onload = () => resolve({ dataUrl, w: img.width, h: img.height });
        img.onerror = () => resolve(null);
        img.src = dataUrl;
      };
      reader.onerror = () => resolve(null);
      reader.readAsDataURL(blob);
    });
  } catch {
    return null;
  }
};

const statusBadgeClass = (status: string) => {
  switch (status) {
    case "Active":
      return "bg-tint-blue text-tint-blue-foreground border-tint-blue-foreground/20";
    case "Expiring Soon":
      return "bg-tint-amber text-tint-amber-foreground border-tint-amber-foreground/20";
    case "Overdue":
      return "bg-tint-rose text-tint-rose-foreground border-tint-rose-foreground/20";
    case "Completed":
      return "bg-tint-green text-tint-green-foreground border-tint-green-foreground/20";
    case "Cancelled":
      return "bg-muted text-muted-foreground border-border";
    default:
      return "bg-muted text-muted-foreground border-border";
  }
};

function formatDate(iso: string | null): string {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

function formatDubaiDateTime(isoString: string): string {
  if (!isoString) return "—";
  const date = new Date(isoString);
  return date.toLocaleString("en-GB", {
    timeZone: "Asia/Dubai",
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).replace(",", " ·");
}

function getChargeVerificationLabel(recordCount: number, lastImportAt: string | null): string {
  if (recordCount > 0) return `${recordCount} records`;
  if (lastImportAt) return `0 records - Last import: ${formatDate(lastImportAt)}`;
  return "Not imported yet";
}

function getContractDocumentLabel(documentType: string): string {
  switch (documentType) {
    case "original_rental_agreement":
      return "Original Rental Agreement";
    case "vehicle_replacement_addendum":
      return "Vehicle Replacement Addendum";
    case "final_return_checkin":
      return "Final Return Check-in";
    case "other":
      return "Other";
    default:
      return documentType
        .split("_")
        .filter(Boolean)
        .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
        .join(" ");
  }
}

function diffDays(start: string, end: string): number {
  return diffCalendarDays(start, end);
}

function formatTimeForDb(time: string | undefined): string {
  if (!time || time.trim() === "") return "12:00:00";
  const trimmed = time.trim();
  if (/^\d{2}:\d{2}$/.test(trimmed)) return `${trimmed}:00`;
  if (/^\d{2}:\d{2}:\d{2}$/.test(trimmed)) return trimmed;
  return "12:00:00";
}

function formatTimeDisplay(time: string | null | undefined): string {
  if (!time) return "12:00";
  const match = time.match(/^(\d{2}):(\d{2})/);
  return match ? `${match[1]}:${match[2]}` : "12:00";
}

function formatDateWithOptionalTime(date: string | null, time: string | null | undefined): string {
  const formattedDate = formatDate(date);
  const formattedTime = time?.trim().slice(0, 5);
  return formattedTime ? `${formattedDate} · ${formattedTime}` : formattedDate;
}

function getTomorrowDateInput(): string {
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const year = tomorrow.getFullYear();
  const month = String(tomorrow.getMonth() + 1).padStart(2, "0");
  const day = String(tomorrow.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function getTodayDateInput(): string {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, "0");
  const day = String(today.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function getCurrentDateTimeInput(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  const hours = String(now.getHours()).padStart(2, "0");
  const minutes = String(now.getMinutes()).padStart(2, "0");
  return `${year}-${month}-${day}T${hours}:${minutes}`;
}

function addDaysToDateInput(value: string, daysToAdd: number): string {
  return addDaysToDateInputValue(value, daysToAdd, getTodayDateInput());
}

const fmtAed = (n: number) => `AED ${Number(n).toLocaleString()}`;
const contractNumberLabel = (id: string) => `CTR-${id.slice(0, 8).toUpperCase()}`;

const RENTAL_EXTENSION_LABEL = "Rental Extension";
const RENTAL_EXTENSION_CATEGORY: FeeCategory = "other";
const DEPOSIT_RECONCILIATION_PREFIX = "[Deposit reconciliation]";
const DEPOSIT_RETURN_PREFIX = "[Deposit return]";

const buildRentalExtensionLabel = (periodStart: string, periodEnd: string) =>
  `${RENTAL_EXTENSION_LABEL}: ${periodStart} - ${periodEnd}`;

const parseRentalExtensionPeriod = (label: string) => {
  const match = label
    .trim()
    .match(/^Rental Extension:\s*(\d{4}-\d{2}-\d{2})\s*-\s*(\d{4}-\d{2}-\d{2})$/i);

  if (!match) return null;
  return { periodStart: match[1], periodEnd: match[2] };
};

const parseAedAmount = (value: string | null | undefined): number => {
  if (!value) return 0;
  const numeric = value.replace(/[^\d.-]/g, "");
  const parsed = Number(numeric);
  return Number.isFinite(parsed) ? parsed : 0;
};

const parseDepositNoteLine = (line: string): Record<string, string> | null => {
  if (!line.includes(DEPOSIT_RECONCILIATION_PREFIX) && !line.includes(DEPOSIT_RETURN_PREFIX)) {
    return null;
  }

  return Object.fromEntries(
    line
      .split("|")
      .map((part) => part.trim())
      .map((part) => {
        const clean = part
          .replace(DEPOSIT_RECONCILIATION_PREFIX, "")
          .replace(DEPOSIT_RETURN_PREFIX, "")
          .trim();
        const separator = clean.indexOf(":");
        if (separator === -1) return null;
        return [clean.slice(0, separator).trim(), clean.slice(separator + 1).trim()];
      })
      .filter((entry): entry is [string, string] => Boolean(entry)),
  );
};

const getDepositReconciliationInfo = (
  contract: Pick<ContractRecord, "deposit_amount" | "notes">,
): DepositReconciliationInfo => {
  const notes = contract.notes ?? "";
  const lines = notes.split("\n").map((line) => line.trim()).filter(Boolean);
  const latestReconciliation = [...lines]
    .reverse()
    .find((line) => line.includes(DEPOSIT_RECONCILIATION_PREFIX));
  const latestReturn = [...lines]
    .reverse()
    .find((line) => line.includes(DEPOSIT_RETURN_PREFIX));
  const reconciliation = latestReconciliation ? parseDepositNoteLine(latestReconciliation) : null;
  const returned = latestReturn ? parseDepositNoteLine(latestReturn) : null;

  const returnedAmount = parseAedAmount(returned?.["Returned amount"]);
  const returnedDate = returned?.["Returned date"] ?? null;

  if (returnedAmount > 0 || returnedDate) {
    return {
      status: "Returned",
      depositHeld: Number(contract.deposit_amount) || 0,
      appliedToBalance: parseAedAmount(reconciliation?.["Applied to balance"]),
      retained: parseAedAmount(reconciliation?.Retained),
      pendingReturn: 0,
      returnDue: reconciliation?.["Return due"] ?? null,
      reason: reconciliation?.Reason ?? null,
      returnedAmount,
      returnedDate,
    };
  }

  if (!reconciliation) {
    return {
      status: "Held",
      depositHeld: Number(contract.deposit_amount) || 0,
      appliedToBalance: 0,
      retained: 0,
      pendingReturn: Number(contract.deposit_amount) || 0,
      returnDue: null,
      reason: null,
      returnedAmount: 0,
      returnedDate: null,
    };
  }

  const pendingReturn = parseAedAmount(reconciliation["Pending return"]);
  const retained = parseAedAmount(reconciliation.Retained);
  const appliedToBalance = parseAedAmount(reconciliation["Applied to balance"]);
  let status = reconciliation.Status ?? "Held";

  if (retained > 0 && pendingReturn <= 0) {
    status = "Retained";
  } else if (appliedToBalance > 0 && pendingReturn <= 0 && retained <= 0) {
    status = "Applied / Used";
  } else if (pendingReturn > 0) {
    status = "Pending return";
  }

  return {
    status,
    depositHeld: parseAedAmount(reconciliation["Deposit held"]) || Number(contract.deposit_amount) || 0,
    appliedToBalance,
    retained,
    pendingReturn,
    returnDue: reconciliation["Return due"] ?? null,
    reason: reconciliation.Reason ?? null,
    returnedAmount: 0,
    returnedDate: null,
  };
};

const getRentalExtensionPeriodFromFee = (fee: ContractFeeRow) => {
  const parsedPeriod = parseRentalExtensionPeriod(fee.label);

  return {
    periodStart: fee.extension_start ?? parsedPeriod?.periodStart ?? null,
    periodEnd: fee.extension_end ?? parsedPeriod?.periodEnd ?? null,
  };
};

const isRentalExtensionFee = (fee: ContractFeeRow) => {
  if (fee.label.trim().toLowerCase().startsWith(`${RENTAL_EXTENSION_LABEL.toLowerCase()}:`)) {
    return true;
  }

  const period = getRentalExtensionPeriodFromFee(fee);
  return Boolean(period.periodStart && period.periodEnd);
};

const isStructuredRentalExtensionFee = (fee: ContractFeeRow) => Boolean(fee.extension_start);

const sortRentalExtensionFees = (fees: ContractFeeRow[]) =>
  [...fees].filter(isRentalExtensionFee).sort((a, b) => {
    const aPeriod = getRentalExtensionPeriodFromFee(a);
    const bPeriod = getRentalExtensionPeriodFromFee(b);
    const startCompare = String(aPeriod.periodStart).localeCompare(String(bPeriod.periodStart));
    if (startCompare !== 0) return startCompare;
    const endCompare = String(aPeriod.periodEnd).localeCompare(String(bPeriod.periodEnd));
    if (endCompare !== 0) return endCompare;
    return String(a.created_at ?? "").localeCompare(String(b.created_at ?? ""));
  });

type RentalHistoryPeriod = {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  amount: number;
  fee?: ContractFeeRow;
};

const buildRentalPeriods = (
  contract: Pick<ContractRecord, "id" | "start_date" | "end_date" | "total_amount">,
  extensionFees: ContractFeeRow[],
): RentalHistoryPeriod[] => {
  const sortedExtensions = [...extensionFees]
    .filter((fee) => fee.extension_start || fee.extension_end)
    .sort((a, b) => {
      const aStart = a.extension_start ?? a.extension_end ?? "";
      const bStart = b.extension_start ?? b.extension_end ?? "";
      const startCompare = aStart.localeCompare(bStart);
      if (startCompare !== 0) return startCompare;

      const endCompare = String(a.extension_end ?? "").localeCompare(String(b.extension_end ?? ""));
      if (endCompare !== 0) return endCompare;

      return String(a.created_at ?? "").localeCompare(String(b.created_at ?? ""));
    });

  const originalEndDate = sortedExtensions[0]?.extension_start ?? contract.end_date;
  const periods: RentalHistoryPeriod[] = [
    {
      id: "base-rental",
      name: "Original Contract",
      startDate: contract.start_date,
      endDate: originalEndDate,
      amount: Number(contract.total_amount),
    },
  ];

  sortedExtensions.forEach((fee, index) => {
    const previousPeriod = periods[periods.length - 1];
    const nextExtension = sortedExtensions[index + 1];
    const startDate = fee.extension_start ?? previousPeriod.endDate;
    const endDate = fee.extension_end ?? nextExtension?.extension_start ?? contract.end_date;

    periods.push({
      id: fee.id,
      name: `Extension #${index + 1}`,
      startDate,
      endDate,
      amount: Number(fee.amount),
      fee,
    });
  });

  return periods;
};

const getLatestRentalPeriodEnd = (contract: Pick<ContractRecord, "end_date">, fees: ContractFeeRow[]) => {
  const sortedExtensionEnds = [...fees]
    .map((fee) => getRentalExtensionPeriodFromFee(fee).periodEnd)
    .filter((endDate): endDate is string => Boolean(endDate))
    .sort((a, b) => a.localeCompare(b));
  return sortedExtensionEnds[sortedExtensionEnds.length - 1] ?? contract.end_date;
};

const formatRentalExtensionPeriod = (fee: ContractFeeRow) => {
  if (fee.extension_start && fee.extension_end) {
    return `${formatDate(fee.extension_start)} - ${formatDate(fee.extension_end)} - ${diffDays(fee.extension_start, fee.extension_end)} days`;
  }

  const period = parseRentalExtensionPeriod(fee.label);
  if (!period) return "Rental extension";
  return `${formatDate(period.periodStart)} - ${formatDate(period.periodEnd)} - ${diffDays(period.periodStart, period.periodEnd)} days`;
};

type SavedPaymentAllocations = {
  rental?: number;
  fines?: number;
  salik?: number;
  fees?: number;
  lines?: Record<string, number>;
};

type PaymentAllocationDisplayLine = {
  id: string;
  category: "rental" | "fines" | "salik" | "fees";
  label: string;
  amount: number;
};

type ExpandedPaymentAllocationRow = {
  id: string;
  label: string;
  amount: number;
};

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

const readSavedPaymentAllocations = (value: unknown): SavedPaymentAllocations | null => {
  if (!isRecord(value)) return null;

  const linesValue = value.lines;
  const lines = isRecord(linesValue)
    ? Object.fromEntries(
        Object.entries(linesValue)
          .map(([key, amount]) => [key, Number(amount)])
          .filter(([, amount]) => Number.isFinite(amount) && amount > 0),
      )
    : undefined;

  return {
    rental: Number(value.rental) || undefined,
    fines: Number(value.fines) || undefined,
    salik: Number(value.salik) || undefined,
    fees: Number(value.fees) || undefined,
    lines,
  };
};

const getPaymentLineAllocationAmount = (payment: PaymentRow, lineId: string): number => {
  const rawAllocations = isRecord(payment.allocations) ? payment.allocations : null;
  const savedAllocations = readSavedPaymentAllocations(payment.allocations);
  const lineAmount = Number(savedAllocations?.lines?.[lineId] ?? 0);
  const directAmount = rawAllocations ? Number(rawAllocations[lineId] ?? 0) : 0;
  const amount = lineAmount > 0 ? lineAmount : directAmount;

  return Number.isFinite(amount) && amount > 0 ? amount : 0;
};

const sumPaymentLineAllocations = (payments: PaymentRow[], lineId: string): number =>
  payments.reduce((sum, payment) => sum + getPaymentLineAllocationAmount(payment, lineId), 0);

const PAYMENT_ALLOCATION_CATEGORY_LABELS: Record<PaymentAllocationDisplayLine["category"], string> = {
  rental: "Rental",
  fees: "Other Fees",
  fines: "Traffic Fines",
  salik: "Salik",
};

const buildPaymentAllocationDisplay = (
  payment: PaymentRow,
  lineLookup: Map<string, Pick<PaymentAllocationDisplayLine, "category" | "label">>,
): PaymentAllocationDisplayLine[] | null => {
  const savedAllocations = readSavedPaymentAllocations(payment.allocations);
  if (!savedAllocations) return null;

  const lines: PaymentAllocationDisplayLine[] = [];
  let hasUnresolvedLine = false;

  if (savedAllocations.lines && Object.keys(savedAllocations.lines).length > 0) {
    Object.entries(savedAllocations.lines).forEach(([lineId, value]) => {
      const amount = Number(value);
      if (!Number.isFinite(amount) || amount <= 0) return;

      const knownLine = lineLookup.get(lineId);
      if (!knownLine) {
        hasUnresolvedLine = true;
        return;
      }

      lines.push({
        id: lineId,
        category: knownLine.category,
        label: knownLine.label,
        amount,
      });
    });
    if (hasUnresolvedLine) return null;
  } else {
    (["rental", "fees", "fines", "salik"] as const).forEach((category) => {
      const amount = Number(savedAllocations[category] ?? 0);
      if (!Number.isFinite(amount) || amount <= 0) return;
      lines.push({
        id: category,
        category,
        label: PAYMENT_ALLOCATION_CATEGORY_LABELS[category],
        amount,
      });
    });
  }

  if (lines.length === 0) return null;

  const allocationTotal = lines.reduce((sum, line) => sum + line.amount, 0);
  if (Math.abs(allocationTotal - Number(payment.amount)) > 0.01) return null;

  return lines;
};

const PaymentAllocationDetails = ({
  payment,
  lineLookup,
}: {
  payment: PaymentRow;
  lineLookup: Map<string, Pick<PaymentAllocationDisplayLine, "category" | "label">>;
}) => {
  const allocationLines = buildPaymentAllocationDisplay(payment, lineLookup);

  return (
    <div className="ml-10 mt-1 rounded-lg bg-zinc-900 p-2 text-xs">
      <div className="mb-1 font-medium text-muted-foreground">Applied to:</div>
      {allocationLines ? (
        <div className="grid gap-1">
          {allocationLines.map((line) => (
            <div key={line.id} className="flex items-center justify-between gap-3">
              <span className="min-w-0 truncate text-foreground/85">{line.label}</span>
              <span className="shrink-0 font-mono font-semibold tabular-nums text-foreground">
                {fmtAed(line.amount)}
              </span>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-muted-foreground">Allocation details not available</div>
      )}
    </div>
  );
};

const buildExpandedPaymentAllocationRows = (
  payment: PaymentRow,
  contractFees: ContractFeeRow[],
  fines: FineRow[],
): ExpandedPaymentAllocationRow[] => {
  const savedAllocations = readSavedPaymentAllocations(payment.allocations);
  const entries = savedAllocations?.lines
    ? Object.entries(savedAllocations.lines)
        .map(([id, amount]) => ({ id, amount: Number(amount) }))
        .filter((line) => Number.isFinite(line.amount) && line.amount > 0)
    : [];

  if (entries.length === 0) {
    return [{ id: `general-${payment.id}`, label: "General payment", amount: Number(payment.amount) || 0 }];
  }

  const feeLabels = new Map<string, string>();
  contractFees.forEach((fee) => {
    feeLabels.set(`fee-${fee.id}`, fee.label || "Fee");
  });
  sortRentalExtensionFees(contractFees).forEach((fee, index) => {
    feeLabels.set(`fee-${fee.id}`, `Extension #${index + 1}`);
  });

  const rows: ExpandedPaymentAllocationRow[] = [];
  let salikRowIndex = -1;

  entries.forEach((line) => {
    let label = "General payment";
    if (line.id.startsWith("fee-")) label = feeLabels.get(line.id) || "Fee";
    if (line.id.startsWith("rental-")) label = "Original Contract";
    if (line.id.startsWith("fine-")) {
      const fineId = line.id.slice("fine-".length);
      const fine = fines.find((item) => item.id === fineId);
      label = `Traffic Fine ${fine?.fine_number || "No number"}`;
    }

    if (line.id.startsWith("salik-")) {
      if (salikRowIndex === -1) {
        salikRowIndex = rows.length;
        rows.push({ id: `salik-${payment.id}`, label: "Salik", amount: line.amount });
      } else {
        rows[salikRowIndex] = {
          ...rows[salikRowIndex],
          amount: rows[salikRowIndex].amount + line.amount,
        };
      }
      return;
    }

    rows.push({ ...line, label });
  });

  return rows;
};

const FEE_CATEGORIES: { value: FeeCategory; label: string; defaultLabel: string }[] = [
  { value: "delivery", label: "Delivery", defaultLabel: "Delivery" },
  { value: "pickup", label: "Pickup", defaultLabel: "Pickup" },
  { value: "fuel", label: "Fuel", defaultLabel: "Fuel" },
  { value: "extra_mileage", label: "Extra Mileage", defaultLabel: "Extra Mileage" },
  { value: "damage", label: "Damage", defaultLabel: "Damage" },
  { value: "detailing", label: "Detailing", defaultLabel: "Detailing" },
  { value: "other", label: "Other", defaultLabel: "" },
];

const ADD_FEE_CATEGORY_TO_DB: Record<AddFeeInlineFee["category"], FeeCategory> = {
  Delivery: "delivery",
  Pickup: "pickup",
  Fuel: "fuel",
  "Extra Mileage": "extra_mileage",
  Damage: "damage",
  Detailing: "detailing",
  Other: "other",
};

const Field = ({ label, value }: { label: string; value?: string | number | null }) => (
  <div className="flex flex-col gap-0.5 py-1.5">
    <span className="text-[11px] uppercase tracking-wide text-muted-foreground/80">{label}</span>
    <span className="text-sm font-medium text-foreground">
      {value || value === 0 ? value : "—"}
    </span>
  </div>
);

const Panel = ({
  title,
  icon: Icon,
  action,
  children,
  className,
}: {
  title: string;
  icon?: React.ComponentType<{ className?: string }>;
  action?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}) => (
  <section className={cn("min-w-0 rounded-lg border border-border bg-card", className)}>
    <header className="flex min-w-0 items-center justify-between gap-3 border-b border-border px-4 py-2.5">
      <div className="flex min-w-0 items-center gap-2">
        {Icon && <Icon className="h-3.5 w-3.5 text-muted-foreground" />}
        <h3 className="min-w-0 truncate text-xs font-semibold uppercase tracking-wide text-foreground">{title}</h3>
      </div>
      {action}
    </header>
    <div className="min-w-0 px-4 py-3">{children}</div>
  </section>
);

const EmptyState = ({
  icon: Icon,
  title,
  description,
  action,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
  action?: React.ReactNode;
}) => (
  <div className="flex flex-col items-center justify-center gap-2 py-10 text-center">
    <div className="rounded-full bg-muted p-2.5">
      <Icon className="h-4 w-4 text-muted-foreground" />
    </div>
    <p className="text-sm font-medium text-foreground">{title}</p>
    <p className="text-xs text-muted-foreground">{description}</p>
    {action}
  </div>
);

// ---------- Financials Accordion ----------

const STATUS_STYLES: Record<string, { dot: string; bg: string; text: string }> = {
  Paid: { dot: "bg-tint-green-foreground", bg: "bg-tint-green", text: "text-tint-green-foreground" },
  "Expiring Soon": { dot: "bg-tint-amber-foreground", bg: "bg-tint-amber", text: "text-tint-amber-foreground" },
  Upcoming: { dot: "bg-tint-blue-foreground", bg: "bg-tint-blue", text: "text-tint-blue-foreground" },
  "Charged to Client": { dot: "bg-tint-violet-foreground", bg: "bg-tint-violet", text: "text-tint-violet-foreground" },
  Unpaid: { dot: "bg-tint-rose-foreground", bg: "bg-tint-rose", text: "text-tint-rose-foreground" },
  Disputed: { dot: "bg-tint-amber-foreground", bg: "bg-tint-amber", text: "text-tint-amber-foreground" },
  Active: { dot: "bg-tint-blue-foreground", bg: "bg-tint-blue", text: "text-tint-blue-foreground" },
  Held: { dot: "bg-tint-violet-foreground", bg: "bg-tint-violet", text: "text-tint-violet-foreground" },
  Completed: { dot: "bg-tint-green-foreground", bg: "bg-tint-green", text: "text-tint-green-foreground" },
  Closed: { dot: "bg-muted-foreground", bg: "bg-muted", text: "text-muted-foreground" },
};

type AccentKey = "blue" | "red" | "cyan" | "purple";

const ACCENT_VAR: Record<AccentKey, string> = {
  blue: "hsl(var(--tint-blue-foreground))",
  red: "hsl(var(--tint-rose-foreground))",
  cyan: "hsl(var(--tint-blue-foreground))",
  purple: "hsl(var(--tint-violet-foreground))",
};

type AccordionRowProps = {
  label: string;
  count: number;
  total: number;
  accent: AccentKey;
  totalClass?: string;
  children: React.ReactNode;
};

const AccordionRow = ({
  label,
  count,
  total,
  accent,
  totalClass,
  children,
}: AccordionRowProps) => {
  const [open, setOpen] = useState(false);
  const accentColor = ACCENT_VAR[accent];
  return (
    <div
      className={cn(
        "overflow-hidden rounded-md border bg-card transition-colors",
        open && "bg-muted/40",
      )}
      style={{ borderColor: open ? accentColor : "hsl(var(--border))" }}
    >
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-stretch gap-0 text-left"
      >
        <span className="w-[3px] shrink-0" style={{ backgroundColor: accentColor }} aria-hidden />
        <div className="flex flex-1 items-center justify-between gap-3 px-3 py-2.5">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-foreground">
              {label}
            </span>
            <span className="rounded-full bg-muted px-1.5 py-0.5 text-[10px] font-medium tabular-nums text-muted-foreground">
              {count}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className={cn("text-sm font-bold tabular-nums", totalClass ?? "text-foreground")}>
              {fmtAed(total)}
            </span>
            <ChevronDown
              className={cn(
                "h-4 w-4 text-muted-foreground transition-transform duration-200",
                open && "rotate-180",
              )}
            />
          </div>
        </div>
      </button>
      <div
        className={cn(
          "grid transition-all duration-200 ease-out",
          open ? "grid-rows-[1fr]" : "grid-rows-[0fr]",
        )}
      >
        <div className="overflow-hidden">
          <div className="max-h-[280px] overflow-y-auto bg-background/40 [scrollbar-width:thin] [&::-webkit-scrollbar]:w-1.5 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-border">
            {count === 0 ? (
              <div className="px-4 py-6 text-center text-xs text-muted-foreground">No entries.</div>
            ) : (
              children
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const StatusPill = ({ status }: { status: string }) => {
  const s = STATUS_STYLES[status] ?? {
    dot: "bg-muted-foreground",
    bg: "bg-muted",
    text: "text-muted-foreground",
  };
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center gap-1.5 rounded-full px-2 py-0.5 text-[10px] font-medium",
        s.bg,
        s.text,
      )}
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", s.dot)} />
      {status}
    </span>
  );
};

const EntryRow = ({ children, className }: { children: React.ReactNode; className?: string }) => (
  <div className={cn("flex items-center gap-3 border-b border-border/40 px-3 py-2.5 last:border-b-0", className)}>
    {children}
  </div>
);

type FinancialsAccordionProps = {
  contract: ContractRecord;
  days: number;
  payments: PaymentRow[];
  fines: FineRow[];
  salik: SalikRow[];
  contractFees: ContractFeeRow[];
  totals: ContractFinancialTotals;
  onEditRentalAmount: () => void;
  onEditPaymentAmount: (payment: PaymentRow) => void;
  onEditFeeAmount: (fee: ContractFeeRow) => void;
  onDeletePayment: (payment: PaymentRow) => void;
  onDeleteFee: (fee: ContractFeeRow) => void;
  onUpdateFineNote: (id: string, note: string) => void;
  onUpdateSalikNote: (id: string, note: string) => void;
};

const FinancialsAccordion = ({
  contract,
  days,
  payments,
  fines,
  salik,
  contractFees,
  totals,
  onEditRentalAmount,
  onEditPaymentAmount,
  onEditFeeAmount,
  onDeletePayment,
  onDeleteFee,
  onUpdateFineNote,
  onUpdateSalikNote,
}: FinancialsAccordionProps) => {
  const rentalFees = sortRentalExtensionFees(contractFees);
  const latestRentalFeeId = rentalFees.at(-1)?.id;
  const originalRentalLabel = `${formatDate(contract.start_date)} -> ${formatDate(contract.end_date)}`;
  const rentalTotal = Number(contract.total_amount);
  const paymentsTotal = payments.reduce((s, p) => s + Number(p.amount), 0);
  const finesTotal = fines.reduce((s, f) => s + Number(f.amount), 0);
  const salikTotal = salik.reduce((s, x) => s + Number(x.amount), 0);
  const otherFees = contractFees.filter((fee) => !isRentalExtensionFee(fee));
  const otherTotal = otherFees.reduce((s, o) => s + o.amount, 0);

  const [editingFineId, setEditingFineId] = useState<string | null>(null);
  const [fineNoteDraft, setFineNoteDraft] = useState("");
  const [savingFineNote, setSavingFineNote] = useState(false);
  const [fineMenuState, setFineMenuState] = useState<{
    id: string;
    top: number;
    right: number;
  } | null>(null);

  const openFineMenu = (
    e: React.MouseEvent<HTMLButtonElement>,
    fineId: string,
  ) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setFineMenuState({
      id: fineId,
      top: rect.bottom + 4,
      right: window.innerWidth - rect.right,
    });
  };

  const [editingSalikId, setEditingSalikId] = useState<string | null>(null);
  const [salikNoteDraft, setSalikNoteDraft] = useState("");
  const [savingSalikNote, setSavingSalikNote] = useState(false);
  const [salikMenuState, setSalikMenuState] = useState<{
    id: string;
    top: number;
    right: number;
  } | null>(null);

  const openSalikMenu = (
    e: React.MouseEvent<HTMLButtonElement>,
    salikId: string,
  ) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setSalikMenuState({
      id: salikId,
      top: rect.bottom + 4,
      right: window.innerWidth - rect.right,
    });
  };

  const [showFinesModal, setShowFinesModal] = useState(false);
  const [showSalikModal, setShowSalikModal] = useState(false);

  const FINES_PAGE_SIZE = 10;
  const SALIK_PAGE_SIZE = 20;
  const [finePage, setFinePage] = useState(0);
  const [salikPage, setSalikPage] = useState(0);
  const finesTotalPages = Math.max(1, Math.ceil(fines.length / FINES_PAGE_SIZE));
  const salikTotalPages = Math.max(1, Math.ceil(salik.length / SALIK_PAGE_SIZE));
  const finesPageItems = fines.slice(finePage * FINES_PAGE_SIZE, (finePage + 1) * FINES_PAGE_SIZE);
  const salikPageItems = salik.slice(salikPage * SALIK_PAGE_SIZE, (salikPage + 1) * SALIK_PAGE_SIZE);

  return (
    <>
      {fineMenuState !== null && (
        <>
          <div
            className="fixed inset-0 z-[100]"
            onClick={() => setFineMenuState(null)}
          />
          <div
            className="fixed z-[101] min-w-[120px] rounded-md border border-border bg-card py-1 shadow-md"
            style={{ top: fineMenuState.top, right: fineMenuState.right }}
          >
            <button
              type="button"
              className="w-full px-3 py-1.5 text-left text-xs hover:bg-muted"
              onClick={() => {
                const fine = fines.find((f) => f.id === fineMenuState.id);
                setEditingFineId(fineMenuState.id);
                setFineNoteDraft(fine?.notes ?? "");
                setFineMenuState(null);
              }}
            >
              Add note
            </button>
          </div>
        </>
      )}

      {salikMenuState !== null && (
        <>
          <div
            className="fixed inset-0 z-[100]"
            onClick={() => setSalikMenuState(null)}
          />
          <div
            className="fixed z-[101] min-w-[120px] rounded-md border border-border bg-card py-1 shadow-md"
            style={{ top: salikMenuState.top, right: salikMenuState.right }}
          >
            <button
              type="button"
              className="w-full px-3 py-1.5 text-left text-xs hover:bg-muted"
              onClick={() => {
                const entry = salik.find((s) => s.id === salikMenuState.id);
                setEditingSalikId(salikMenuState.id);
                setSalikNoteDraft(entry?.notes ?? "");
                setSalikMenuState(null);
              }}
            >
              Add note
            </button>
          </div>
        </>
      )}

    <div className="space-y-2">
      <AccordionRow label="Rental" count={1 + rentalFees.length} total={rentalTotal} accent="blue">
        <EntryRow>
          <span className="flex-1 truncate font-sans text-xs text-foreground/90">
            {originalRentalLabel}
          </span>
          <StatusPill status={rentalFees.length > 0 ? "Closed" : "Active"} />
          <span className="w-24 text-right font-mono text-sm font-bold tabular-nums text-foreground">
            {fmtAed(Number(contract.total_amount))}
          </span>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            aria-label="Edit rental amount"
            className="h-11 w-11 shrink-0 text-muted-foreground hover:bg-transparent hover:text-foreground"
            onClick={onEditRentalAmount}
          >
            <Pencil className="h-4 w-4" />
          </Button>
        </EntryRow>
        {rentalFees.map((fee) => (
          <EntryRow key={fee.id}>
            <div className="flex min-w-0 flex-1 flex-col gap-0.5">
              <span className="truncate font-sans text-xs text-foreground/90">
                {RENTAL_EXTENSION_LABEL}
              </span>
              <span className="font-mono text-[11px] text-muted-foreground">
                {formatRentalExtensionPeriod(fee)}
              </span>
            </div>
            <StatusPill status={fee.id === latestRentalFeeId ? "Active" : "Closed"} />
            <span className="w-24 text-right font-mono text-sm font-bold tabular-nums text-foreground">
              {fmtAed(Number(fee.amount))}
            </span>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              aria-label="Edit extension"
              className="h-11 w-11 shrink-0 text-muted-foreground hover:bg-transparent hover:text-foreground"
              onClick={() => onEditFeeAmount(fee)}
            >
              <Pencil className="h-4 w-4" />
            </Button>
          </EntryRow>
        ))}
      </AccordionRow>

      <AccordionRow
        label="Payments"
        count={payments.length}
        total={paymentsTotal}
        accent="cyan"
        totalClass="font-mono text-tint-green-foreground"
      >
        {payments.map((payment) => (
          <EntryRow key={payment.id}>
            <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-muted">
              <Receipt className="h-3.5 w-3.5 text-muted-foreground" />
            </span>
            <div className="flex min-w-0 flex-1 flex-col gap-0.5">
              <span className="truncate text-xs text-foreground/90">
                {payment.method}
              </span>
              <span className="text-[11px] text-muted-foreground">
                {formatDate(payment.payment_date)}
              </span>
            </div>
            <StatusPill status={payment.status} />
            <span className="w-24 text-right font-mono text-sm font-bold tabular-nums text-tint-green-foreground">
              {fmtAed(Number(payment.amount))}
            </span>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              aria-label="Edit payment amount"
              className="h-11 w-11 shrink-0 text-muted-foreground hover:bg-transparent hover:text-foreground"
              onClick={() => onEditPaymentAmount(payment)}
            >
              <Pencil className="h-4 w-4" />
            </Button>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              aria-label="Delete payment"
              className="h-11 w-11 shrink-0 text-muted-foreground hover:bg-transparent hover:text-destructive"
              onClick={() => onDeletePayment(payment)}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </EntryRow>
        ))}
      </AccordionRow>

      {/* Traffic Fines — summary row */}
      <div className="flex w-full items-center justify-between rounded-md border border-border bg-card px-4 py-2.5">
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-foreground">Traffic Fines</span>
          <span className="rounded-full bg-muted px-1.5 py-0.5 text-[10px] font-medium tabular-nums text-muted-foreground">
            {fines.length}
          </span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm font-bold tabular-nums text-tint-rose-foreground">{fmtAed(finesTotal)}</span>
          <button
            type="button"
            onClick={() => setShowFinesModal(true)}
            className="text-[11px] font-medium text-tint-blue-foreground hover:underline"
          >
            View All →
          </button>
        </div>
      </div>

      {/* Salik — summary row */}
      <div className="flex w-full items-center justify-between rounded-md border border-border bg-card px-4 py-2.5">
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-foreground">Salik</span>
          <span className="rounded-full bg-muted px-1.5 py-0.5 text-[10px] font-medium tabular-nums text-muted-foreground">
            {salik.length}
          </span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm font-bold tabular-nums text-foreground">{fmtAed(salikTotal)}</span>
          <button
            type="button"
            onClick={() => setShowSalikModal(true)}
            className="text-[11px] font-medium text-tint-blue-foreground hover:underline"
          >
            View All →
          </button>
        </div>
      </div>

      <AccordionRow
        label="Other Fees"
        count={otherFees.length}
        total={otherTotal}
        accent="purple"
        totalClass="font-mono text-foreground"
      >
        {otherFees.map((o) => (
          <EntryRow key={o.id}>
            <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-muted">
              <Tag className="h-3.5 w-3.5 text-muted-foreground" />
            </span>
            <span className="flex-1 truncate text-xs text-foreground/90">{o.label}</span>
            <span className="w-24 text-right font-mono text-sm font-bold tabular-nums text-foreground">
              {fmtAed(o.amount)}
            </span>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              aria-label="Edit fee amount"
              className="h-11 w-11 shrink-0 text-muted-foreground hover:bg-transparent hover:text-foreground"
              onClick={() => onEditFeeAmount(o)}
            >
              <Pencil className="h-4 w-4" />
            </Button>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              aria-label="Delete fee"
              className="h-11 w-11 shrink-0 text-muted-foreground hover:bg-transparent hover:text-destructive"
              onClick={() => onDeleteFee(o)}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </EntryRow>
        ))}
      </AccordionRow>


    </div>

      <ContractFinesSheet
        contract={contract}
        fines={fines}
        payments={payments}
        open={showFinesModal}
        onOpenChange={setShowFinesModal}
        onPaymentRecorded={() => undefined}
      />
      <SalikModal contractId={contract.id} open={showSalikModal} onOpenChange={setShowSalikModal} />

    </>
  );
};

type FinancialsPanelProps = {
  contract: ContractRecord;
  days: number;
  payments: PaymentRow[];
  fines: FineRow[];
  salik: SalikRow[];
  chargeImportEvidence: ChargeImportEvidence;
  contractFees: ContractFeeRow[];
  unpaidAllocationLines: ContractPaymentAllocationLine[];
  totals: ContractFinancialTotals;
  addFeeInlineOpen: boolean;
  savingFee: boolean;
  onAddFee: () => void;
  onCancelAddFee: () => void;
  onSaveFee: (fee: AddFeeInlineFee) => void;
  onAddPayment: () => void;
  onEditRentalPeriod: (fee?: ContractFeeRow) => void;
  onEditPaymentAmount: (payment: PaymentRow) => void;
  onEditFeeAmount: (fee: ContractFeeRow) => void;
  onDeletePayment: (payment: PaymentRow) => void;
  onDeleteFee: (fee: ContractFeeRow) => void;
  onMarkDepositReturned: (amount: number) => void;
  onMarkDepositPartiallyReturned: (amount: number) => void;
  onMarkDepositForfeited: () => void;
  markingDepositReturned: boolean;
  onInlinePaymentRecorded: () => void;
};

const FinancialBadge = ({ status }: { status: string }) => {
  const key = status.toLowerCase();
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center rounded-full px-2 py-0.5 text-[10px] font-medium",
        key === "pending return" && "bg-yellow-500/10 px-[8px] py-[1px] text-[11px] font-medium text-yellow-400",
        key === "returned" && "bg-green-500/10 px-[8px] py-[1px] text-[11px] font-medium text-green-400",
        key === "partial return" && "bg-blue-500/10 px-[8px] py-[1px] text-[11px] font-medium text-blue-400",
        key === "forfeited" && "bg-red-500/10 px-[8px] py-[1px] text-[11px] font-medium text-red-400",
        key === "paid" && "bg-tint-green text-tint-green-foreground",
        key === "active" && "bg-tint-blue text-tint-blue-foreground",
        key === "retained" && "bg-tint-rose text-tint-rose-foreground",
        key === "held" && "bg-muted text-muted-foreground",
        key === "closed" && "bg-muted text-muted-foreground",
        key === "applied / used" && "bg-muted text-muted-foreground",
        ![
          "paid",
          "returned",
          "active",
          "pending return",
          "partial return",
          "forfeited",
          "retained",
          "held",
          "closed",
          "applied / used",
        ].includes(key) && "bg-muted text-muted-foreground",
      )}
    >
      {status}
    </span>
  );
};

type FinePaymentMethod = "Cash" | "Card" | "Bank Transfer" | "Cheque";

type FinePaymentDraft = {
  amount: string;
  taxRate: string;
  method: FinePaymentMethod;
};

const FineStatusBadge = ({ status }: { status: string | null | undefined }) => {
  const normalized = status === "Paid" ? "Paid" : status === "Partial" ? "Partial" : "Unpaid";

  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center rounded-full border px-2 py-0.5 text-[10px] font-medium",
        normalized === "Paid" && "border-[#22c55e]/25 bg-[#22c55e]/15 text-[#22c55e]",
        normalized === "Partial" && "border-[#f59e0b]/25 bg-[#f59e0b]/15 text-[#f59e0b]",
        normalized === "Unpaid" && "border-[#ef4444]/25 bg-[#ef4444]/15 text-[#ef4444]",
      )}
    >
      {normalized}
    </span>
  );
};

const getFineVehicleSourceLine = (fine: FineRow) => {
  const directFine = fine as FineRow & {
    plate?: string | null;
    make?: string | null;
    model?: string | null;
  };
  const plate = fine.cars?.plate ?? directFine.plate;
  const make = fine.cars?.make ?? directFine.make;
  const model = fine.cars?.model ?? directFine.model;
  const carName = [make, model].filter(Boolean).join(" ").trim();

  return [plate, carName, fine.source].filter(Boolean).join(" · ");
};

const ContractFinesSheet = ({
  contract,
  fines,
  payments,
  open,
  onOpenChange,
  onPaymentRecorded,
}: {
  contract: ContractRecord;
  fines: FineRow[];
  payments: PaymentRow[];
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onPaymentRecorded: () => void | Promise<void>;
}) => {
  const [payingFineId, setPayingFineId] = useState<string | null>(null);
  const [openPaymentFineId, setOpenPaymentFineId] = useState<string | null>(null);
  const [paymentDraft, setPaymentDraft] = useState<FinePaymentDraft>({
    amount: "",
    taxRate: "0",
    method: "Cash",
  });

  useEffect(() => {
    if (!open) {
      setOpenPaymentFineId(null);
      setPaymentDraft({ amount: "", taxRate: "0", method: "Cash" });
    }
  }, [open]);

  const visibleFines = useMemo(
    () =>
      fines
        .filter((fine) => fine.status !== "Paid")
        .map((fine) => {
          const totalPaid = sumPaymentLineAllocations(payments, `fine-${fine.id}`);
          const remainingAmount = Math.max(0, Number(fine.amount) - totalPaid);
          return {
            fine,
            totalPaid,
            displayAmount: fine.status === "Partial" ? remainingAmount : Number(fine.amount),
          };
        }),
    [fines, payments],
  );
  const outstandingTotal = visibleFines.reduce((sum, item) => sum + Number(item.displayAmount), 0);

  const toggleFinePayment = (fine: FineRow, amount: number) => {
    if (openPaymentFineId === fine.id) {
      setOpenPaymentFineId(null);
      return;
    }

    setPaymentDraft({
      amount: amount.toFixed(2),
      taxRate: "0",
      method: "Cash",
    });
    setOpenPaymentFineId(fine.id);
  };

  const recordFinePayment = async (fine: FineRow) => {
    const amount = Number(paymentDraft.amount);
    const taxRate = Number(paymentDraft.taxRate);

    if (!Number.isFinite(amount) || amount <= 0) {
      toast.error("Enter a payment amount greater than zero");
      return;
    }

    if (!Number.isFinite(taxRate) || taxRate < 0) {
      toast.error("Enter a valid tax percentage");
      return;
    }

    const taxAmount = Math.round(((amount * taxRate) / 100) * 100) / 100;
    const lineId = `fine-${fine.id}`;
    const totalPaid = sumPaymentLineAllocations(payments, lineId) + amount;
    const nextStatus = totalPaid >= Number(fine.amount) ? "Paid" : "Partial";

    setPayingFineId(fine.id);
    try {
      const { error: paymentError } = await (supabase as any)
        .from("payments")
        .insert({
          amount,
          tax_rate: taxRate,
          tax_amount: taxAmount,
          method: paymentDraft.method,
          contract_id: contract.id,
          client_id: contract.client_id,
          owner_id: contract.owner_id,
          payment_date: getTodayDateInput(),
          status: "Paid",
          allocations: {
            rental: 0,
            fines: amount,
            salik: 0,
            fees: 0,
            lines: {
              [lineId]: amount,
            },
          },
        });

      if (paymentError) throw paymentError;

      const { error: fineError } = await (supabase as any)
        .from("fines")
        .update({
          status: nextStatus,
          paid_at: nextStatus === "Paid" ? new Date().toISOString() : null,
        })
        .eq("id", fine.id);

      if (fineError) throw fineError;

      toast.success("Fine payment recorded");
      setOpenPaymentFineId(null);
      await onPaymentRecorded();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to record fine payment";
      toast.error(message);
    } finally {
      setPayingFineId(null);
    }
  };

  const renderPaymentForm = (fine: FineRow) => {
    const amount = Number(paymentDraft.amount) || 0;
    const taxRate = Number(paymentDraft.taxRate) || 0;
    const taxAmount = Math.round(((amount * taxRate) / 100) * 100) / 100;
    const total = Math.round((amount + taxAmount) * 100) / 100;
    const isSaving = payingFineId === fine.id;

    return (
      <div className="mt-3 rounded-lg border border-[#24304f] bg-[#0f1729] p-3">
        <div className="grid gap-3 sm:grid-cols-[1fr_96px_150px]">
          <div className="grid gap-1.5">
            <Label className="text-[11px] uppercase tracking-wide text-[#e8eaf0]/55">Amount</Label>
            <Input
              type="number"
              min="0"
              step="0.01"
              value={paymentDraft.amount}
              onChange={(event) => setPaymentDraft((draft) => ({ ...draft, amount: event.target.value }))}
              className="h-9 border-[#2a3a55] bg-[#1a2338] font-mono text-sm text-[#e8eaf0]"
            />
          </div>
          <div className="grid gap-1.5">
            <Label className="text-[11px] uppercase tracking-wide text-[#e8eaf0]/55">Tax %</Label>
            <Input
              type="number"
              min="0"
              step="0.01"
              value={paymentDraft.taxRate}
              onChange={(event) => setPaymentDraft((draft) => ({ ...draft, taxRate: event.target.value }))}
              className="h-9 border-[#2a3a55] bg-[#1a2338] font-mono text-sm text-[#e8eaf0]"
            />
          </div>
          <div className="grid gap-1.5">
            <Label className="text-[11px] uppercase tracking-wide text-[#e8eaf0]/55">Method</Label>
            <Select
              value={paymentDraft.method}
              onValueChange={(value) => setPaymentDraft((draft) => ({ ...draft, method: value as FinePaymentMethod }))}
            >
              <SelectTrigger className="h-9 border-[#2a3a55] bg-[#1a2338] text-sm text-[#e8eaf0]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Cash">Cash</SelectItem>
                <SelectItem value="Card">Card</SelectItem>
                <SelectItem value="Bank Transfer">Bank Transfer</SelectItem>
                <SelectItem value="Cheque">Cheque</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
          <div className="text-xs text-[#e8eaf0]/60">
            Tax {fmtAed(taxAmount)} / Total <span className="font-mono font-semibold text-[#e8eaf0]">{fmtAed(total)}</span>
          </div>
          <div className="flex gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="h-9 border-[#2a3a55] bg-transparent text-xs text-[#e8eaf0]"
              disabled={isSaving}
              onClick={() => setOpenPaymentFineId(null)}
            >
              Cancel
            </Button>
            <Button
              type="button"
              size="sm"
              className="h-9 bg-[#1d4ed8] text-xs font-semibold text-white hover:bg-[#2563eb]"
              disabled={isSaving}
              onClick={() => void recordFinePayment(fine)}
            >
              {isSaving ? "Recording..." : "Record Payment"}
            </Button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="flex h-full w-full flex-col border-l border-[#232d4a] bg-[#161d35] p-0 text-[#e8eaf0] sm:max-w-[560px]">
        <SheetHeader className="border-b border-[#232d4a] px-5 py-4 text-left">
          <div className="flex items-center gap-2">
            <Receipt className="h-5 w-5 text-[#e8eaf0]/70" />
            <SheetTitle className="text-lg font-semibold text-[#e8eaf0]">Contract Fines</SheetTitle>
          </div>
          <SheetDescription className="text-xs text-[#e8eaf0]/55">
            {visibleFines.length} unpaid or partial fines / {fmtAed(outstandingTotal)}
          </SheetDescription>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto px-5 py-4">
          {visibleFines.length === 0 ? (
            <div className="rounded-md border border-[#232d4a] bg-white/[0.02] px-4 py-10 text-center text-sm text-[#e8eaf0]/60">
              No unpaid fines linked to this contract.
            </div>
          ) : (
            <div className="space-y-2">
              {visibleFines.map(({ fine, displayAmount }) => (
                <div key={fine.id} className="rounded-md border border-[#232d4a] bg-white/[0.015] px-3 py-3">
                  <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
                    <div className="min-w-0">
                      <div className="truncate text-sm font-medium text-[#e8eaf0]">
                        {fine.fine_type || "Traffic violation"}
                      </div>
                      <div className="mt-0.5 truncate font-mono text-[11px] tabular-nums text-[#e8eaf0]/50">
                        {formatDubaiDateTime(fine.fine_date)} / {fine.fine_number || "No fine number"}
                      </div>
                      <div className="mt-0.5 truncate text-[11px] text-[#e8eaf0]/50">
                        {getFineVehicleSourceLine(fine) || "No vehicle details"}
                      </div>
                      <div className="mt-2">
                        <FineStatusBadge status={fine.status} />
                      </div>
                    </div>
                    <div className="shrink-0 text-right">
                      <div className="font-mono text-sm font-semibold tabular-nums text-[#e8eaf0]">
                        {fmtAed(displayAmount)}
                      </div>
                      <Button
                        type="button"
                        size="sm"
                        className="mt-2 h-8 bg-[#1d4ed8] px-3 text-xs font-semibold text-white hover:bg-[#2563eb]"
                        onClick={() => toggleFinePayment(fine, displayAmount)}
                      >
                        Pay
                      </Button>
                    </div>
                  </div>
                  {openPaymentFineId === fine.id ? renderPaymentForm(fine) : null}
                </div>
              ))}
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
};

const ContractFinesDetailModal = ({
  contractId,
  fines,
  open,
  onClose,
}: {
  contractId: string;
  fines: FineRow[];
  open: boolean;
  onClose: () => void;
}) => {
  const [search, setSearch] = useState("");

  useEffect(() => {
    if (!open) setSearch("");
  }, [open]);

  const filteredFines = useMemo(() => {
    const query = search.trim().toLowerCase();
    if (!query) return fines;

    return fines.filter((fine) =>
      [fine.fine_number, fine.fine_type].some((value) => value?.toLowerCase().includes(query)),
    );
  }, [fines, search]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end bg-black/65 font-dm-sans" onClick={onClose}>
      <div
        className="max-h-[88vh] w-full animate-in slide-in-from-bottom duration-200 overflow-hidden rounded-t-2xl border border-[#22222e] bg-[#12121a] text-white shadow-2xl"
        onClick={(event) => event.stopPropagation()}
      >
        <header className="flex items-start justify-between gap-4 border-b border-[#22222e] px-4 py-4 sm:px-6">
          <div className="min-w-0">
            <h2 className="text-lg font-semibold leading-6 text-white">Traffic Fines</h2>
            <p className="mt-1 truncate font-mono text-xs text-white/50">{contractId}</p>
          </div>
          <button
            type="button"
            aria-label="Close traffic fines"
            onClick={onClose}
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-md border border-[#22222e] text-white/70 transition hover:bg-white/5 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </header>

        <div className="max-h-[calc(88vh-76px)] overflow-y-auto">
          <section className="space-y-3 px-4 py-4 sm:px-6">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/35" />
              <Input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search fine number or type"
                className="h-11 border-[#22222e] bg-white/[0.03] pl-9 font-dm-sans text-white placeholder:text-white/35 focus-visible:ring-white/20"
              />
            </div>

            <div className="grid grid-cols-[minmax(0,1fr)_86px_76px] gap-2 px-1 text-[11px] font-medium uppercase tracking-normal text-white/40">
              <span>Violation</span>
              <span className="text-right">Amount</span>
              <span className="text-right">Status</span>
            </div>

            {filteredFines.length === 0 ? (
              <p className="rounded-md border border-[#22222e] bg-white/[0.02] px-3 py-8 text-center text-sm text-white/50">
                No traffic fines found.
              </p>
            ) : (
              <div className="space-y-2 pb-2">
                {filteredFines.map((fine) => (
                  <div
                    key={fine.id}
                    className="grid min-h-11 grid-cols-[minmax(0,1fr)_86px_76px] items-center gap-2 rounded-md border border-[#22222e] bg-white/[0.025] px-3 py-3"
                  >
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-white">
                        {fine.fine_type || "Traffic violation"}
                      </p>
                      <p className="mt-1 truncate font-mono text-[11px] tabular-nums text-white/45">
                        {formatDubaiDateTime(fine.fine_date)} / {fine.fine_number || "No fine number"}
                      </p>
                      <p className="mt-0.5 truncate text-[11px] text-white/45">
                        {getFineVehicleSourceLine(fine) || "No vehicle details"}
                      </p>
                    </div>
                    <p className="text-right font-mono text-xs font-semibold tabular-nums text-white">
                      {fmtAed(Number(fine.amount))}
                    </p>
                    <div className="flex justify-end">
                      <FineStatusBadge status={fine.status} />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  );
};

const ContractSalikBulkSheet = ({
  contract,
  open,
  onOpenChange,
  transactions,
  onRefresh,
}: {
  contract: ContractRecord;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  transactions: SalikRow[];
  onRefresh: () => void | Promise<void>;
}) => {
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<"Cash" | "Bank Transfer">("Cash");
  const [confirmingPayment, setConfirmingPayment] = useState(false);

  useEffect(() => {
    if (!open) {
      setSelectedIds(new Set());
      setPaymentDialogOpen(false);
      setPaymentMethod("Cash");
    }
  }, [open]);

  const unpaidTransactions = useMemo(
    () => transactions.filter((transaction) => transaction.status !== "Paid"),
    [transactions],
  );

  const monthGroups = useMemo(() => {
    const groups = new Map<string, { key: string; label: string; ids: string[] }>();

    unpaidTransactions.forEach((transaction) => {
      const date = new Date(`${transaction.charge_date}T00:00:00`);
      const key = Number.isNaN(date.getTime()) ? transaction.charge_date.slice(0, 7) : `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
      const label = Number.isNaN(date.getTime())
        ? transaction.charge_date.slice(0, 7)
        : date.toLocaleDateString("en-US", { month: "short", year: "numeric" });

      const group = groups.get(key) ?? { key, label, ids: [] };
      group.ids.push(transaction.id);
      groups.set(key, group);
    });

    return Array.from(groups.values());
  }, [unpaidTransactions]);

  const visibleIds = useMemo(() => unpaidTransactions.map((transaction) => transaction.id), [unpaidTransactions]);
  const selectedTransactions = useMemo(
    () => unpaidTransactions.filter((transaction) => selectedIds.has(transaction.id)),
    [selectedIds, unpaidTransactions],
  );
  const selectedTotal = selectedTransactions.reduce((sum, transaction) => sum + Number(transaction.amount), 0);
  const allVisibleSelected = visibleIds.length > 0 && visibleIds.every((id) => selectedIds.has(id));
  const someVisibleSelected = visibleIds.some((id) => selectedIds.has(id));

  const toggleTransaction = (id: string) => {
    setSelectedIds((current) => {
      const next = new Set(current);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const toggleVisibleTransactions = () => {
    setSelectedIds((current) => {
      const next = new Set(current);
      if (allVisibleSelected) {
        visibleIds.forEach((id) => next.delete(id));
      } else {
        visibleIds.forEach((id) => next.add(id));
      }
      return next;
    });
  };

  const selectMonthTransactions = (ids: string[]) => {
    setSelectedIds(new Set(ids));
  };

  const openPaymentDialog = async () => {
    if (selectedTransactions.length === 0) return;
    const ids = Array.from(selectedIds);
    const { data, error } = await (supabase as any)
      .from("salik")
      .select("id, status")
      .in("id", ids);

    if (error) {
      toast.error("Failed to verify Salik payment status");
      return;
    }

    const paidIds = new Set(
      ((data ?? []) as Array<{ id: string; status: string }>).filter((transaction) => transaction.status === "Paid").map((transaction) => transaction.id),
    );

    if (paidIds.size > 0) {
      setSelectedIds((current) => {
        const next = new Set(current);
        paidIds.forEach((id) => next.delete(id));
        return next;
      });
      toast.warning("Some selected trips were already paid and have been removed.");
      await onRefresh();
      if (selectedTransactions.every((transaction) => paidIds.has(transaction.id))) return;
    }

    setPaymentDialogOpen(true);
  };

  const confirmSalikPayment = async () => {
    if (selectedTransactions.length === 0 || selectedTotal <= 0) return;

    const ids = selectedTransactions.map((transaction) => transaction.id);

    setConfirmingPayment(true);
    try {
      const { data: statusRows, error: statusError } = await (supabase as any)
        .from("salik")
        .select("id, status")
        .in("id", ids);

      if (statusError) throw statusError;

      const paidIds = new Set(
        ((statusRows ?? []) as Array<{ id: string; status: string }>).filter((transaction) => transaction.status === "Paid").map((transaction) => transaction.id),
      );
      const validTransactions = selectedTransactions.filter((transaction) => !paidIds.has(transaction.id));
      const validSelectedTotal = validTransactions.reduce((sum, transaction) => sum + Number(transaction.amount), 0);

      if (paidIds.size > 0) {
        setSelectedIds(new Set(validTransactions.map((transaction) => transaction.id)));
        toast.warning("Some selected trips were already paid and have been removed.");
        await onRefresh();
      }

      if (validTransactions.length === 0 || validSelectedTotal <= 0) {
        toast.warning("No unpaid Salik trips remain for this payment");
        setPaymentDialogOpen(false);
        return;
      }

      const validIds = validTransactions.map((transaction) => transaction.id);
      const lines = validTransactions.reduce<Record<string, number>>((allocations, transaction) => {
        allocations[`salik-${transaction.id}`] = Number(transaction.amount);
        return allocations;
      }, {});

      const { error: paymentError } = await (supabase as any)
        .from("payments")
        .insert({
          contract_id: contract.id,
          client_id: contract.client_id,
          amount: validSelectedTotal,
          payment_date: getTodayDateInput(),
          method: paymentMethod,
          status: "Paid",
          owner_id: contract.owner_id,
          tax_rate: 0,
          tax_amount: 0,
          allocations: {
            fees: 0,
            fines: 0,
            salik: validSelectedTotal,
            rental: 0,
            lines,
          },
        });

      if (paymentError) throw paymentError;

      const { error: salikError } = await (supabase as any)
        .from("salik")
        .update({ status: "Paid", paid_at: new Date().toISOString() })
        .eq("contract_id", contract.id)
        .in("id", validIds);

      if (salikError) throw salikError;

      toast.success("Salik payment recorded");
      setSelectedIds(new Set());
      setPaymentDialogOpen(false);
      setPaymentMethod("Cash");
      await onRefresh();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to record Salik payment";
      toast.error(message);
    } finally {
      setConfirmingPayment(false);
    }
  };

  return (
    <>
      <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="flex h-full w-full flex-col border-l border-[#232d4a] bg-[#161d35] p-0 text-[#e8eaf0] sm:max-w-[520px]">
        <SheetHeader className="border-b border-[#232d4a] px-5 py-4 text-left">
          <div className="flex items-center gap-2">
            <Route className="h-5 w-5 text-[#e8eaf0]/70" />
            <SheetTitle className="text-lg font-semibold text-[#e8eaf0]">Contract Salik</SheetTitle>
          </div>
          <SheetDescription className="text-xs text-[#e8eaf0]/55">
            {unpaidTransactions.length} unpaid {unpaidTransactions.length === 1 ? "transaction" : "transactions"} found
          </SheetDescription>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto px-5 pb-28 pt-4">
          {unpaidTransactions.length === 0 ? (
            <div className="rounded-md border border-[#232d4a] bg-white/[0.02] px-4 py-10 text-center text-sm text-[#e8eaf0]/60">
              No unpaid Salik linked to this contract.
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex gap-2 overflow-x-auto pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
                {monthGroups.map((month) => {
                  const isSelected = month.ids.every((id) => selectedIds.has(id));

                  return (
                    <button
                      key={month.key}
                      type="button"
                      className={cn(
                        "h-8 shrink-0 rounded-full border px-3 font-mono text-[11px] font-medium tabular-nums transition-colors",
                        isSelected
                          ? "border-[#1d4ed8] bg-[#0c1f3a] text-[#e8eaf0]"
                          : "border-[#232d4a] bg-white/[0.03] text-[#e8eaf0]/70 hover:bg-white/[0.06]",
                      )}
                      onClick={() => selectMonthTransactions(month.ids)}
                    >
                      {month.label} · {month.ids.length}
                    </button>
                  );
                })}
              </div>

              <button
                type="button"
                className="flex min-h-10 w-full items-center gap-3 rounded-md border border-[#232d4a] bg-white/[0.02] px-3 py-2 text-left text-xs font-medium text-[#e8eaf0]/80 transition-colors hover:bg-white/[0.05]"
                onClick={toggleVisibleTransactions}
              >
                <Checkbox
                  checked={allVisibleSelected ? true : someVisibleSelected ? "indeterminate" : false}
                  onCheckedChange={toggleVisibleTransactions}
                  onClick={(event) => event.stopPropagation()}
                  className="h-4 w-4 shrink-0 border-[#64748b] data-[state=checked]:border-[#1d4ed8] data-[state=checked]:bg-[#1d4ed8]"
                />
                <span>Select all</span>
                <span className="ml-auto font-mono text-[11px] tabular-nums text-[#e8eaf0]/45">
                  {visibleIds.length}
                </span>
              </button>

              <div className="space-y-1.5">
                {unpaidTransactions.map((transaction) => {
                  const isSelected = selectedIds.has(transaction.id);

                  return (
                    <div
                      key={transaction.id}
                      role="button"
                      tabIndex={0}
                      className={cn(
                        "grid min-h-12 grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 rounded-md border px-3 py-2 transition-colors",
                        isSelected
                          ? "border-[#1d4ed8] bg-[#0c1f3a]"
                          : "border-[#232d4a] bg-white/[0.015] hover:bg-white/[0.04]",
                      )}
                      onClick={() => toggleTransaction(transaction.id)}
                      onKeyDown={(event) => {
                        if (event.key === "Enter" || event.key === " ") {
                          event.preventDefault();
                          toggleTransaction(transaction.id);
                        }
                      }}
                    >
                      <Checkbox
                        checked={isSelected}
                        onCheckedChange={() => toggleTransaction(transaction.id)}
                        onClick={(event) => event.stopPropagation()}
                        className="h-4 w-4 shrink-0 border-[#64748b] data-[state=checked]:border-[#1d4ed8] data-[state=checked]:bg-[#1d4ed8]"
                      />
                      <div className="min-w-0">
                        <div className="truncate text-sm font-medium text-[#e8eaf0]">
                          {transaction.toll_gate || "Salik transaction"}
                        </div>
                        <div className="mt-0.5 truncate font-mono text-[11px] tabular-nums text-[#e8eaf0]/50">
                          {formatDate(transaction.charge_date)}{transaction.trip_time ? ` · ${transaction.trip_time}` : ""} / {transaction.transaction_id || "No transaction ID"}
                        </div>
                        <div className="mt-0.5 truncate text-[11px] text-[#e8eaf0]/45">
                          {[transaction.cars?.plate, [transaction.cars?.make, transaction.cars?.model].filter(Boolean).join(" ")].filter(Boolean).join(" · ") || "No car"}
                        </div>
                      </div>
                      <div className="shrink-0 text-right font-mono text-sm font-semibold tabular-nums text-[#e8eaf0]">
                        {fmtAed(Number(transaction.amount))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        <div
          className={cn(
            "absolute inset-x-0 bottom-0 border-t border-[#1d4ed8]/30 bg-[#0d1526] px-5 py-4 shadow-2xl transition-all duration-200 ease-out",
            selectedIds.size > 0 ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-full opacity-0",
          )}
        >
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0 font-mono text-sm font-semibold tabular-nums text-[#e8eaf0]">
              {selectedIds.size} {selectedIds.size === 1 ? "transaction" : "transactions"} · {fmtAed(selectedTotal)}
            </div>
            <Button
              type="button"
              size="sm"
              className="h-9 shrink-0 bg-[#1d4ed8] px-4 text-xs font-semibold text-white hover:bg-[#2563eb]"
              onClick={openPaymentDialog}
              disabled={confirmingPayment}
            >
              Pay
            </Button>
          </div>
        </div>
      </SheetContent>
      </Sheet>

      <Dialog open={paymentDialogOpen} onOpenChange={setPaymentDialogOpen}>
        <DialogContent className="sm:max-w-[380px]">
          <DialogHeader>
            <DialogTitle>Salik Payment</DialogTitle>
            <DialogDescription className="text-xs">
              Record payment for the selected Salik transactions.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="rounded-md border border-border bg-muted/30 px-3 py-2">
              <div className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">Amount</div>
              <div className="mt-1 font-mono text-lg font-semibold tabular-nums text-foreground">
                {fmtAed(selectedTotal)}
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-xs">Payment method</Label>
              <Select
                value={paymentMethod}
                onValueChange={(value) => setPaymentMethod(value as "Cash" | "Bank Transfer")}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Cash">Cash</SelectItem>
                  <SelectItem value="Bank Transfer">Bank Transfer</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter className="gap-2 sm:gap-0">
            <Button type="button" variant="outline" onClick={() => setPaymentDialogOpen(false)} disabled={confirmingPayment}>
              Cancel
            </Button>
            <Button type="button" onClick={confirmSalikPayment} disabled={confirmingPayment || selectedTransactions.length === 0}>
              {confirmingPayment ? "Recording..." : "Confirm Payment"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

const FinancialSection = ({
  title,
  meta,
  action,
  children,
}: {
  title: string;
  meta?: React.ReactNode;
  action?: React.ReactNode;
  children: React.ReactNode;
}) => (
  <section className="rounded-md border border-border bg-card">
    <div className="flex items-center justify-between gap-3 border-b border-border px-4 py-3">
      <div className="min-w-0">
        <h3 className="text-[11px] font-semibold uppercase tracking-wider text-foreground">{title}</h3>
        {meta ? <div className="mt-0.5 text-[11px] text-muted-foreground">{meta}</div> : null}
      </div>
      {action}
    </div>
    <div className="divide-y divide-border/50">{children}</div>
  </section>
);

const FinancialLine = ({ children, className }: { children: React.ReactNode; className?: string }) => (
  <div className={cn("flex min-h-14 items-center gap-3 px-4 py-3", className)}>{children}</div>
);

const FinancialIconBox = ({
  icon: Icon,
  tone = "muted",
}: {
  icon: React.ComponentType<{ className?: string }>;
  tone?: "blue" | "green" | "amber" | "violet" | "rose" | "muted";
}) => (
  <span
    className={cn(
      "flex h-9 w-9 shrink-0 items-center justify-center rounded-md",
      tone === "blue" && "bg-tint-blue text-tint-blue-foreground",
      tone === "green" && "bg-tint-green text-tint-green-foreground",
      tone === "amber" && "bg-tint-amber text-tint-amber-foreground",
      tone === "violet" && "bg-tint-violet text-tint-violet-foreground",
      tone === "rose" && "bg-tint-rose text-tint-rose-foreground",
      tone === "muted" && "bg-muted text-muted-foreground",
    )}
  >
    <Icon className="h-4 w-4" />
  </span>
);

type TransactionFilter = "all" | "charges" | "payments" | "adjustments";

type FinancialTransaction = {
  id: string;
  date: string;
  group: TransactionFilter;
  type: string;
  description: string;
  details?: string;
  amount: number;
  amountTone: "debit" | "credit";
  reference: React.ReactNode;
  icon: React.ComponentType<{ className?: string }>;
  iconTone: "blue" | "green" | "amber" | "violet" | "rose" | "muted";
  allocationPayment?: PaymentRow;
  contractFee?: ContractFeeRow;
};

type PaymentAllocationDialogState = {
  payments: PaymentRow[];
  methodLabel: string;
  date: string;
  amount: number;
};

type OpenItemGroup = {
  id: string;
  title: string;
  detail: string;
  meta: string;
  note?: string;
  due: number;
  icon: React.ComponentType<{ className?: string }>;
  iconTone: "blue" | "green" | "amber" | "violet";
};

const FinancialsPanel = ({
  contract,
  days,
  payments,
  fines,
  salik,
  chargeImportEvidence,
  contractFees,
  unpaidAllocationLines,
  totals,
  addFeeInlineOpen,
  savingFee,
  onAddFee,
  onCancelAddFee,
  onSaveFee,
  onAddPayment,
  onEditRentalPeriod,
  onEditPaymentAmount,
  onEditFeeAmount,
  onDeletePayment,
  onDeleteFee,
  onMarkDepositReturned,
  onMarkDepositPartiallyReturned,
  onMarkDepositForfeited,
  markingDepositReturned,
  onInlinePaymentRecorded,
}: FinancialsPanelProps) => {
  const rentalExtensions = sortRentalExtensionFees(contractFees);
  const otherFees = contractFees.filter((fee) => !rentalExtensions.some((extension) => extension.id === fee.id));
  const paymentAllocationLineLookup = useMemo(() => {
    const lookup = new Map<string, Pick<PaymentAllocationDisplayLine, "category" | "label">>();
    lookup.set(`rental-${contract.id}`, { category: "rental", label: "Original Contract" });

    rentalExtensions.forEach((fee, index) => {
      lookup.set(`fee-${fee.id}`, { category: "rental", label: `Extension #${index + 1}` });
    });

    contractFees
      .filter((fee) => !rentalExtensions.some((extension) => extension.id === fee.id))
      .forEach((fee) => {
        lookup.set(`fee-${fee.id}`, { category: "fees", label: fee.label });
      });

    fines.forEach((fine) => {
      lookup.set(`fine-${fine.id}`, {
        category: "fines",
        label: fine.fine_number ? `${fine.fine_type} ${fine.fine_number}` : fine.fine_type,
      });
    });

    salik.forEach((charge) => {
      lookup.set(`salik-${charge.id}`, {
        category: "salik",
        label: charge.transaction_id ? `Salik ${charge.transaction_id}` : charge.toll_gate ? `Salik ${charge.toll_gate}` : "Salik",
      });
    });

    return lookup;
  }, [contract.id, contractFees, fines, rentalExtensions, salik]);
  const depositInfo = getDepositReconciliationInfo(contract);
  const rawDepositStatus = (contract as any).deposit_status;
  const normalizedDepositStatus =
    typeof rawDepositStatus === "string" ? rawDepositStatus.trim().toLowerCase() : "";
  const depositStatus =
    normalizedDepositStatus === "returned"
      ? "Returned"
      : normalizedDepositStatus === "partial"
        ? "Partial return"
        : normalizedDepositStatus === "forfeited"
          ? "Forfeited"
          : normalizedDepositStatus === "pending"
            ? "Pending return"
            : depositInfo.status;
  const isDepositFinalized = ["Returned", "Partial return", "Forfeited"].includes(depositStatus);
  const depositMethod =
    (contract as any).deposit_collection_method ||
    (contract as any).deposit_method ||
    (contract as any).deposit_payment_method;
  const finesVerificationLabel = getChargeVerificationLabel(fines.length, chargeImportEvidence.finesLastImportAt);
  const salikVerificationLabel = getChargeVerificationLabel(salik.length, chargeImportEvidence.salikLastImportAt);
  const hasUnverifiedAdditionalCharges =
    (fines.length === 0 && !chargeImportEvidence.finesLastImportAt) ||
    (salik.length === 0 && !chargeImportEvidence.salikLastImportAt);
  const showDepositVerificationWarning =
    Number(contract.deposit_amount) > 0 &&
    contract.status.toLowerCase() === "closed" &&
    !isDepositFinalized &&
    depositInfo.pendingReturn > 0 &&
    hasUnverifiedAdditionalCharges;
  const [showFinesModal, setShowFinesModal] = useState(false);
  const [showSalikModal, setShowSalikModal] = useState(false);
  const [finesModalOpen, setFinesModalOpen] = useState(false);
  const [salikModalOpen, setSalikModalOpen] = useState(false);
  const [transactionFilter, setTransactionFilter] = useState<TransactionFilter>("all");
  const [transactionSearch, setTransactionSearch] = useState("");
  const [showAllPayments, setShowAllPayments] = useState(false);
  const [allocationDialog, setAllocationDialog] = useState<PaymentAllocationDialogState | null>(null);
  const [openInlinePaymentId, setOpenInlinePaymentId] = useState<string | null>(null);
  const [inlinePaymentDraft, setInlinePaymentDraft] = useState<InlinePaymentDraft>({
    amount: "",
    taxRate: "0",
    method: "Cash",
  });
  const [savingInlinePayment, setSavingInlinePayment] = useState(false);
  const [depositPartialReturnOpen, setDepositPartialReturnOpen] = useState(false);
  const [depositPartialReturnAmount, setDepositPartialReturnAmount] = useState("");
  const [depositForfeitConfirmOpen, setDepositForfeitConfirmOpen] = useState(false);
  const depositAmount = Math.max(0, Number(contract.deposit_amount) || 0);
  const depositPartialReturnValue = Math.max(0, Number(depositPartialReturnAmount) || 0);
  const depositPartialRetainedAmount = Math.max(0, depositAmount - depositPartialReturnValue);
  const canConfirmDepositPartialReturn =
    depositPartialReturnValue > 0 && depositPartialReturnValue <= depositAmount;

  const openItemGroups = useMemo(() => {
    const groups = new Map<string, OpenItemGroup>();
    const unpaidRentalLines = unpaidAllocationLines.filter((line) => line.category === "rental");
    const unpaidRentalDue = unpaidRentalLines.reduce((sum, line) => sum + Number(line.due), 0);

    unpaidAllocationLines.forEach((line) => {
      const existing = groups.get(line.category);
      const nextDue = (existing?.due ?? 0) + Number(line.due);
      const count = (unpaidAllocationLines.filter((item) => item.category === line.category).length);

      if (line.category === "rental" && !groups.has("rental")) {
        groups.set("rental", {
          id: "rental",
          title: "Rent Outstanding",
          detail: `${unpaidRentalLines.length} unpaid ${unpaidRentalLines.length === 1 ? "period" : "periods"}`,
          meta: `${formatDate(contract.start_date)} - ${formatDate(getLatestRentalPeriodEnd(contract, rentalExtensions))}`,
          due: unpaidRentalDue,
          icon: CalendarDays,
          iconTone: "blue",
        });
      }

      if (line.category === "salik") {
        groups.set("salik", {
          id: "salik",
          title: "Salik",
          detail: `${salik.filter((charge) => charge.status.toLowerCase() !== "paid").reduce((sum, charge) => sum + Number(charge.trips), 0)} trips`,
          meta: salikVerificationLabel,
          due: nextDue,
          icon: Route,
          iconTone: "green",
        });
      }

      if (line.category === "fines") {
        groups.set("fines", {
          id: "fines",
          title: "Traffic Fines",
          detail: `${fines.filter((fine) => fine.status !== "Paid").length} fines`,
          meta: finesVerificationLabel,
          due: nextDue,
          icon: CarFront,
          iconTone: "amber",
        });
      }

      if (line.category === "fees") {
        const fee = otherFees.find((item) => `fee-${item.id}` === line.id);
        const feeCategory = FEE_CATEGORIES.find((category) => category.value === fee?.category);
        const feeIcon =
          fee?.category === "delivery" || fee?.category === "pickup"
            ? CarFront
            : fee?.category === "fuel"
              ? Wallet
              : fee?.category === "extra_mileage"
                ? Route
                : fee?.category === "damage"
                  ? ShieldCheck
                  : fee?.category === "detailing"
                    ? Camera
                    : Tag;

        groups.set(line.id, {
          id: line.id,
          title: line.label || "Other unpaid charges",
          detail: feeCategory?.label ?? "Other",
          meta: "Unpaid fee",
          note: fee?.note?.trim() || undefined,
          due: Number(line.due),
          icon: feeIcon,
          iconTone: "violet",
        });
      }
    });

    return Array.from(groups.values());
  }, [
    contract.end_date,
    contract.start_date,
    fines,
    finesVerificationLabel,
    otherFees,
    rentalExtensions,
    salik,
    salikVerificationLabel,
    unpaidAllocationLines,
  ]);

  const transactions = useMemo<FinancialTransaction[]>(() => {
    const latestFineDate =
      fines.reduce((latest, fine) => {
        const currentTime = new Date(fine.fine_date).getTime() || 0;
        const latestTime = latest ? new Date(latest).getTime() || 0 : 0;
        return currentTime > latestTime ? fine.fine_date : latest;
      }, fines[0]?.fine_date ?? contract.start_date) || contract.start_date;
    const latestSalikDate =
      salik.reduce((latest, charge) => {
        const currentTime = new Date(charge.charge_date).getTime() || 0;
        const latestTime = latest ? new Date(latest).getTime() || 0 : 0;
        return currentTime > latestTime ? charge.charge_date : latest;
      }, salik[0]?.charge_date ?? contract.start_date) || contract.start_date;
    const finesTotal = fines.reduce((sum, fine) => sum + Number(fine.amount), 0);
    const salikTotal = salik.reduce((sum, charge) => sum + Number(charge.amount), 0);
    const salikTripCount = salik.reduce((sum, charge) => sum + Number(charge.trips), 0);

    const rows: FinancialTransaction[] = [
      {
        id: `rent-${contract.id}`,
        date: contract.start_date,
        group: "charges",
        type: "Rent",
        description: "Rent - Original Contract",
        details: `${formatDate(contract.start_date)} - ${formatDate(contract.end_date)}`,
        amount: Number(contract.total_amount),
        amountTone: "debit",
        reference: contractNumberLabel(contract.id),
        icon: CalendarDays,
        iconTone: "blue",
      },
      ...rentalExtensions.map((fee, index) => {
        return {
          id: `rent-extension-${fee.id}`,
          date: fee.extension_start ?? fee.created_at ?? contract.start_date,
          group: "adjustments" as const,
          type: "Rent",
          description: `Extension #${index + 1}`,
          details: `${formatDate(fee.extension_start)} -> ${formatDate(fee.extension_end)} (included in rent total)`,
          amount: Number(fee.amount),
          amountTone: "credit" as const,
          reference: contractNumberLabel(contract.id),
          icon: CalendarDays,
          iconTone: "blue" as const,
          contractFee: fee,
        };
      }),
      ...otherFees.map((fee) => ({
        id: `fee-${fee.id}`,
        date: fee.created_at ?? contract.start_date,
        group: "charges" as const,
        type: "Charge",
        description: FEE_CATEGORIES.find((category) => category.value === fee.category)?.label ?? "Other fee",
        details: fee.label,
        amount: Number(fee.amount),
        amountTone: "debit" as const,
        reference: contractNumberLabel(contract.id),
        icon: Tag,
        iconTone: "violet" as const,
        contractFee: fee,
      })),
      ...(fines.length > 0 ? [{
        id: "fines-summary",
        date: latestFineDate,
        group: "charges" as const,
        type: "Fine",
        description: "Traffic Fines",
        details: `${fines.length} ${fines.length === 1 ? "violation" : "violations"}`,
        amount: finesTotal,
        amountTone: "debit" as const,
        reference: contractNumberLabel(contract.id),
        icon: CarFront,
        iconTone: "amber" as const,
      }] : []),
      ...(salik.length > 0 ? [{
        id: "salik-summary",
        date: latestSalikDate,
        group: "charges" as const,
        type: "Salik",
        description: "Salik Charges",
        details: `${salikTripCount} ${salikTripCount === 1 ? "trip" : "trips"}`,
        amount: salikTotal,
        amountTone: "debit" as const,
        reference: contractNumberLabel(contract.id),
        icon: Route,
        iconTone: "green" as const,
      }] : []),
      ...payments.map((payment) => ({
        id: `payment-${payment.id}`,
        date: payment.payment_date,
        group: "payments" as const,
        type: "Payment",
        description: payment.method ?? "Payment",
        details: `${payment.method} payment received`,
        amount: Number(payment.amount),
        amountTone: "credit" as const,
        reference: <PaymentAllocationDetails payment={payment} lineLookup={paymentAllocationLineLookup} />,
        icon: Receipt,
        iconTone: "green" as const,
        allocationPayment: payment,
      })),
    ];

    return rows.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [
    contract.end_date,
    contract.id,
    contract.start_date,
    contract.total_amount,
    fines,
    otherFees,
    paymentAllocationLineLookup,
    payments,
    rentalExtensions,
    salik,
  ]);

  const visibleTransactions = transactions.filter((transaction) => {
    if (transactionFilter !== "all" && transaction.group !== transactionFilter) return false;
    const query = transactionSearch.trim().toLowerCase();
    if (!query) return true;
    return [transaction.type, transaction.description, transaction.details, transaction.date]
      .filter(Boolean)
      .some((value) => String(value).toLowerCase().includes(query));
  });
  const rentalPeriods = buildRentalPeriods(contract, rentalExtensions).map((period) => ({
    ...period,
    onEdit: () => onEditRentalPeriod(period.fee),
  })).sort((a, b) => {
    const aTime = new Date(a.startDate).getTime() || 0;
    const bTime = new Date(b.startDate).getTime() || 0;
    return bTime - aTime;
  });
  const currentRentalPeriod = rentalPeriods[0];
  const pastRentalPeriods = rentalPeriods.slice(1);

  const getTransactionIconClass = (transaction: FinancialTransaction) => {
    if (transaction.type === "Payment") return "bg-green-950 text-green-300";
    if (transaction.type === "Fine") return "bg-red-950 text-red-300";
    if (transaction.type === "Salik") return "bg-emerald-950 text-emerald-300";
    if (transaction.type === "Rent") return "bg-blue-950 text-blue-300";
    return "bg-purple-950 text-purple-300";
  };

  const getOpenItemAllocationLines = (item: OpenItemGroup) => {
    if (item.id === "rental") return unpaidAllocationLines.filter((line) => line.category === "rental");
    if (item.id.startsWith("fee-")) return unpaidAllocationLines.filter((line) => line.id === item.id);
    return unpaidAllocationLines.filter((line) => line.category === item.id);
  };

  const updatePaidFineStatuses = async (currentFineAllocations: Record<string, number> = {}) => {
    const updates = fines
      .map((fine) => {
        const lineId = `fine-${fine.id}`;
        const totalPaid =
          sumPaymentLineAllocations(payments, lineId) + Number(currentFineAllocations[lineId] ?? 0);

        if (totalPaid >= Number(fine.amount)) {
          return {
            id: fine.id,
            status: "Paid",
            paid_at: new Date().toISOString(),
          };
        }

        if (totalPaid > 0) {
          return {
            id: fine.id,
            status: "Partial",
            paid_at: null,
          };
        }

        return null;
      })
      .filter(Boolean);

    for (const update of updates) {
      const { error } = await (supabase as any)
        .from("fines")
        .update({ status: update.status, paid_at: update.paid_at })
        .eq("id", update.id);

      if (error) throw error;
    }
  };

  const toggleInlinePayment = (item: OpenItemGroup) => {
    if (openInlinePaymentId === item.id) {
      setOpenInlinePaymentId(null);
      return;
    }

    setInlinePaymentDraft({
      amount: Number(item.due).toFixed(2),
      taxRate: "0",
      method: "Cash",
    });
    setOpenInlinePaymentId(item.id);
  };

  const recordInlinePayment = async (item: OpenItemGroup) => {
    const amount = Number(inlinePaymentDraft.amount);
    const taxRate = Number(inlinePaymentDraft.taxRate);
    if (!Number.isFinite(amount) || amount <= 0) {
      toast.error("Enter a valid payment amount");
      return;
    }
    if (!Number.isFinite(taxRate) || taxRate < 0) {
      toast.error("Enter a valid tax rate");
      return;
    }

    const taxAmount = Math.round(((amount * taxRate) / 100) * 100) / 100;
    const lineAllocations: Record<string, number> = {};
    const groupedAllocations: SavedPaymentAllocations = {
      rental: 0,
      fines: 0,
      salik: 0,
      fees: 0,
      lines: lineAllocations,
    };
    let remaining = amount;

    for (const line of getOpenItemAllocationLines(item)) {
      if (remaining <= 0) break;
      const allocated = Math.min(Number(line.due), remaining);
      if (allocated <= 0) continue;
      const roundedAllocated = Math.round(allocated * 100) / 100;
      lineAllocations[line.id] = roundedAllocated;
      groupedAllocations[line.category] += roundedAllocated;
      remaining -= allocated;
    }

    setSavingInlinePayment(true);
    const { error } = await supabase.from("payments").insert({
      amount,
      tax_rate: taxRate,
      tax_amount: taxAmount,
      method: inlinePaymentDraft.method,
      contract_id: contract.id,
      client_id: contract.client_id,
      owner_id: contract.owner_id,
      payment_date: getTodayDateInput(),
      status: "Paid",
      allocations: groupedAllocations,
    } as never);

    setSavingInlinePayment(false);

    if (error) {
      toast.error("Failed to record payment");
      return;
    }

    try {
      await updatePaidFineStatuses(lineAllocations);
    } catch (statusError) {
      console.error("Failed to update fine payment status:", statusError);
      toast.error("Payment recorded, but fine status could not update");
    }

    toast.success("Payment recorded");
    setOpenInlinePaymentId(null);
    onInlinePaymentRecorded();
  };

  const renderInlinePaymentForm = (item: OpenItemGroup) => {
    const amount = Number(inlinePaymentDraft.amount) || 0;
    const taxRate = Number(inlinePaymentDraft.taxRate) || 0;
    const taxAmount = Math.round(((amount * taxRate) / 100) * 100) / 100;
    const total = Math.round((amount + taxAmount) * 100) / 100;

    return (
      <div className="border-t border-[#1e3a5f] bg-[#0f1729] px-4 py-3">
        <div className="flex flex-col md:flex-row md:items-end md:gap-3 md:flex-wrap">
          <div className="flex w-full gap-3 md:w-auto">
            <div className="grid w-full gap-1.5 md:w-48">
              <Label className="text-[11px] uppercase tracking-wide text-muted-foreground">Amount</Label>
              <Input
                type="number"
                min="0"
                step="0.01"
                value={Math.round(Number(inlinePaymentDraft.amount))}
                onChange={(event) => setInlinePaymentDraft((draft) => ({ ...draft, amount: event.target.value }))}
                className="h-9 rounded-lg border border-[#2a3a55] bg-[#1a2338] font-mono text-sm tabular-nums text-foreground"
              />
            </div>
            <div className="grid w-full gap-1.5 md:w-24">
              <Label className="text-[11px] uppercase tracking-wide text-muted-foreground">Tax %</Label>
              <Input
                type="number"
                min="0"
                step="0.01"
                value={inlinePaymentDraft.taxRate}
                onChange={(event) => setInlinePaymentDraft((draft) => ({ ...draft, taxRate: event.target.value }))}
                className="h-9 rounded-lg border border-[#2a3a55] bg-[#1a2338] font-mono text-sm tabular-nums text-foreground"
              />
            </div>
          </div>
          <div className="w-full space-y-1 text-sm md:w-auto md:self-center">
            <div className="flex items-center justify-between gap-3 text-xs text-muted-foreground">
              <span>Tax amount</span>
              <span className="font-mono tabular-nums">{fmtAed(taxAmount)}</span>
            </div>
            <div className="flex items-center justify-between gap-3 text-sm font-semibold text-foreground">
              <span>Total</span>
              <span className="font-mono tabular-nums text-tint-green-foreground">{fmtAed(total)}</span>
            </div>
          </div>
          <Select
            value={inlinePaymentDraft.method}
            onValueChange={(value) =>
              setInlinePaymentDraft((draft) => ({ ...draft, method: value as InlinePaymentMethod }))
            }
          >
            <SelectTrigger className="h-9 w-full rounded-lg border border-[#2a3a55] bg-[#1a2338] py-2 text-sm md:w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Cash">Cash</SelectItem>
              <SelectItem value="Card">Card</SelectItem>
              <SelectItem value="Bank Transfer">Bank Transfer</SelectItem>
              <SelectItem value="Cheque">Cheque</SelectItem>
            </SelectContent>
          </Select>
          <div className="flex w-full gap-2 md:w-auto">
            <Button
              type="button"
              size="sm"
              className="h-9 flex-1 rounded-lg border border-blue-800 bg-blue-900 text-sm font-semibold text-blue-300 hover:bg-blue-900/80 hover:text-blue-300"
              disabled={savingInlinePayment}
              onClick={() => void recordInlinePayment(item)}
            >
              {savingInlinePayment ? "Recording..." : "Record Payment"}
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="h-9 w-24 rounded-lg border border-[#2a3a55] bg-transparent text-sm font-semibold text-foreground hover:bg-white/5 hover:text-foreground"
              disabled={savingInlinePayment}
              onClick={() => setOpenInlinePaymentId(null)}
            >
              Cancel
            </Button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <>
      <div className="w-full max-w-full min-w-0 space-y-4 pb-20">
        <section>
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <div
                className={cn(
                  "font-mono text-xl font-semibold tabular-nums",
                  totals.outstanding > 0 ? "text-tint-rose-foreground" : "text-tint-green-foreground",
                )}
              >
                {fmtAed(totals.outstanding)}
              </div>
              <div className="text-xs text-muted-foreground">Deposit tracked separately below</div>
            </div>
          </div>
        </section>

        <FinancialSection
          title="Open Items"
          meta={`What the customer owes - ${openItemGroups.length} items`}
        >
          {showDepositVerificationWarning ? (
            <div className="flex items-start gap-2 rounded-md border border-tint-amber-foreground/25 bg-tint-amber px-3 py-2 text-xs text-tint-amber-foreground">
              <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              <span>Fines/Salik import not verified. Review before returning deposit.</span>
            </div>
          ) : null}
          {openItemGroups.length === 0 ? (
            <FinancialLine className="text-xs text-muted-foreground">No unpaid customer items.</FinancialLine>
          ) : (
            openItemGroups.map((item) => (
              <div key={item.id}>
                <FinancialLine className="min-h-0 flex-nowrap py-2">
                  <FinancialIconBox icon={item.icon} tone={item.iconTone} />
                  <div className="flex min-w-0 flex-1 flex-col gap-0.5">
                    <span className="whitespace-normal text-xs font-semibold text-foreground">{item.title}</span>
                    <span className="whitespace-normal text-[11px] text-muted-foreground">{item.detail}</span>
                    {item.note ? (
                      <span className="whitespace-normal text-[11px] text-muted-foreground">{item.note}</span>
                    ) : null}
                  </div>
                  <div className="hidden min-w-[170px] text-xs text-muted-foreground md:block">{item.meta}</div>
                  <span className="ml-auto w-28 shrink-0 text-right font-mono text-sm font-bold tabular-nums text-tint-rose-foreground">
                    {fmtAed(item.due)}
                  </span>
                  {item.id === "fines" ? (
                    <Button type="button" variant="outline" size="sm" className="h-8 shrink-0 gap-1.5" onClick={() => setShowFinesModal(true)}>
                      View
                      <ExternalLink className="h-3.5 w-3.5" />
                    </Button>
                  ) : item.id === "salik" ? (
                    <Button type="button" variant="outline" size="sm" className="h-8 shrink-0 gap-1.5" onClick={() => setShowSalikModal(true)}>
                      View
                      <ExternalLink className="h-3.5 w-3.5" />
                    </Button>
                  ) : (
                    <Button type="button" variant="outline" size="sm" className="h-8 shrink-0 gap-1.5" onClick={() => toggleInlinePayment(item)}>
                      Pay
                    </Button>
                  )}
                </FinancialLine>
                {openInlinePaymentId === item.id ? renderInlinePaymentForm(item) : null}
              </div>
            ))
          )}
          <div className="border-t border-border px-4 py-2">
            {addFeeInlineOpen ? (
              <AddFeeInline
                onSave={(fee) => {
                  if (!savingFee) onSaveFee(fee);
                }}
                onCancel={onCancelAddFee}
                className={cn(savingFee && "pointer-events-none opacity-70")}
              />
            ) : (
              <div className="grid grid-cols-[auto_1fr] items-center gap-3 md:block">
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="h-8 w-auto justify-start gap-1.5 px-2 text-xs font-medium text-muted-foreground hover:bg-muted/50 hover:text-foreground"
                  onClick={onAddFee}
                >
                  <Plus className="h-3.5 w-3.5" />
                  Add Fee
                </Button>
                <Button
                  type="button"
                  className="h-11 min-w-0 gap-2 bg-primary text-primary-foreground hover:bg-primary/90 md:hidden"
                  onClick={onAddPayment}
                >
                  <Plus className="h-4 w-4" />
                  Add Payment
                </Button>
              </div>
            )}
          </div>
        </FinancialSection>

        <FinancialSection title="Rental History" meta={`${rentalPeriods.length} periods`}>
          {currentRentalPeriod ? (
            <div className="px-4 py-3">
              <div className="flex overflow-hidden rounded-lg border border-blue-800 bg-blue-950/30">
                <div className="h-full w-[3px] shrink-0 bg-blue-500 rounded-l-lg" />
                <div className="flex flex-1 items-center gap-3 px-3 py-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-xs font-semibold text-foreground">{currentRentalPeriod.name}</span>
                      <span className="rounded-full bg-blue-950 px-2 py-0.5 text-[10px] font-medium text-blue-300">
                        Current
                      </span>
                    </div>
                    <div className="mt-1 text-xs text-muted-foreground">
                      {formatDate(currentRentalPeriod.startDate)} - {formatDate(currentRentalPeriod.endDate)}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-[11px] text-muted-foreground">
                      {diffDays(currentRentalPeriod.startDate, currentRentalPeriod.endDate)} days
                    </div>
                    <div className="mt-0.5 font-mono text-sm font-semibold tabular-nums text-foreground">
                      {fmtAed(currentRentalPeriod.amount)}
                    </div>
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    aria-label="Edit current rental period"
                    className="h-8 w-8 shrink-0 text-muted-foreground hover:bg-green-950/40 hover:text-foreground"
                    onClick={currentRentalPeriod.onEdit}
                  >
                    <Pencil className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            </div>
          ) : null}

          {pastRentalPeriods.length > 0 ? (
            <details className="group px-4 py-3">
              <summary className="flex h-8 cursor-pointer list-none items-center gap-2 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground [&::-webkit-details-marker]:hidden">
                <ChevronDown className="h-3.5 w-3.5 group-open:hidden" />
                <ChevronUp className="hidden h-3.5 w-3.5 group-open:block" />
                <span className="group-open:hidden">Show all periods ({rentalPeriods.length})</span>
                <span className="hidden group-open:inline">Hide past periods</span>
              </summary>
              <div className="mt-2 space-y-2">
                {pastRentalPeriods.map((period) => (
                  <div key={period.id} className="flex items-center justify-between gap-3 rounded-md bg-background/30 px-3 py-2 text-zinc-500">
                    <div className="min-w-0">
                      <div className="truncate text-xs font-medium">{period.name}</div>
                      <div className="mt-0.5 text-xs">
                        {formatDate(period.startDate)} - {formatDate(period.endDate)} - {diffDays(period.startDate, period.endDate)} days
                      </div>
                    </div>
                    <div className="shrink-0 font-mono text-xs tabular-nums">{fmtAed(period.amount)}</div>
                  </div>
                ))}
              </div>
            </details>
          ) : null}
        </FinancialSection>

        <FinancialSection
          title="Transaction History"
          meta="All charges, payments, and adjustments"
        >
          <div className="border-b border-border px-4 py-3">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
              <div className="flex overflow-x-auto rounded-md border border-border bg-background/40 p-0.5">
                {([
                  ["all", "All"],
                  ["charges", "Charges"],
                  ["payments", "Payments"],
                  ["adjustments", "Adjustments"],
                ] as const).map(([value, label]) => (
                  <button
                    key={value}
                    type="button"
                    className={cn(
                      "h-8 shrink-0 rounded px-3 text-xs font-medium text-muted-foreground transition-colors",
                      transactionFilter === value && "bg-muted text-foreground",
                    )}
                    onClick={() => setTransactionFilter(value)}
                  >
                    {label}
                  </button>
                ))}
              </div>
              <div className="flex gap-2">
                <div className="relative min-w-0 flex-1 lg:w-56 lg:flex-none">
                  <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    value={transactionSearch}
                    onChange={(event) => setTransactionSearch(event.target.value)}
                    placeholder="Search..."
                    className="h-8 pl-8 text-xs"
                  />
                </div>
                <Button type="button" variant="outline" size="sm" className="h-8 gap-1.5" onClick={() => setTransactionSearch("")}>
                  <Filter className="h-3.5 w-3.5" />
                  Filters
                </Button>
              </div>
            </div>
          </div>

          <div className="hidden grid-cols-[1fr_auto] gap-3 border-b border-border px-4 py-2 text-[11px] font-medium text-muted-foreground md:grid">
            <span>Type / Description</span>
            <span className="text-right">Amount</span>
          </div>

          {visibleTransactions.length === 0 ? (
            <FinancialLine className="text-xs text-muted-foreground">No transactions match the current view.</FinancialLine>
          ) : (
            (() => {
              const renderTransactionRow = (transaction: FinancialTransaction) => {
              const payment = transaction.allocationPayment;
              const isPaymentTransaction = transaction.type === "Payment" && Boolean(payment);
              const isFeeTransaction = transaction.type === "Charge" && Boolean(transaction.contractFee);
              const feeTransactionNote = isFeeTransaction ? transaction.contractFee?.note?.trim() : "";
              const showsTransactionDate = isFeeTransaction || isPaymentTransaction;
              const showsTransactionDetails =
                transaction.type === "Rent" || transaction.type === "Fine" || transaction.type === "Salik";

              return (
              <div key={transaction.id}>
                <div className="flex items-center gap-3 px-4 py-3">
                  <div className={cn("flex h-8 w-8 shrink-0 self-start items-center justify-center rounded-lg", getTransactionIconClass(transaction))}>
                    {(() => {
                      const TransactionIcon = transaction.icon;
                      return <TransactionIcon className="h-3.5 w-3.5" />;
                    })()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold text-foreground">{transaction.description}</div>
                    {isPaymentTransaction ? (
                      <button
                        type="button"
                        className="mt-0.5 block truncate text-xs text-muted-foreground hover:text-foreground"
                        onClick={() =>
                          setAllocationDialog({
                            payments: [payment!],
                            methodLabel: `${payment!.method} Payment`,
                            date: payment!.payment_date,
                            amount: Number(payment!.amount) || 0,
                          })
                        }
                      >
                        Applied to
                      </button>
                    ) : null}
                    {showsTransactionDetails && transaction.details ? (
                      <div className="mt-0.5 truncate text-xs text-muted-foreground">{transaction.details}</div>
                    ) : null}
                    {feeTransactionNote ? (
                      <div className="mt-0.5 truncate text-xs text-muted-foreground">{feeTransactionNote}</div>
                    ) : null}
                  </div>
                  <div className="ml-auto flex flex-shrink-0 flex-col items-end">
                    <div className="flex items-center gap-2 flex-shrink-0 ml-auto">
                      <span
                        className={cn(
                          "font-mono text-sm font-bold tabular-nums",
                          transaction.amountTone === "credit" ? "text-green-400" : "text-zinc-200",
                        )}
                      >
                        {transaction.amountTone === "credit" ? "+" : ""}
                        {fmtAed(transaction.amount)}
                      </span>
                      {transaction.type === "Fine" ? (
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="h-8 px-2 text-xs text-muted-foreground hover:bg-transparent hover:text-foreground"
                          onClick={() => setFinesModalOpen(true)}
                        >
                          View all →
                        </Button>
                      ) : transaction.type === "Salik" ? (
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="h-8 px-2 text-xs text-muted-foreground hover:bg-transparent hover:text-foreground"
                          onClick={() => setSalikModalOpen(true)}
                        >
                          View all →
                        </Button>
                      ) : null}
                      {transaction.allocationPayment || transaction.contractFee ? (
                        <>
                          {transaction.allocationPayment ? (
                            <>
                              <Button
                                type="button"
                                variant="ghost"
                                size="icon"
                                aria-label="Edit payment amount"
                                className="h-8 w-8 text-muted-foreground hover:bg-transparent hover:text-foreground"
                                onClick={() => onEditPaymentAmount(transaction.allocationPayment!)}
                              >
                                <Pencil className="h-3.5 w-3.5" />
                              </Button>
                              <Button
                                type="button"
                                variant="ghost"
                                size="icon"
                                aria-label="Delete payment"
                                className="h-8 w-8 text-muted-foreground hover:bg-transparent hover:text-destructive"
                                onClick={() => onDeletePayment(transaction.allocationPayment!)}
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </Button>
                            </>
                          ) : null}
                          {transaction.contractFee ? (
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              aria-label="Delete fee"
                              className="h-8 w-8 text-muted-foreground hover:bg-transparent hover:text-destructive"
                              onClick={() => onDeleteFee(transaction.contractFee!)}
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          ) : null}
                        </>
                      ) : null}
                    </div>
                    {showsTransactionDate ? (
                      <div className="text-xs text-right text-muted-foreground">
                        {formatDate(transaction.date)}
                      </div>
                    ) : null}
                  </div>
                </div>
              </div>
              );
              };

              if (transactionFilter !== "all") {
                return visibleTransactions.map(renderTransactionRow);
              }

              const chargeTransactions = visibleTransactions.filter((transaction) => transaction.group === "charges");
              const paymentTransactions = visibleTransactions.filter((transaction) => transaction.group === "payments");
              const paymentGroups = Array.from(
                paymentTransactions.reduce((groups, transaction) => {
                  const dateKey = transaction.date.slice(0, 10);
                  const group = groups.get(dateKey);
                  if (group) {
                    group.push(transaction);
                  } else {
                    groups.set(dateKey, [transaction]);
                  }
                  return groups;
                }, new Map<string, FinancialTransaction[]>()),
              ).map(([, group]) => group);
              const visiblePaymentGroups = showAllPayments ? paymentGroups : paymentGroups.slice(0, 5);
              const hasHiddenPayments = paymentGroups.length > visiblePaymentGroups.length;

              const renderMergedPaymentRow = (group: FinancialTransaction[]) => {
                const paymentRows = group
                  .map((transaction) => transaction.allocationPayment)
                  .filter((payment): payment is PaymentRow => Boolean(payment));
                const methods = Array.from(new Set(paymentRows.map((payment) => payment.method).filter(Boolean)));
                const amount = group.reduce((sum, transaction) => sum + Number(transaction.amount), 0);
                const date = group[0]?.date ?? "";
                const description = methods.length === 1 ? `${methods[0]} Payment` : `${group.length} payments`;

                return (
                  <div
                    key={`merged-payments-${date}`}
                    role="button"
                    tabIndex={0}
                    className="cursor-pointer"
                    onClick={() =>
                      setAllocationDialog({
                        payments: paymentRows,
                        methodLabel: description,
                        date,
                        amount,
                      })
                    }
                    onKeyDown={(event) => {
                      if (event.key === "Enter" || event.key === " ") {
                        event.preventDefault();
                        setAllocationDialog({
                          payments: paymentRows,
                          methodLabel: description,
                          date,
                          amount,
                        });
                      }
                    }}
                  >
                    <div className="flex items-center gap-3 px-4 py-3">
                      <div className="flex h-8 w-8 shrink-0 self-start items-center justify-center rounded-lg bg-green-950 text-green-300">
                        <Receipt className="h-3.5 w-3.5" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="text-sm font-semibold text-foreground">{description}</div>
                        <div className="mt-0.5 truncate text-xs text-muted-foreground">Applied to</div>
                      </div>
                      <div className="ml-auto flex flex-shrink-0 flex-col items-end">
                        <span className="font-mono text-sm font-bold tabular-nums text-green-400">
                          +{fmtAed(amount)}
                        </span>
                        <div className="text-right text-xs text-muted-foreground">
                          {formatDate(date)}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              };

              return (
                <>
                  {chargeTransactions.length > 0 ? (
                    <div>
                      <div className="border-b border-border px-4 py-2 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                        Charges
                      </div>
                      {chargeTransactions.map(renderTransactionRow)}
                    </div>
                  ) : null}

                  {paymentTransactions.length > 0 ? (
                    <div className={cn(chargeTransactions.length > 0 && "border-t border-border")}>
                      <div className="border-b border-border px-4 py-2 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                        Payments
                      </div>
                      {visiblePaymentGroups.map((group) =>
                        group.length === 1 ? renderTransactionRow(group[0]) : renderMergedPaymentRow(group)
                      )}
                      {hasHiddenPayments ? (
                        <div className="px-4 pb-3">
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            className="h-8 px-0 text-xs text-muted-foreground hover:bg-transparent hover:text-foreground"
                            onClick={() => setShowAllPayments(true)}
                          >
                            Show all payments ({paymentTransactions.length})
                          </Button>
                        </div>
                      ) : null}
                    </div>
                  ) : null}
                </>
              );
            })()
          )}

          <Dialog
            open={Boolean(allocationDialog)}
            onOpenChange={(open) => {
              if (!open) setAllocationDialog(null);
            }}
          >
            <DialogContent className="sm:max-w-[420px]">
              {allocationDialog ? (
                (() => {
                  const allocationRows = Array.from(
                    allocationDialog.payments
                      .flatMap((payment) => buildExpandedPaymentAllocationRows(payment, contractFees, fines))
                      .reduce((rows, line) => {
                        const key = line.label === "Salik" ? "salik" : line.id;
                        const existing = rows.get(key);
                        rows.set(key, existing ? { ...existing, amount: existing.amount + line.amount } : line);
                        return rows;
                      }, new Map<string, ExpandedPaymentAllocationRow>())
                      .values(),
                  );

                  return (
                    <>
                      <DialogHeader>
                        <DialogTitle>Payment Allocation</DialogTitle>
                        <DialogDescription className="text-xs">
                          {allocationDialog.methodLabel} {"\u00B7"} {formatDate(allocationDialog.date)}
                        </DialogDescription>
                      </DialogHeader>

                      <div className="space-y-4">
                        <div className="rounded-md border border-border bg-background/40 px-3 py-2">
                          <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                            Total amount
                          </div>
                          <div className="mt-1 font-mono text-lg font-bold tabular-nums text-foreground">
                            {fmtAed(allocationDialog.amount)}
                          </div>
                        </div>

                        <div className="grid gap-2">
                          {allocationRows.map((line) => (
                            <div key={line.id} className="flex items-center justify-between gap-3 rounded-md bg-background/30 px-3 py-2">
                              <span className="min-w-0 truncate text-sm text-foreground">{line.label}</span>
                              <span className="shrink-0 font-mono text-sm font-semibold tabular-nums text-foreground">
                                {fmtAed(line.amount)}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <DialogFooter>
                        <Button type="button" variant="outline" onClick={() => setAllocationDialog(null)}>
                          Close
                        </Button>
                      </DialogFooter>
                    </>
                  );
                })()
              ) : null}
            </DialogContent>
          </Dialog>
        </FinancialSection>

        <div className="rounded-md border border-border bg-card p-4">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex min-w-0 items-center gap-3">
              <FinancialIconBox icon={ShieldCheck} tone="violet" />
              <div className="min-w-0">
                <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Security Deposit</div>
                <div className="mt-0.5 text-xs text-muted-foreground">Separate from balance</div>
              </div>
            </div>
            <div className="grid gap-3 sm:grid-cols-2 lg:min-w-[420px] lg:grid-cols-[1fr_auto] lg:items-center">
              <div>
                <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Amount</div>
                <div className="mt-0.5 font-mono text-sm font-semibold tabular-nums text-foreground">
                  {fmtAed(Number(contract.deposit_amount))}
                </div>
                {depositMethod ? (
                  <div className="mt-0.5 text-[10px] text-muted-foreground">Collected via {depositMethod}</div>
                ) : null}
              </div>
              <div>
                <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Status</div>
                <div className="mt-1">
                  <FinancialBadge status={depositStatus} />
                </div>
              </div>
            </div>
          </div>

          {Number(contract.deposit_amount) > 0 && contract.status.toLowerCase() === "closed" ? (
            <div className="mt-3 grid gap-2 border-t border-border pt-3 text-xs">
              {isDepositFinalized ? (
                <>
                  {depositStatus !== "Forfeited" ? (
                    <div className="flex justify-between gap-3">
                      <span className="text-muted-foreground">Returned amount</span>
                      <span className="font-mono font-semibold tabular-nums">
                        {fmtAed(Number((contract as any).deposit_returned) || depositInfo.returnedAmount || Number(contract.deposit_amount))}
                      </span>
                    </div>
                  ) : null}
                  {depositStatus === "Partial return" || depositStatus === "Forfeited" ? (
                    <div className="flex justify-between gap-3">
                      <span className="text-muted-foreground">Forfeited</span>
                      <span className="font-mono font-semibold tabular-nums">
                        {fmtAed(Number((contract as any).deposit_forfeited) || (depositStatus === "Forfeited" ? depositAmount : 0))}
                      </span>
                    </div>
                  ) : null}
                  <div className="flex justify-between gap-3">
                    <span className="text-muted-foreground">Returned date</span>
                    <span className="font-mono font-semibold tabular-nums">
                      {(contract as any).deposit_return_date ? formatDate((contract as any).deposit_return_date) : depositInfo.returnedDate ?? "Recorded"}
                    </span>
                  </div>
                  <div className="flex flex-wrap justify-end gap-2 pt-1">
                    <Button
                      type="button"
                      size="sm"
                      className="h-8 cursor-not-allowed gap-1.5 text-xs opacity-50"
                      disabled
                    >
                      Return Full
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      className="h-8 cursor-not-allowed text-xs opacity-50"
                      disabled
                    >
                      Partial Return
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      className="h-8 cursor-not-allowed border-tint-rose-foreground/40 text-xs text-tint-rose-foreground opacity-50"
                      disabled
                    >
                      Forfeit
                    </Button>
                  </div>
                </>
              ) : (
                <>
                  <div className="flex justify-between gap-3">
                    <span className="text-muted-foreground">Pending return</span>
                    <span className="font-mono font-semibold tabular-nums">
                      {fmtAed(depositInfo.pendingReturn)}
                    </span>
                  </div>
                  {depositInfo.returnDue ? (
                    <div className="flex justify-between gap-3">
                      <span className="text-muted-foreground">Return due date</span>
                      <span className="font-mono font-semibold tabular-nums">{depositInfo.returnDue}</span>
                    </div>
                  ) : null}
                  {depositInfo.retained > 0 ? (
                    <div className="flex justify-between gap-3">
                      <span className="text-muted-foreground">Retained</span>
                      <span className="font-mono font-semibold tabular-nums">
                        {fmtAed(depositInfo.retained)}
                      </span>
                    </div>
                  ) : null}
                  {depositInfo.reason ? (
                    <div className="flex justify-between gap-3">
                      <span className="text-muted-foreground">Retention reason</span>
                      <span className="max-w-[60%] text-right font-medium text-foreground">{depositInfo.reason}</span>
                    </div>
                  ) : null}
                  {depositInfo.appliedToBalance > 0 ? (
                    <div className="flex justify-between gap-3">
                      <span className="text-muted-foreground">Applied to balance</span>
                      <span className="font-mono font-semibold tabular-nums">
                        {fmtAed(depositInfo.appliedToBalance)}
                      </span>
                    </div>
                  ) : null}
                  {depositInfo.pendingReturn > 0 ? (
                    <div className="grid gap-2 pt-1">
                      <div className="flex flex-wrap justify-end gap-2">
                        <Button
                          type="button"
                          size="sm"
                          className={cn("h-8 gap-1.5 text-xs", isDepositFinalized && "cursor-not-allowed opacity-50")}
                          disabled={markingDepositReturned || isDepositFinalized}
                          onClick={() => onMarkDepositReturned(depositAmount)}
                        >
                          {markingDepositReturned ? "Saving..." : "Return Full"}
                        </Button>
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          className={cn("h-8 text-xs", isDepositFinalized && "cursor-not-allowed opacity-50")}
                          disabled={markingDepositReturned || isDepositFinalized}
                          onClick={() => {
                            setDepositForfeitConfirmOpen(false);
                            setDepositPartialReturnOpen((open) => !open);
                          }}
                        >
                          Partial Return
                        </Button>
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          className={cn(
                            "h-8 border-tint-rose-foreground/40 text-xs text-tint-rose-foreground",
                            isDepositFinalized && "cursor-not-allowed opacity-50",
                          )}
                          disabled={markingDepositReturned || isDepositFinalized}
                          onClick={() => {
                            setDepositPartialReturnOpen(false);
                            setDepositForfeitConfirmOpen((open) => !open);
                          }}
                        >
                          Forfeit
                        </Button>
                      </div>

                      {depositPartialReturnOpen && !isDepositFinalized ? (
                        <div className="grid gap-2 rounded-md border border-border bg-background p-3">
                          <Label className="text-[10px] uppercase tracking-wide text-muted-foreground">
                            Amount to return (AED)
                          </Label>
                          <Input
                            type="number"
                            min={0}
                            max={depositAmount}
                            value={depositPartialReturnAmount}
                            onChange={(event) => setDepositPartialReturnAmount(event.target.value)}
                            className="font-['IBM_Plex_Mono']"
                            placeholder="0.00"
                          />
                          <div className="flex justify-between gap-3 text-xs">
                            <span className="text-muted-foreground">Retained</span>
                            <span className="font-mono font-semibold tabular-nums">
                              {fmtAed(depositPartialRetainedAmount)}
                            </span>
                          </div>
                          <div className="flex justify-end">
                            <Button
                              type="button"
                              size="sm"
                              className="h-8 text-xs"
                              disabled={markingDepositReturned || !canConfirmDepositPartialReturn}
                              onClick={() => {
                                onMarkDepositPartiallyReturned(depositPartialReturnValue);
                                setDepositPartialReturnOpen(false);
                                setDepositPartialReturnAmount("");
                              }}
                            >
                              {markingDepositReturned ? "Saving..." : "Confirm Partial Return"}
                            </Button>
                          </div>
                        </div>
                      ) : null}

                      {depositForfeitConfirmOpen && !isDepositFinalized ? (
                        <div className="grid gap-2 rounded-md border border-tint-rose-foreground/30 bg-tint-rose/10 p-3">
                          <div className="text-xs font-medium text-tint-rose-foreground">
                            Forfeit full deposit of {fmtAed(depositAmount)}? This means the client receives nothing.
                          </div>
                          <div className="flex justify-end gap-2">
                            <Button
                              type="button"
                              size="sm"
                              variant="outline"
                              className="h-8 text-xs"
                              disabled={markingDepositReturned}
                              onClick={() => setDepositForfeitConfirmOpen(false)}
                            >
                              Cancel
                            </Button>
                            <Button
                              type="button"
                              size="sm"
                              variant="destructive"
                              className="h-8 text-xs"
                              disabled={markingDepositReturned}
                              onClick={() => {
                                onMarkDepositForfeited();
                                setDepositForfeitConfirmOpen(false);
                              }}
                            >
                              {markingDepositReturned ? "Saving..." : "Confirm Forfeit"}
                            </Button>
                          </div>
                        </div>
                      ) : null}
                    </div>
                  ) : null}
                </>
              )}
            </div>
          ) : null}
        </div>

        <div className="fixed inset-x-0 bottom-0 z-40 hidden w-full max-w-[100vw] min-w-0 justify-end bg-[#121830] p-3 md:flex">
          <Button
            type="button"
            className="h-11 min-w-[180px] gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
            onClick={onAddPayment}
          >
            <Plus className="h-4 w-4" />
            Add Payment
          </Button>
        </div>
      </div>

      <ContractFinesSheet
        contract={contract}
        fines={fines}
        payments={payments}
        open={showFinesModal}
        onOpenChange={setShowFinesModal}
        onPaymentRecorded={onInlinePaymentRecorded}
      />
      <ContractSalikBulkSheet
        contract={contract}
        open={showSalikModal}
        onOpenChange={setShowSalikModal}
        transactions={salik}
        onRefresh={onInlinePaymentRecorded}
      />
      <ContractFinesDetailModal
        contractId={contract.id}
        fines={fines}
        open={finesModalOpen}
        onClose={() => setFinesModalOpen(false)}
      />
      <SalikDetailModal contractId={contract.id} open={salikModalOpen} onClose={() => setSalikModalOpen(false)} />
    </>
  );
};

const ContractDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const [contract, setContract] = useState<ContractRecord | null>(null);
  const [fines, setFines] = useState<FineRow[]>([]);
  const [salik, setSalik] = useState<SalikRow[]>([]);
  const [chargeImportEvidence, setChargeImportEvidence] = useState<ChargeImportEvidence>({
    finesLastImportAt: null,
    salikLastImportAt: null,
  });
  const [payments, setPayments] = useState<PaymentRow[]>([]);
  const [contractFees, setContractFees] = useState<ContractFeeRow[]>([]);
  const [contractDocuments, setContractDocuments] = useState<ContractDocumentRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingNotes, setEditingNotes] = useState(false);
  const [notesDraft, setNotesDraft] = useState("");
  const [savingNotes, setSavingNotes] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showAddFeeInline, setShowAddFeeInline] = useState(false);
  const [savingFee, setSavingFee] = useState(false);
  const [feeRefreshKey, setFeeRefreshKey] = useState(0);
  const [showCloseModal, setShowCloseModal] = useState(false);
  const [closeReturnDate, setCloseReturnDate] = useState("");
  const [closeReceivedBy, setCloseReceivedBy] = useState("");
  const [closeFinalMileage, setCloseFinalMileage] = useState("");
  const [closeVehicleStatus, setCloseVehicleStatus] = useState("Available");
  const [depositCloseAction, setDepositCloseAction] = useState<DepositCloseAction>("return_full");
  const [depositRetainedAmount, setDepositRetainedAmount] = useState("");
  const [depositRetainReason, setDepositRetainReason] = useState("");
  const [depositReturnDueDate, setDepositReturnDueDate] = useState("");
  const [depositReturnDueDateEdited, setDepositReturnDueDateEdited] = useState(false);
  const [isClosing, setIsClosing] = useState(false);
  const [showExtendModal, setShowExtendModal] = useState(false);
  const [extendEndDate, setExtendEndDate] = useState("");
  const [extendAmount, setExtendAmount] = useState("");
  const [extendError, setExtendError] = useState("");
  const [isExtending, setIsExtending] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editStartDate, setEditStartDate] = useState("");
  const [editStartTime, setEditStartTime] = useState("");
  const [editEndDate, setEditEndDate] = useState("");
  const [editEndTime, setEditEndTime] = useState("");
  const [editCarId, setEditCarId] = useState("");
  const [availableCars, setAvailableCars] = useState<AvailableCarRow[]>([]);
  const [isSavingEdit, setIsSavingEdit] = useState(false);
  const [replaceVehicleOpen, setReplaceVehicleOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [replacementCount, setReplacementCount] = useState(0);
  const [reopenConfirmOpen, setReopenConfirmOpen] = useState(false);
  const [isReopening, setIsReopening] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [paymentToDelete, setPaymentToDelete] = useState<PaymentRow | null>(null);
  const [feeToDelete, setFeeToDelete] = useState<ContractFeeRow | null>(null);
  const [deletingPayment, setDeletingPayment] = useState(false);
  const [deletingFee, setDeletingFee] = useState(false);
  const [amountEditTarget, setAmountEditTarget] = useState<AmountEditTarget | null>(null);
  const [amountEditValue, setAmountEditValue] = useState("");
  const [amountEditPaymentMethod, setAmountEditPaymentMethod] = useState<PaymentMethod>("Cash");
  const [amountEditAllocations, setAmountEditAllocations] = useState<Record<string, number>>({});
  const [amountEditAllocationError, setAmountEditAllocationError] = useState("");
  const [amountEditExtensionEndDate, setAmountEditExtensionEndDate] = useState("");
  const [savingAmountEdit, setSavingAmountEdit] = useState(false);
  const [rentalPeriodEditTarget, setRentalPeriodEditTarget] = useState<RentalPeriodEditTarget | null>(null);
  const [rentalPeriodEndDate, setRentalPeriodEndDate] = useState("");
  const [rentalPeriodAmount, setRentalPeriodAmount] = useState("");
  const [rentalPeriodEditError, setRentalPeriodEditError] = useState("");
  const [savingRentalPeriod, setSavingRentalPeriod] = useState(false);
  const [markingDepositReturned, setMarkingDepositReturned] = useState(false);
  const [generatingInvoice, setGeneratingInvoice] = useState(false);

  const navigate = useNavigate();

  const fetchContractFees = useCallback(async () => {
    if (!contract?.id) {
      setContractFees([]);
      return;
    }
    let { data, error } = await (supabase as any)
      .from("contract_fees")
      .select("id, category, label, amount, note, extension_start, extension_end, created_at")
      .eq("contract_id", contract.id)
      .order("created_at", { ascending: false });

    if (error && /note/i.test(error.message ?? "")) {
      const fallback = await (supabase as any)
        .from("contract_fees")
        .select("id, category, label, amount, extension_start, extension_end, created_at")
        .eq("contract_id", contract.id)
        .order("created_at", { ascending: false });
      data = fallback.data;
      error = fallback.error;
    }

    if (error) {
      toast.error("Failed to load fees");
      return;
    }

    setContractFees(
      ((data ?? []) as ContractFeeRow[]).map((fee) => ({
        ...fee,
        amount: Number(fee.amount),
      })),
    );
  }, [contract?.id]);

  const fetchData = useCallback(async () => {
    if (!id) return;
    const { data: contractData, error: contractErr } = await supabase
      .from("contracts")
      .select(
        "*, clients(full_name, phone, email, emirates_id, passport_number, nationality, client_type), cars(plate, make, model, year)",
      )
      .eq("id", id)
      .maybeSingle();

    if (contractErr) {
      toast.error("Failed to load contract");
      setLoading(false);
      return;
    }

    const c = contractData as ContractRecord | null;
    setContract(c);
    setNotesDraft((c as { notes?: string | null } | null)?.notes ?? "");

    if (c) {
      const [
        paymentsRes,
        finesRes,
        salikRes,
        latestFinesImportRes,
        latestSalikImportRes,
        documentsRes,
      ] = await Promise.all([
        supabase
          .from("payments")
          .select("id, payment_date, amount, method, status, allocations")
          .eq("contract_id", c.id)
          .order("payment_date", { ascending: false }),
        supabase
          .from("fines")
          .select("id, fine_date, fine_number, fine_type, amount, status, source, notes, car_id, cars(plate, make, model)")
          .eq("contract_id", c.id)
          .order("fine_date", { ascending: false }),
        supabase
          .from("salik")
          .select("id, charge_date, trip_time, transaction_id, toll_gate, direction, trips, amount, status, car_id, cars(plate, make, model)")
          .eq("contract_id", c.id)
          .order("charge_date", { ascending: false }),
        supabase
          .from("fines")
          .select("created_at")
          .eq("owner_id", c.owner_id)
          .order("created_at", { ascending: false })
          .limit(1)
          .maybeSingle(),
        supabase
          .from("salik")
          .select("created_at")
          .eq("owner_id", c.owner_id)
          .order("created_at", { ascending: false })
          .limit(1)
          .maybeSingle(),
        (supabase as any)
          .from("contract_documents")
          .select("id, document_type, title, storage_bucket, storage_path, public_url, created_at")
          .eq("contract_id", c.id)
          .order("created_at", { ascending: true }),
      ]);
      if (!paymentsRes.error) setPayments(paymentsRes.data || []);
      if (!finesRes.error) setFines(finesRes.data || []);
      if (!salikRes.error) setSalik(salikRes.data || []);
      if (documentsRes.error) {
        toast.error("Failed to load contract documents");
        setContractDocuments([]);
      } else {
        setContractDocuments((documentsRes.data ?? []) as ContractDocumentRow[]);
      }
      setChargeImportEvidence({
        finesLastImportAt:
          !latestFinesImportRes.error && latestFinesImportRes.data
            ? (latestFinesImportRes.data as { created_at: string }).created_at
            : null,
        salikLastImportAt:
          !latestSalikImportRes.error && latestSalikImportRes.data
            ? (latestSalikImportRes.data as { created_at: string }).created_at
            : null,
      });
    } else {
      setContractDocuments([]);
      setChargeImportEvidence({ finesLastImportAt: null, salikLastImportAt: null });
    }
    setLoading(false);
  }, [id]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  useEffect(() => {
    if (!contract?.id) return;
    (supabase as unknown as any)
      .from("contract_vehicles")
      .select("id", { count: "exact", head: true })
      .eq("contract_id", contract.id)
      .then(({ count }: { count: number | null }) => {
        setReplacementCount(count ?? 0);
      });
  }, [contract?.id]);

  useEffect(() => {
    fetchContractFees();
  }, [fetchContractFees, feeRefreshKey]);

  const reconcileFinePaymentStatuses = useCallback(async () => {
    if (!contract) return;

    const { data: contractPayments, error } = await supabase
      .from("payments")
      .select("id, payment_date, amount, method, status, allocations")
      .eq("contract_id", contract.id);

    if (error) {
      toast.error("Failed to verify fine payment status");
      return;
    }

    const loadedPayments = (contractPayments ?? []) as PaymentRow[];
    const updates = fines
      .map((fine) => {
        const totalPaid = sumPaymentLineAllocations(loadedPayments, `fine-${fine.id}`);

        if (totalPaid >= Number(fine.amount)) {
          return { id: fine.id, status: "Paid", paid_at: new Date().toISOString() };
        }

        if (totalPaid > 0) {
          return { id: fine.id, status: "Partial", paid_at: null };
        }

        return null;
      })
      .filter(Boolean);

    for (const update of updates) {
      const { error: updateError } = await (supabase as any)
        .from("fines")
        .update({ status: update.status, paid_at: update.paid_at })
        .eq("id", update.id);

      if (updateError) {
        toast.error("Failed to update fine payment status");
        return;
      }
    }
  }, [contract, fines]);

  const handlePaymentRecorded = useCallback(async () => {
    await reconcileFinePaymentStatuses();
    await fetchData();
  }, [fetchData, reconcileFinePaymentStatuses]);

  const getContractDocumentUrl = useCallback((document: ContractDocumentRow) => {
    if (document.public_url) return document.public_url;

    const { data } = supabase.storage
      .from(document.storage_bucket)
      .getPublicUrl(document.storage_path);

    return data.publicUrl;
  }, []);

  const openContractDocument = useCallback((document: ContractDocumentRow) => {
    const url = getContractDocumentUrl(document);
    if (!url) {
      toast.error("Document URL is not available");
      return;
    }

    window.open(url, "_blank", "noopener,noreferrer");
  }, [getContractDocumentUrl]);

  const shareContractDocumentOnWhatsApp = useCallback((document: ContractDocumentRow) => {
    if (!document.public_url) return;

    const phone = contract?.clients?.phone?.replace(/\D/g, "") ?? "";
    const message = `${document.title}: ${document.public_url}`;
    const url = phone
      ? `https://wa.me/${phone}?text=${encodeURIComponent(message)}`
      : `https://wa.me/?text=${encodeURIComponent(message)}`;

    window.open(url, "_blank", "noopener,noreferrer");
  }, [contract?.clients?.phone]);

  const effectiveContractEndDate = contract ? getLatestRentalPeriodEnd(contract, contractFees) : "";

  const days = useMemo(
    () => (contract ? diffDays(contract.start_date, effectiveContractEndDate) : 0),
    [contract, effectiveContractEndDate],
  );

  const ledger: LedgerEntry[] = useMemo(() => {
    if (!contract) return [];
    const entries: LedgerEntry[] = [];
    entries.push({
      id: `rental-${contract.id}`,
      date: contract.start_date,
      type: "Rental",
      description: `${contract.rate_type} rental · ${days} days @ ${fmtAed(contract.rate_amount)}`,
      debit: Number(contract.total_amount),
      credit: 0,
      status: contract.status,
    });
    if (Number(contract.deposit_amount) > 0) {
      entries.push({
        id: `deposit-${contract.id}`,
        date: contract.start_date,
        type: "Deposit",
        description: "Refundable security deposit",
        debit: Number(contract.deposit_amount),
        credit: 0,
        status: "Held",
      });
    }
    fines.forEach((f) =>
      entries.push({
        id: `fine-${f.id}`,
        date: f.fine_date,
        type: "Fine",
        description: `${f.fine_type} · ${f.source}`,
        debit: Number(f.amount),
        credit: 0,
        status: f.status,
      }),
    );
    salik.forEach((s) =>
      entries.push({
        id: `salik-${s.id}`,
        date: s.charge_date,
        type: "Salik",
        description: `${s.trips} toll trips`,
        debit: Number(s.amount),
        credit: 0,
        status: s.status,
      }),
    );
    payments.forEach((p) =>
      entries.push({
        id: `pay-${p.id}`,
        date: p.payment_date,
        type: "Payment",
        description: `Payment received · ${p.method}`,
        debit: 0,
        credit: p.status?.toLowerCase() === "paid" ? Number(p.amount) : 0,
        status: p.status,
      }),
    );
    return entries.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [contract, fines, salik, payments, days]);

  const totals = useMemo(() => {
    const feeCharges = contractFees
      .filter((fee) => !isRentalExtensionFee(fee))
      .reduce((sum, fee) => sum + Number(fee.amount), 0);
    const charges = ledger.reduce((s, e) => e.type === "Deposit" ? s : s + e.debit, 0) + feeCharges;
    const credits = ledger.reduce((s, e) => s + e.credit, 0);
    // Security deposit is reconciled separately and must not reduce the customer balance.
    const outstanding = Math.max(0, charges - credits);
    return { charges, credits, outstanding, overdue: 0 };
  }, [ledger, contractFees]);

  const saveNotes = async () => {
    if (!contract) return;
    setSavingNotes(true);
    const { error } = await supabase
      .from("contracts")
      .update({ notes: notesDraft } as never)
      .eq("id", contract.id);
    setSavingNotes(false);
    if (error) {
      toast.error("Failed to save notes");
      return;
    }
    toast.success("Notes saved");
    setContract({ ...contract, notes: notesDraft });
    setEditingNotes(false);
  };

  const handleDownloadInvoice = async () => {
    if (!contract || !user) return;

    setGeneratingInvoice(true);
    try {
      const [profileRes, feesRes, finesRes, salikRes, paymentsRes] = await Promise.all([
        (supabase as any)
          .from("profiles")
          .select(
            "company_name, company_name_ar, phone_number, trn, address, logo_url, stamp_url, bank_name, beneficiary_name, iban, account_number, swift_code, invoice_prefix, contract_prefix, vat_enabled, vat_rate",
          )
          .eq("id", user.id)
          .maybeSingle(),
        (supabase as any)
          .from("contract_fees")
          .select("id, label, amount")
          .eq("contract_id", contract.id)
          .order("created_at", { ascending: true }),
        (supabase as any)
          .from("fines")
          .select("id, amount")
          .eq("contract_id", contract.id),
        (supabase as any)
          .from("salik")
          .select("id, trips, amount")
          .eq("contract_id", contract.id),
        (supabase as any)
          .from("payments")
          .select("id, amount")
          .eq("contract_id", contract.id),
      ]);

      if (profileRes.error || feesRes.error || finesRes.error || salikRes.error || paymentsRes.error) {
        throw new Error(
          profileRes.error?.message ||
            feesRes.error?.message ||
            finesRes.error?.message ||
            salikRes.error?.message ||
            paymentsRes.error?.message ||
            "Failed to load invoice data",
        );
      }

      let vehicle = contract.cars as
        | ({ make: string; model: string; year: number; plate?: string | null; color?: string | null; plate_number?: string | null })
        | null;
      const vehicleRes = await (supabase as any)
        .from("cars")
        .select("make, model, year, color, plate, plate_number")
        .eq("id", contract.car_id)
        .maybeSingle();
      if (!vehicleRes.error && vehicleRes.data) {
        vehicle = vehicleRes.data;
      } else {
        const fallbackVehicleRes = await (supabase as any)
          .from("cars")
          .select("make, model, year, plate")
          .eq("id", contract.car_id)
          .maybeSingle();
        if (!fallbackVehicleRes.error && fallbackVehicleRes.data) {
          vehicle = fallbackVehicleRes.data;
        }
      }

      const profile = (profileRes.data ?? {}) as {
        company_name?: string | null;
        company_name_ar?: string | null;
        phone_number?: string | null;
        trn?: string | null;
        address?: string | null;
        logo_url?: string | null;
        stamp_url?: string | null;
        bank_name?: string | null;
        beneficiary_name?: string | null;
        iban?: string | null;
        account_number?: string | null;
        swift_code?: string | null;
        invoice_prefix?: string | null;
        contract_prefix?: string | null;
        vat_enabled?: boolean | null;
        vat_rate?: number | null;
      };
      const companyName = cleanPdfValue(profile.company_name) || "Company Name";
      const companyPhone = cleanPdfValue(profile.phone_number);
      const companyTrn = cleanPdfValue(profile.trn);
      const companyAddress = cleanPdfValue(profile.address);
      const invoicePrefix = cleanPdfValue(profile.invoice_prefix) || "INV";
      const vatEnabled = Boolean(profile.vat_enabled);
      const vatRate = Math.min(100, Math.max(0, Number(profile.vat_rate ?? 5) || 0));
      const vatLabel = `VAT ${vatRate.toLocaleString("en-US", { maximumFractionDigits: 2 })}%`;
      const bankRows: Array<[string, string]> = [
        ["Bank Name", cleanPdfValue(profile.bank_name)],
        ["Beneficiary Name", cleanPdfValue(profile.beneficiary_name)],
        ["IBAN", cleanPdfValue(profile.iban)],
        ["Account Number", cleanPdfValue(profile.account_number)],
        ["SWIFT Code", cleanPdfValue(profile.swift_code)],
      ].filter(([, value]) => Boolean(value));
      const client = contract.clients;
      const invoiceNo = `${invoicePrefix}-${contract.id}`;
      const invoiceDate = new Date().toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      });
      const money = (value: number) =>
        Number(value || 0).toLocaleString("en-US", {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2,
        });
      const aed = (value: number) => `AED ${money(value)}`;
      const rentalDays = Math.max(1, diffDays(contract.start_date, contract.end_date));
      const rentalAmount = Number(contract.total_amount) || 0;
      const chargedFines = ((finesRes.data ?? []) as Array<{ id: string; amount: number }>).map((fine) => ({
        ...fine,
        amount: Number(fine.amount) || 0,
      }));
      const salikCharges = ((salikRes.data ?? []) as Array<{ id: string; trips: number; amount: number }>).map((charge) => ({
        ...charge,
        trips: Number(charge.trips) || 0,
        amount: Number(charge.amount) || 0,
      }));
      const fees = ((feesRes.data ?? []) as Array<{ id: string; label: string; amount: number }>).map((fee) => ({
        ...fee,
        amount: Number(fee.amount) || 0,
      }));
      const paidAmount = ((paymentsRes.data ?? []) as Array<{ amount: number }>).reduce(
        (sum, payment) => sum + (Number(payment.amount) || 0),
        0,
      );
      const finesTotal = chargedFines.reduce((sum, fine) => sum + fine.amount, 0);
      const salikTrips = salikCharges.reduce((sum, charge) => sum + charge.trips, 0);
      const salikTotal = salikCharges.reduce((sum, charge) => sum + charge.amount, 0);
      const feeTotal = fees.reduce((sum, fee) => sum + fee.amount, 0);
      const subtotal = rentalAmount + finesTotal + salikTotal + feeTotal;
      const taxTotal = vatEnabled ? (subtotal * vatRate) / 100 : 0;
      const invoiceAmount = subtotal + taxTotal;
      const remainingBalance = Math.max(0, invoiceAmount - paidAmount);
      const invoiceStatus =
        remainingBalance <= 0.01 ? "Paid" : paidAmount > 0 ? "Partially Paid" : "Unpaid";
      const statusColors =
        invoiceStatus === "Paid"
          ? { fill: [240, 253, 244], text: [22, 163, 74] }
          : invoiceStatus === "Partially Paid"
            ? { fill: [255, 251, 235], text: [217, 119, 6] }
            : { fill: [254, 242, 242], text: [220, 38, 38] };

      const makeInvoiceRow = (description: string, quantity: string, amount: number) => {
        const vatAmount = vatEnabled ? (amount * vatRate) / 100 : 0;
        const row = [
          String(rows.length + 1).padStart(2, "0"),
          description,
          quantity,
          money(amount),
        ];
        return vatEnabled ? [...row, money(vatAmount), money(amount + vatAmount)] : [...row, money(amount)];
      };
      const rows: string[][] = [];
      rows.push(
        makeInvoiceRow(
          `Car Rental\n${formatDate(contract.start_date)} - ${formatDate(contract.end_date)}`,
          `${rentalDays} days`,
          rentalAmount,
        ),
      );
      if (chargedFines.length > 0) {
        rows.push(
          makeInvoiceRow(
            `Traffic Fines\n${chargedFines.length} ${chargedFines.length === 1 ? "fine" : "fines"} - incl. AED 20 service fee`,
            String(chargedFines.length),
            finesTotal,
          ),
        );
      }
      if (salikCharges.length > 0) {
        rows.push(
          makeInvoiceRow(
            `Salik Charges\n${salikTrips} ${salikTrips === 1 ? "trip" : "trips"}`,
            String(salikTrips),
            salikTotal,
          ),
        );
      }
      fees.forEach((fee) => {
        rows.push(makeInvoiceRow(fee.label || "Contract Fee", "1", fee.amount));
      });

      const loadCompanyImage = async (path: string | null | undefined) => {
        const imagePath = cleanPdfValue(path);
        if (!imagePath) return null;
        let fetchUrl = imagePath;
        if (!imagePath.startsWith("http")) {
          const { data } = await supabase.storage.from("company-logos").createSignedUrl(imagePath, 60);
          if (!data?.signedUrl) return null;
          fetchUrl = data.signedUrl;
        }
        return loadPdfImage(fetchUrl);
      };
      const [logoImage, stampImage] = await Promise.all([
        loadCompanyImage(profile.logo_url),
        loadCompanyImage(profile.stamp_url),
      ]);

      const doc = new jsPDF({ unit: "pt", format: "a4" });
      const pageW = doc.internal.pageSize.getWidth();
      const pageH = doc.internal.pageSize.getHeight();
      const margin = 36;
      const navy = [18, 24, 48] as const;
      const grey = [107, 114, 128] as const;
      const lightGrey = [249, 250, 251] as const;
      const borderGrey = [229, 231, 235] as const;

      const text = (
        value: string,
        x: number,
        y: number,
        options: { size?: number; color?: readonly number[]; font?: "helvetica" | "courier"; style?: "normal" | "bold"; align?: "left" | "right" | "center" } = {},
      ) => {
        doc.setFont(options.font ?? "helvetica", options.style ?? "normal");
        doc.setFontSize(options.size ?? 10);
        doc.setTextColor(...(options.color ?? [17, 24, 39]));
        doc.text(value, x, y, { align: options.align ?? "left" });
      };

      const drawImageFit = (image: PdfImage, x: number, y: number, maxW: number, maxH: number) => {
        const ratio = Math.min(maxW / image.w, maxH / image.h);
        const w = image.w * ratio;
        const h = image.h * ratio;
        const imageX = x + (maxW - w) / 2;
        const imageY = y + (maxH - h) / 2;
        try {
          doc.addImage(image.dataUrl, "PNG", imageX, imageY, w, h);
        } catch {
          try {
            doc.addImage(image.dataUrl, "JPEG", imageX, imageY, w, h);
          } catch {
            // Ignore unsupported or unreachable image data so invoice generation still succeeds.
          }
        }
      };

      const headerTextX = logoImage ? margin + 54 : margin;
      const headerMaxW = pageW - margin * 2 - 208 - (headerTextX - margin);
      if (logoImage) {
        drawImageFit(logoImage, margin, 38, 40, 40);
      }
      const companyNameLines = (doc.splitTextToSize(companyName, headerMaxW) as string[]).slice(0, 2);
      companyNameLines.forEach((line, index) => {
        text(line, headerTextX, 49 + index * 11, { size: 12, style: "bold", color: navy });
      });
      const contactStartY = 52 + companyNameLines.length * 11;
      const companyContactLines = [
        ...doc.splitTextToSize(companyAddress, headerMaxW).slice(0, 3),
        companyPhone ? `Phone: ${companyPhone}` : "",
      ].filter(Boolean);
      companyContactLines.forEach((line, index) => {
        text(line, headerTextX, contactStartY + index * 9, { size: 7.5, color: grey });
      });
      if (vatEnabled && companyTrn) {
        const trnY = contactStartY + companyContactLines.length * 9 + 5;
        doc.setFillColor(243, 244, 246);
        doc.roundedRect(headerTextX, trnY - 11, 146, 16, 3, 3, "F");
        text(`TRN: ${companyTrn}`, headerTextX + 6, trnY, { size: 7.5, font: "courier", color: [55, 65, 81] });
      }

      text(vatEnabled ? "TAX INVOICE" : "INVOICE", pageW - margin, 52, { size: 19, style: "bold", color: navy, align: "right" });
      text("Original Document", pageW - margin, 67, { size: 8, color: grey, align: "right" });
      const metaX = pageW - margin - 150;
      [
        ["Invoice No", invoiceNo],
        ["Date", invoiceDate],
      ].forEach(([label, value], index) => {
        const y = 86 + index * 15;
        text(label, metaX, y, { size: 9, color: grey, align: "right" });
        text(value, metaX + 16, y, { size: 9, font: "courier" });
      });
      text("Status", metaX, 116, { size: 9, color: grey, align: "right" });
      doc.setFillColor(...statusColors.fill);
      doc.roundedRect(metaX + 16, 104, 90, 17, 8, 8, "F");
      text(invoiceStatus, metaX + 61, 116, { size: 8, style: "bold", color: statusColors.text, align: "center" });

      doc.setDrawColor(...navy);
      doc.setLineWidth(1.4);
      doc.line(margin, 124, pageW - margin, 124);

      const blockY = 136;
      const blockW = (pageW - margin * 2 - 16) / 2;
      const drawInfoBlock = (x: number, title: string, main: string, lines: Array<[string, string]>, plate?: string) => {
        doc.setFillColor(...lightGrey);
        doc.setDrawColor(...borderGrey);
        doc.roundedRect(x, blockY, blockW, 76, 6, 6, "FD");
        text(title.toUpperCase(), x + 12, blockY + 16, { size: 7, style: "bold", color: [156, 163, 175] });
        text(main, x + 12, blockY + 33, { size: 10.5, style: "bold" });
        lines.forEach(([key, value], index) => {
          text(key, x + 12, blockY + 48 + index * 11, { size: 7.5, color: [156, 163, 175] });
          text(value || "-", x + 66, blockY + 48 + index * 11, { size: 7.5, color: [75, 85, 99] });
        });
        if (plate) {
          doc.setFillColor(229, 231, 235);
          doc.roundedRect(x + 12, blockY + 55, 82, 16, 3, 3, "F");
          text(plate, x + 18, blockY + 66, { size: 8.5, font: "courier", style: "bold", color: navy });
        }
      };
      drawInfoBlock(margin, "Invoice To", client?.full_name || "-", [
        ["Phone", client?.phone || "-"],
        ["Nationality", client?.nationality || "-"],
      ]);
      drawInfoBlock(
        margin + blockW + 16,
        "Vehicle",
        [vehicle?.make, vehicle?.model].filter(Boolean).join(" ") || "-",
        [["Year", `${vehicle?.year ?? "-"}${vehicle?.color ? ` - ${vehicle.color}` : ""}`]],
        vehicle?.plate_number || vehicle?.plate || "-",
      );

      doc.setFillColor(...navy);
      doc.roundedRect(margin, 224, pageW - margin * 2, 40, 6, 6, "F");
      text("RENTAL PERIOD", margin + 16, 241, { size: 7.5, color: [156, 163, 175], style: "bold" });
      text(`${formatDate(contract.start_date)} -> ${formatDate(contract.end_date)}`, margin + 16, 257, {
        size: 9.5,
        font: "courier",
        color: [255, 255, 255],
      });
      text(String(rentalDays), pageW - margin - 20, 248, {
        size: 18,
        font: "courier",
        style: "bold",
        color: [255, 255, 255],
        align: "right",
      });
      text("days", pageW - margin - 20, 261, { size: 7.5, color: [156, 163, 175], align: "right" });

      autoTable(doc, {
        startY: 286,
        head: [vatEnabled ? ["#", "Description", "Qty", "Amount", vatLabel, "Total"] : ["#", "Description", "Qty", "Amount", "Total"]],
        body: rows,
        theme: "plain",
        margin: { left: margin, right: margin },
        styles: {
          font: "helvetica",
          fontSize: 8.5,
          cellPadding: { top: 5, right: 8, bottom: 5, left: 8 },
          lineColor: borderGrey,
          lineWidth: 0.5,
          valign: "top",
        },
        headStyles: {
          fillColor: navy,
          textColor: [255, 255, 255],
          fontStyle: "bold",
          fontSize: 8,
        },
        columnStyles: {
          0: { cellWidth: 30, textColor: [156, 163, 175], font: "courier" },
          1: { cellWidth: vatEnabled ? 205 : 275 },
          2: { cellWidth: 70, halign: "right", font: "courier" },
          3: { cellWidth: 80, halign: "right", font: "courier" },
          4: { cellWidth: vatEnabled ? 70 : 85, halign: "right", font: "courier" },
          5: { cellWidth: 85, halign: "right", font: "courier" },
        },
        didParseCell: (data) => {
          if (data.section === "body" && data.row.index % 2 === 1) {
            data.cell.styles.fillColor = lightGrey;
          }
        },
      });

      const tableEndY = ((doc as any).lastAutoTable?.finalY ?? 410) + 8;
      doc.setDrawColor(...borderGrey);
      doc.line(margin, tableEndY, pageW - margin, tableEndY);
      const totalsX = pageW - margin - 250;
      const totalsRows: Array<[string, string, "normal" | "total" | "deposit" | "paid" | "remaining"]> = [
        ["Subtotal", aed(subtotal), "normal"],
        ...(vatEnabled ? [["Tax", aed(taxTotal), "normal"] as [string, string, "normal"]] : []),
        ["Invoice Amount", aed(invoiceAmount), "total"],
        ["Security Deposit (tracked separately)", aed(Number(contract.deposit_amount) || 0), "deposit"],
        ["Paid Amount", `- ${aed(paidAmount)}`, "paid"],
        ["Remaining Balance", aed(remainingBalance), "remaining"],
      ];
      let y = tableEndY + 14;
      totalsRows.forEach(([label, value, kind]) => {
        if (kind === "total" || kind === "remaining") {
          doc.setDrawColor(kind === "remaining" ? 220 : 17, kind === "remaining" ? 38 : 24, kind === "remaining" ? 38 : 39);
          doc.setLineWidth(1.2);
          doc.line(totalsX, y - 10, pageW - margin, y - 10);
        }
        const color =
          kind === "paid"
            ? [22, 163, 74]
            : kind === "remaining"
              ? [220, 38, 38]
              : kind === "deposit"
                ? [156, 163, 175]
                : [107, 114, 128];
        text(label, totalsX, y, {
          size: kind === "total" ? 10.5 : kind === "remaining" ? 9.5 : 8.5,
          style: kind === "total" || kind === "remaining" ? "bold" : "normal",
          color,
        });
        text(value, pageW - margin, y, {
          size: kind === "total" ? 10.5 : kind === "remaining" ? 9.5 : 8.5,
          style: kind === "total" || kind === "remaining" || kind === "paid" ? "bold" : "normal",
          font: "courier",
          color,
          align: "right",
        });
        y += kind === "total" ? 20 : 15;
      });

      let bankBottomY = y;
      if (bankRows.length > 0) {
        const bankY = y + 4;
        const bankW = pageW - margin * 2;
        const labelW = 100;
        const valueX = margin + 12 + labelW;
        const valueW = bankW - labelW - 24;
        const wrappedBankRows = bankRows.map(([label, value]) => ({
          label,
          lines: doc.splitTextToSize(value, valueW) as string[],
        }));
        const bankH = 24 + wrappedBankRows.reduce((height, row) => height + Math.max(13, row.lines.length * 10), 0);
        doc.setDrawColor(...borderGrey);
        doc.roundedRect(margin, bankY - 14, bankW, bankH, 6, 6);
        text("BANK DETAILS", margin + 12, bankY + 2, { size: 7, color: [156, 163, 175], style: "bold" });
        let bankRowY = bankY + 17;
        wrappedBankRows.forEach(({ label, lines }) => {
          text(label, margin + 12, bankRowY, { size: 7.5, color: [107, 114, 128] });
          lines.forEach((line, lineIndex) => {
            text(line, valueX, bankRowY + lineIndex * 10, {
              size: 7.5,
              font: label === "IBAN" ? "courier" : "helvetica",
              color: [17, 24, 39],
            });
          });
          bankRowY += Math.max(13, lines.length * 10);
        });
        bankBottomY = bankY - 14 + bankH;
      }

      const sigY = Math.max(y + 12, bankBottomY + 14, 568);
      doc.setDrawColor(...borderGrey);
      doc.line(margin, sigY - 14, pageW - margin, sigY - 14);
      const sigW = (pageW - margin * 2 - 24) / 3;
      ["Receiver Signature", "Manager Signature", "Company Stamp"].forEach((label, index) => {
        const x = margin + index * (sigW + 12);
        doc.setDrawColor(209, 213, 219);
        doc.setLineDashPattern([3, 3], 0);
        doc.roundedRect(x, sigY, sigW, 56, 5, 5);
        doc.setLineDashPattern([], 0);
        if (label === "Company Stamp" && stampImage) {
          const stampW = Math.min(90, sigW - 18);
          drawImageFit(stampImage, x + (sigW - stampW) / 2, sigY + 4, stampW, 48);
        }
        text(label.toUpperCase(), x + sigW / 2, sigY + 72, {
          size: 7,
          color: [156, 163, 175],
          style: "bold",
          align: "center",
        });
      });

      const remarksY = sigY + 84;
      doc.setDrawColor(...borderGrey);
      doc.roundedRect(margin, remarksY, pageW - margin * 2, 38, 6, 6);
      text("REMARKS", margin + 12, remarksY + 15, { size: 7, color: [156, 163, 175], style: "bold" });
      text("Notes or comments...", margin + 12, remarksY + 29, { size: 8, color: [209, 213, 219], style: "normal" });

      doc.save(`Invoice-${contract.id}.pdf`);
      toast.success("Invoice downloaded");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to generate invoice");
    } finally {
      setGeneratingInvoice(false);
    }
  };

  const handleMarkDepositReturned = async (amount: number) => {
    if (!contract) return;

    const returnedDate = getTodayDateInput();
    const returnNote = [
      DEPOSIT_RETURN_PREFIX,
      "Status: Returned",
      `Returned amount: ${fmtAed(amount)}`,
      `Returned date: ${formatDate(returnedDate)}`,
    ].join(" | ");
    const updatedNotes = [contract.notes?.trim(), returnNote].filter(Boolean).join("\n");

    setMarkingDepositReturned(true);
    const { error } = await (supabase as any)
      .from("contracts")
      .update({
        notes: updatedNotes,
        deposit_returned: amount,
        deposit_status: "returned",
        deposit_return_date: returnedDate,
        deposit_forfeited: 0,
      })
      .eq("id", contract.id);

    if (error) {
      setMarkingDepositReturned(false);
      toast.error("Failed to mark deposit as returned");
      return;
    }

    setContract({ ...contract, notes: updatedNotes });
    setNotesDraft(updatedNotes);
    setMarkingDepositReturned(false);
    toast.success("Deposit marked as returned");
    await fetchData();
  };

  const handleMarkDepositPartiallyReturned = async (amount: number) => {
    if (!contract) return;

    const depositAmount = Math.max(0, Number(contract.deposit_amount) || 0);
    const returnedAmount = Math.min(depositAmount, Math.max(0, Number(amount) || 0));
    const forfeitedAmount = Math.max(0, depositAmount - returnedAmount);
    const returnedDate = getTodayDateInput();
    const returnNote = [
      DEPOSIT_RETURN_PREFIX,
      "Status: Partial return",
      `Returned amount: ${fmtAed(returnedAmount)}`,
      `Forfeited amount: ${fmtAed(forfeitedAmount)}`,
      `Returned date: ${formatDate(returnedDate)}`,
    ].join(" | ");
    const updatedNotes = [contract.notes?.trim(), returnNote].filter(Boolean).join("\n");

    setMarkingDepositReturned(true);
    const { error } = await (supabase as any)
      .from("contracts")
      .update({
        notes: updatedNotes,
        deposit_returned: returnedAmount,
        deposit_status: "partial",
        deposit_return_date: returnedDate,
        deposit_forfeited: forfeitedAmount,
      })
      .eq("id", contract.id);

    if (error) {
      setMarkingDepositReturned(false);
      toast.error("Failed to record partial deposit return");
      return;
    }

    setContract({ ...contract, notes: updatedNotes });
    setNotesDraft(updatedNotes);
    setMarkingDepositReturned(false);
    toast.success("Partial deposit return recorded");
    await fetchData();
  };

  const handleMarkDepositForfeited = async () => {
    if (!contract) return;

    const depositAmount = Math.max(0, Number(contract.deposit_amount) || 0);
    const returnedDate = getTodayDateInput();
    const returnNote = [
      DEPOSIT_RETURN_PREFIX,
      "Status: Forfeited",
      `Returned amount: ${fmtAed(0)}`,
      `Forfeited amount: ${fmtAed(depositAmount)}`,
      `Returned date: ${formatDate(returnedDate)}`,
    ].join(" | ");
    const updatedNotes = [contract.notes?.trim(), returnNote].filter(Boolean).join("\n");

    setMarkingDepositReturned(true);
    const { error } = await (supabase as any)
      .from("contracts")
      .update({
        notes: updatedNotes,
        deposit_returned: 0,
        deposit_status: "forfeited",
        deposit_return_date: returnedDate,
        deposit_forfeited: depositAmount,
      })
      .eq("id", contract.id);

    if (error) {
      setMarkingDepositReturned(false);
      toast.error("Failed to forfeit deposit");
      return;
    }

    setContract({ ...contract, notes: updatedNotes });
    setNotesDraft(updatedNotes);
    setMarkingDepositReturned(false);
    toast.success("Deposit forfeited");
    await fetchData();
  };

  const openExtendModal = () => {
    if (!contract) return;
    setExtendEndDate("");
    setExtendAmount("");
    setExtendError("");
    setShowExtendModal(true);
  };

  const handleExtendContract = async () => {
    if (!contract) return;
    setExtendError("");

    if (!extendEndDate) {
      setExtendError("Select a new end date.");
      return;
    }

    const extensionStart = getLatestRentalPeriodEnd(contract, contractFees);

    if (extendEndDate <= extensionStart) {
      setExtendError("New end date must be later than the current end date.");
      return;
    }

    const extensionAmount = Number(extendAmount);
    if (!Number.isFinite(extensionAmount) || extensionAmount <= 0) {
      setExtendError("Enter a valid extension amount.");
      return;
    }

    setIsExtending(true);
    const extensionEnd = extendEndDate;
    const newEndTime = formatTimeForDb(contract.end_time);

    let overlap = null;
    try {
      overlap = await findVehicleContractOverlap(supabase, {
        carId: contract.car_id,
        startDate: extensionStart,
        startTime: contract.start_time,
        endDate: extensionEnd,
        endTime: newEndTime,
        excludeContractId: contract.id,
        operation: "contract-extension",
      });
    } catch (error) {
      setIsExtending(false);
      const message = error instanceof Error ? error.message : "Could not check vehicle availability. Try again.";
      setExtendError(message);
      return;
    }

    if (overlap) {
      setIsExtending(false);
      setExtendError(formatContractOverlapMessage(overlap));
      return;
    }

    const { data: existingExtension, error: existingExtensionError } = await (supabase as any)
      .from("contract_fees")
      .select("id")
      .eq("contract_id", contract.id)
      .eq("extension_start", extensionStart)
      .eq("extension_end", extensionEnd)
      .maybeSingle();

    if (existingExtensionError) {
      setIsExtending(false);
      const message = "Could not verify existing extension periods. Try again.";
      setExtendError(message);
      toast.error(message);
      return;
    }

    if (existingExtension?.id) {
      setIsExtending(false);
      toast.info("This extension period already exists");
      setShowExtendModal(false);
      setExtendEndDate("");
      setExtendAmount("");
      await fetchContractFees();
      return;
    }

    const { data: userData } = await supabase.auth.getUser();
    const userId = userData?.user?.id;
    if (!userId) {
      setIsExtending(false);
      setExtendError("Could not confirm current user. Try again.");
      return;
    }

    const nextTotalAmount = Math.round((Number(contract.total_amount) + extensionAmount) * 100) / 100;
    const { error: contractEndDateError } = await supabase
      .from("contracts")
      .update({ end_date: extensionEnd, total_amount: nextTotalAmount } as never)
      .eq("id", contract.id);

    if (contractEndDateError) {
      setIsExtending(false);
      const message = "Could not update the contract end date.";
      setExtendError(message);
      toast.error(message);
      return;
    }

    const { error: feeError } = await (supabase as any)
      .from("contract_fees")
      .insert({
        contract_id: contract.id,
        category: RENTAL_EXTENSION_CATEGORY,
        label: buildRentalExtensionLabel(extensionStart, extensionEnd),
        amount: extensionAmount,
        extension_start: extensionStart,
        extension_end: extensionEnd,
        owner_id: userId,
      });

    if (feeError) {
      console.error("Failed to insert extension history", feeError);
      toast.warning("Contract extended, but extension history was not saved");
    }

    setIsExtending(false);

    toast.success("Contract extended");
    setShowExtendModal(false);
    setExtendEndDate("");
    setExtendAmount("");
    await fetchData();
    await fetchContractFees();
    setFeeRefreshKey((key) => key + 1);
  };

  const buildDepositPaymentAllocations = (amount: number) => {
    let remaining = amount;
    const grouped: Record<AllocationCategory, number> = {
      rental: 0,
      fines: 0,
      salik: 0,
      fees: 0,
    };
    const lines: Record<string, number> = {};

    for (const line of paymentAllocationLines) {
      if (remaining <= 0) break;
      const applied = Math.min(remaining, Number(line.due));
      if (applied <= 0) continue;
      grouped[line.category] += applied;
      lines[line.id] = applied;
      remaining -= applied;
    }

    return { ...grouped, lines, source: "security_deposit" };
  };

  const handleCloseContract = async () => {
    if (!contract) return;

    if (closeFinalMileage.trim() === "") {
      toast.error("Please enter final mileage");
      return;
    }

    const finalMileage = Number(closeFinalMileage);
    if (finalMileage < Number(contract.initial_mileage)) {
      toast.error("Final mileage cannot be lower than initial mileage.");
      return;
    }

    const depositAmount = Math.max(0, Number(contract.deposit_amount) || 0);
    const outstandingBalance = Math.max(0, Number(financialTotals.outstanding) || 0);
    const retainedAmount =
      depositCloseAction === "retain_full"
        ? depositAmount
        : depositCloseAction === "retain_partial"
          ? Number(depositRetainedAmount)
          : 0;
    const appliedAmount =
      depositCloseAction === "apply_to_balance"
        ? Math.min(depositAmount, outstandingBalance)
        : 0;
    const pendingReturnAmount = Math.max(0, depositAmount - retainedAmount - appliedAmount);
    const finalOutstandingAmount = Math.max(0, outstandingBalance - appliedAmount);
    const returnDueDate =
      pendingReturnAmount > 0
        ? depositReturnDueDate || (!depositReturnDueDateEdited ? addDaysToDateInput(closeReturnDate, 15) : null)
        : null;
    const needsRetainReason =
      depositAmount > 0 &&
      (depositCloseAction === "retain_partial" || depositCloseAction === "retain_full");

    if (depositAmount > 0 && depositCloseAction === "apply_to_balance" && appliedAmount <= 0) {
      toast.error("There is no outstanding balance to apply the deposit to.");
      return;
    }

    if (depositAmount > 0 && depositCloseAction === "retain_partial") {
      if (!Number.isFinite(retainedAmount) || retainedAmount <= 0) {
        toast.error("Enter the deposit amount to retain.");
        return;
      }
      if (retainedAmount > depositAmount) {
        toast.error("Retained amount cannot exceed the deposit held.");
        return;
      }
    }

    if (needsRetainReason && depositRetainReason.trim() === "") {
      toast.error("Enter a reason for retaining the deposit.");
      return;
    }

    if (pendingReturnAmount > 0 && !returnDueDate) {
      toast.error("Select a deposit return due date.");
      return;
    }

    setIsClosing(true);
    const mileageRes = await (supabase as any)
      .from("car_maintenance")
      .insert({
        car_id: contract.car_id,
        owner_id: user?.id,
        current_mileage: finalMileage,
        notes: `Contract ${contract.id.slice(0, 8).toUpperCase()} return mileage`,
      });

    if (mileageRes.error) {
      setIsClosing(false);
      toast.error("Failed to close contract");
      return;
    }

    let appliedDepositPaymentId: string | null = null;
    if (appliedAmount > 0) {
      const { data: depositPaymentData, error: depositPaymentError } = await supabase
        .from("payments")
        .insert({
          contract_id: contract.id,
          client_id: contract.client_id,
          amount: appliedAmount,
          method: "Security Deposit",
          payment_date: getTodayDateInput(),
          status: "Paid",
          allocations: buildDepositPaymentAllocations(appliedAmount),
        } as never)
        .select("id")
        .single();

      if (depositPaymentError) {
        setIsClosing(false);
        toast.error("Failed to apply security deposit to balance");
        return;
      }
      appliedDepositPaymentId = (depositPaymentData as { id?: string } | null)?.id ?? null;
    }

    const actionLabel =
      depositCloseAction === "return_full"
        ? "Schedule full deposit return"
        : depositCloseAction === "apply_to_balance"
          ? "Apply to outstanding balance"
          : depositCloseAction === "retain_partial"
            ? "Retain partial amount"
            : "Retain full deposit";
    const depositStatus =
      depositCloseAction === "retain_full"
        ? "Retained"
        : "Pending Return";
    const depositNote =
      depositAmount > 0
        ? [
            DEPOSIT_RECONCILIATION_PREFIX,
            `Action: ${actionLabel}`,
            `Status: ${depositStatus}`,
            `Deposit held: ${fmtAed(depositAmount)}`,
            `Outstanding at close: ${fmtAed(outstandingBalance)}`,
            `Applied to balance: ${fmtAed(appliedAmount)}`,
            `Retained: ${fmtAed(retainedAmount)}`,
            `Pending return: ${fmtAed(pendingReturnAmount)}`,
            `Return due: ${returnDueDate ? formatDate(returnDueDate) : "No return due"}`,
            `Final outstanding: ${fmtAed(finalOutstandingAmount)}`,
            depositRetainReason.trim() ? `Reason: ${depositRetainReason.trim()}` : null,
            closeReturnDate ? `Closed/returned at: ${closeReturnDate}` : null,
            closeReceivedBy.trim() ? `Received by: ${closeReceivedBy.trim()}` : null,
          ]
            .filter(Boolean)
            .join(" | ")
        : null;
    const updatedNotes = depositNote
      ? [contract.notes?.trim(), depositNote].filter(Boolean).join("\n")
      : contract.notes ?? null;

    const [contractRes, vehicleRes] = await Promise.all([
      supabase
        .from("contracts")
        .update({ status: "Closed", notes: updatedNotes } as never)
        .eq("id", contract.id),
      supabase
        .from("cars")
        .update({ status: closeVehicleStatus } as never)
        .eq("id", contract.car_id),
    ]);
    setIsClosing(false);
    if (contractRes.error || vehicleRes.error) {
      if (appliedDepositPaymentId) {
        await supabase.from("payments").delete().eq("id", appliedDepositPaymentId);
      }
      toast.error("Failed to close contract");
      return;
    }

    if (depositAmount > 0) {
      const { error: depositStatusError } = await (supabase as any)
        .from("contracts")
        .update({ deposit_status: depositStatus })
        .eq("id", contract.id);

      if (depositStatusError) {
        console.info("Deposit status column is not available; reconciliation was saved in contract notes.");
      }
    }

    toast.success("Contract closed");
    navigate("/contracts");
  };

  const handleReopenContract = async () => {
    if (!contract) return;

    setIsReopening(true);
    const { error } = await (supabase as any)
      .from("contracts")
      .update({ status: "Active" })
      .eq("id", contract.id);
    setIsReopening(false);

    if (error) {
      toast.error("Failed to reopen contract");
      return;
    }

    toast.success("Contract reopened");
    setReopenConfirmOpen(false);
    await fetchData();
  };

  const handleDeleteContract = async () => {
    if (!id) return;

    try {
      // 1. Delete related payments
      const { error: payErr } = await supabase
        .from("payments")
        .delete()
        .eq("contract_id", id);
      if (payErr) throw payErr;

      // 2. Delete related contract_vehicles
      const { error: vehErr } = await (supabase as any)
        .from("contract_vehicles")
        .delete()
        .eq("contract_id", id);
      if (vehErr) throw vehErr;

      // 3. Delete the contract itself
      const { error: contractErr } = await supabase
        .from("contracts")
        .delete()
        .eq("id", id);
      if (contractErr) throw contractErr;

      toast.success("Contract deleted");
      navigate("/contracts");
    } catch (error: any) {
      toast.error("Failed to delete contract: " + error.message);
    } finally {
      setDeleteConfirmOpen(false);
    }
  };

  const handleConfirmDeletePayment = async () => {
    if (!contract || !paymentToDelete) return;

    setDeletingPayment(true);
    const { error } = await supabase
      .from("payments")
      .delete()
      .eq("id", paymentToDelete.id);

    if (error) {
      setDeletingPayment(false);
      toast.error("Failed to delete payment");
      return;
    }

    setPayments((prev) => prev.filter((payment) => payment.id !== paymentToDelete.id));

    const { data, error: refetchError } = await supabase
      .from("payments")
      .select("id, payment_date, amount, method, status")
      .eq("contract_id", contract.id)
      .order("payment_date", { ascending: false });

    setDeletingPayment(false);
    if (refetchError) {
      toast.error("Payment deleted, but payments could not refresh");
    } else {
      setPayments(data || []);
      toast.success("Payment deleted");
    }
    setPaymentToDelete(null);
  };

  const handleConfirmDeleteFee = async () => {
    if (!contract || !feeToDelete) return;

    setDeletingFee(true);
    const { data: contractPayments, error: allocationCheckError } = await supabase
      .from("payments")
      .select("allocations")
      .eq("contract_id", contract.id);

    if (allocationCheckError) {
      setDeletingFee(false);
      toast.error("Failed to verify fee allocations");
      return;
    }

    const allocationKey = `fee-${feeToDelete.id}`;
    const hasAllocatedPayment = (contractPayments ?? []).some((payment) => {
      const allocations = readSavedPaymentAllocations(payment.allocations);
      return Number(allocations?.lines?.[allocationKey] ?? 0) > 0;
    });

    if (hasAllocatedPayment) {
      setDeletingFee(false);
      toast.error("This fee has a payment allocated to it and cannot be deleted.");
      return;
    }

    const { error } = await (supabase as any)
      .from("contract_fees")
      .delete()
      .eq("id", feeToDelete.id);

    if (error) {
      setDeletingFee(false);
      toast.error("Failed to delete fee");
      return;
    }

    setContractFees((prev) => prev.filter((fee) => fee.id !== feeToDelete.id));
    await fetchContractFees();
    setDeletingFee(false);
    toast.success("Fee deleted");
    setFeeToDelete(null);
  };

  const syncContractEndDateWithFees = async (nextFees: ContractFeeRow[]) => {
    if (!contract) return;

    const nextEffectiveEndDate = getLatestRentalPeriodEnd(contract, nextFees);
    if (nextEffectiveEndDate === contract.end_date) return;

    const { error } = await supabase
      .from("contracts")
      .update({ end_date: nextEffectiveEndDate } as never)
      .eq("id", contract.id);

    if (error) {
      throw error;
    }

    setContract((current) =>
      current ? { ...current, end_date: nextEffectiveEndDate } : current,
    );
  };

  const openAmountEditDialog = (target: AmountEditTarget) => {
    const targetPaymentMethod =
      target.type === "payment" && target.payment.method === "Bank Transfer"
        ? "Transfer"
        : target.type === "payment" && ["Cash", "Card", "Transfer"].includes(target.payment.method)
          ? (target.payment.method as PaymentMethod)
          : "Cash";
    const savedPaymentAllocations =
      target.type === "payment" ? readSavedPaymentAllocations(target.payment.allocations) : null;
    const savedLineAllocations =
      savedPaymentAllocations?.lines && Object.keys(savedPaymentAllocations.lines).length > 0
        ? savedPaymentAllocations.lines
        : {};

    setAmountEditTarget(target);
    setAmountEditValue(String(target.amount));
    setAmountEditPaymentMethod(targetPaymentMethod);
    setAmountEditAllocations(target.type === "payment" ? savedLineAllocations : {});
    setAmountEditAllocationError("");
    setAmountEditExtensionEndDate(
      target.type === "fee" && isStructuredRentalExtensionFee(target.fee)
        ? target.fee.extension_end ?? ""
        : "",
    );
  };

  const closeAmountEditDialog = () => {
    if (savingAmountEdit) return;
    setAmountEditTarget(null);
    setAmountEditValue("");
    setAmountEditPaymentMethod("Cash");
    setAmountEditAllocations({});
    setAmountEditAllocationError("");
    setAmountEditExtensionEndDate("");
  };

  const handleSaveAmountEdit = async () => {
    if (!contract || !amountEditTarget) return;

    const amount = Number(amountEditValue);
    if (!Number.isFinite(amount) || amount < 0) {
      toast.error("Enter a valid AED amount");
      return;
    }

    const nextAmount = Math.round(amount * 100) / 100;
    setSavingAmountEdit(true);

    if (amountEditTarget.type === "rental") {
      const { error } = await supabase
        .from("contracts")
        .update({ total_amount: nextAmount } as never)
        .eq("id", contract.id);

      if (error) {
        setSavingAmountEdit(false);
        toast.error("Failed to update rental amount");
        return;
      }

      setContract((prev) => (prev ? { ...prev, total_amount: nextAmount } : prev));
      await fetchData();
      setSavingAmountEdit(false);
      setAmountEditTarget(null);
      setAmountEditValue("");
      toast.success("Rental amount updated");
      return;
    }

    if (amountEditTarget.type === "payment") {
      const totalAllocated = Object.values(amountEditAllocations).reduce(
        (sum, value) => sum + (Number(value) || 0),
        0,
      );
      const unallocatedAmount = Math.round((nextAmount - totalAllocated) * 100) / 100;

      if (Math.abs(unallocatedAmount) > 0.01) {
        const message = "Allocate the full payment before saving.";
        setSavingAmountEdit(false);
        setAmountEditAllocationError(message);
        toast.error(message);
        return;
      }

      const groupedAllocations: Record<"rental" | "fines" | "salik" | "fees", number> = {
        rental: 0,
        fines: 0,
        salik: 0,
        fees: 0,
      };
      const lineAllocations: Record<string, number> = {};

      for (const row of amountEditAllocationRows) {
        const value = Math.round((Number(amountEditAllocations[row.id] ?? 0) || 0) * 100) / 100;
        if (value <= 0) continue;
        groupedAllocations[row.category] += value;
        lineAllocations[row.id] = value;
      }

      const nextAllocations = {
        ...groupedAllocations,
        lines: lineAllocations,
      };

      const { error } = await (supabase as any)
        .from("payments")
        .update({
          amount: nextAmount,
          method: amountEditPaymentMethod,
          allocations: nextAllocations,
        })
        .eq("id", amountEditTarget.payment.id);

      if (error) {
        setSavingAmountEdit(false);
        toast.error("Failed to update payment amount");
        return;
      }

      setPayments((prev) =>
        prev.map((payment) =>
          payment.id === amountEditTarget.payment.id
            ? {
                ...payment,
                amount: nextAmount,
                method: amountEditPaymentMethod,
                allocations: nextAllocations,
              }
            : payment,
        ),
      );

      setSavingAmountEdit(false);
      setAmountEditTarget(null);
      setAmountEditValue("");
      setAmountEditPaymentMethod("Cash");
      setAmountEditAllocations({});
      setAmountEditAllocationError("");
      toast.success("Payment updated");
      return;
    }

    if (isStructuredRentalExtensionFee(amountEditTarget.fee)) {
      const extensionStart = amountEditTarget.fee.extension_start;
      if (!extensionStart || !amountEditExtensionEndDate) {
        setSavingAmountEdit(false);
        toast.error("Select an extension end date");
        return;
      }

      if (amountEditExtensionEndDate <= extensionStart) {
        setSavingAmountEdit(false);
        toast.error("End date must be later than the extension start");
        return;
      }

      const nextLabel = buildRentalExtensionLabel(extensionStart, amountEditExtensionEndDate);
      const amountDelta = Math.round((nextAmount - Number(amountEditTarget.fee.amount)) * 100) / 100;
      const nextContractTotal = Math.round((Number(contract.total_amount) + amountDelta) * 100) / 100;
      const { error: contractAmountError } = await supabase
        .from("contracts")
        .update({ total_amount: nextContractTotal } as never)
        .eq("id", contract.id);

      if (contractAmountError) {
        setSavingAmountEdit(false);
        toast.error("Failed to update rental amount");
        return;
      }

      const { error } = await (supabase as any)
        .from("contract_fees")
        .update({
          extension_end: amountEditExtensionEndDate,
          amount: nextAmount,
          label: nextLabel,
        })
        .eq("id", amountEditTarget.fee.id);

      if (error) {
        setSavingAmountEdit(false);
        toast.error("Failed to update extension");
        return;
      }

      const nextFees = contractFees.map((fee) =>
        fee.id === amountEditTarget.fee.id
          ? {
              ...fee,
              amount: nextAmount,
              extension_end: amountEditExtensionEndDate,
              label: nextLabel,
            }
          : fee,
      );

      try {
        await syncContractEndDateWithFees(nextFees);
      } catch {
        setSavingAmountEdit(false);
        toast.error("Extension saved, but contract end date did not sync");
        return;
      }

      setContract((current) =>
        current ? { ...current, total_amount: nextContractTotal } : current,
      );
      setContractFees(nextFees);
      await fetchContractFees();
      setSavingAmountEdit(false);
      setAmountEditTarget(null);
      setAmountEditValue("");
      setAmountEditExtensionEndDate("");
      toast.success("Extension updated");
      return;
    }

    const { error } = await (supabase as any)
      .from("contract_fees")
      .update({ amount: nextAmount })
      .eq("id", amountEditTarget.fee.id);

    if (error) {
      setSavingAmountEdit(false);
      toast.error("Failed to update fee amount");
      return;
    }

    setContractFees((prev) =>
      prev.map((fee) =>
        fee.id === amountEditTarget.fee.id ? { ...fee, amount: nextAmount } : fee,
      ),
    );
    await fetchContractFees();
    setSavingAmountEdit(false);
    setAmountEditTarget(null);
    setAmountEditValue("");
    setAmountEditExtensionEndDate("");
    toast.success("Fee amount updated");
  };

  const openRentalPeriodEditDialog = (fee?: ContractFeeRow) => {
    if (!contract) return;

    if (fee && isStructuredRentalExtensionFee(fee)) {
      const startDate = fee.extension_start ?? contract.end_date;
      const endDate = fee.extension_end ?? contract.end_date;
      const amount = Number(fee.amount);
      setRentalPeriodEditTarget({ type: "extension", startDate, endDate, amount, fee });
      setRentalPeriodEndDate(endDate);
      setRentalPeriodAmount(String(amount));
    } else {
      const amount = Number(contract.total_amount);
      setRentalPeriodEditTarget({
        type: "contract",
        startDate: contract.start_date,
        endDate: contract.end_date,
        amount,
      });
      setRentalPeriodEndDate(contract.end_date);
      setRentalPeriodAmount(String(amount));
    }

    setRentalPeriodEditError("");
  };

  const closeRentalPeriodEditDialog = () => {
    if (savingRentalPeriod) return;
    setRentalPeriodEditTarget(null);
    setRentalPeriodEndDate("");
    setRentalPeriodAmount("");
    setRentalPeriodEditError("");
  };

  const handleSaveRentalPeriod = async () => {
    if (!contract || !rentalPeriodEditTarget) return;

    if (!rentalPeriodEndDate) {
      setRentalPeriodEditError("Select an end date.");
      return;
    }

    if (rentalPeriodEndDate < rentalPeriodEditTarget.startDate) {
      setRentalPeriodEditError("End Date cannot be before Start Date.");
      return;
    }

    const nextAmount = Number(rentalPeriodAmount);
    if (!Number.isFinite(nextAmount) || nextAmount < 0) {
      setRentalPeriodEditError("Amount must be 0 or greater.");
      return;
    }

    setSavingRentalPeriod(true);
    setRentalPeriodEditError("");

    try {
      const conflict = await findVehicleContractOverlap(supabase, {
        carId: contract.car_id,
        startDate:
          rentalPeriodEditTarget.type === "contract"
            ? contract.start_date
            : rentalPeriodEditTarget.startDate,
        startTime: contract.start_time,
        endDate: rentalPeriodEndDate,
        endTime: contract.end_time,
        excludeContractId: contract.id,
        operation: rentalPeriodEditTarget.type === "contract" ? "contract-edit" : "contract-extension",
      });

      if (conflict) {
        setSavingRentalPeriod(false);
        setRentalPeriodEditError(formatContractOverlapMessage(conflict));
        return;
      }
    } catch (error) {
      setSavingRentalPeriod(false);
      setRentalPeriodEditError(
        error instanceof Error ? error.message : "Could not check vehicle availability.",
      );
      return;
    }

    if (rentalPeriodEditTarget.type === "contract") {
      const { error } = await supabase
        .from("contracts")
        .update({
          end_date: rentalPeriodEndDate,
          total_amount: nextAmount,
        } as never)
        .eq("id", contract.id);

      if (error) {
        setSavingRentalPeriod(false);
        setRentalPeriodEditError("Failed to update rental period.");
        return;
      }

      setContract((current) =>
        current
          ? { ...current, end_date: rentalPeriodEndDate, total_amount: nextAmount }
          : current,
      );
      await fetchData();
    } else {
      const nextLabel = buildRentalExtensionLabel(
        rentalPeriodEditTarget.startDate,
        rentalPeriodEndDate,
      );
      const amountDelta = Math.round((nextAmount - Number(rentalPeriodEditTarget.amount)) * 100) / 100;
      const nextContractTotal = Math.round((Number(contract.total_amount) + amountDelta) * 100) / 100;
      const { error: contractAmountError } = await supabase
        .from("contracts")
        .update({ total_amount: nextContractTotal } as never)
        .eq("id", contract.id);

      if (contractAmountError) {
        setSavingRentalPeriod(false);
        setRentalPeriodEditError("Failed to update rental amount.");
        return;
      }

      const { error } = await (supabase as any)
        .from("contract_fees")
        .update({
          extension_end: rentalPeriodEndDate,
          amount: nextAmount,
          label: nextLabel,
        })
        .eq("id", rentalPeriodEditTarget.fee.id);

      if (error) {
        setSavingRentalPeriod(false);
        setRentalPeriodEditError("Failed to update rental period.");
        return;
      }

      const nextFees = contractFees.map((fee) =>
        fee.id === rentalPeriodEditTarget.fee.id
          ? {
              ...fee,
              extension_end: rentalPeriodEndDate,
              amount: nextAmount,
              label: nextLabel,
            }
          : fee,
      );

      try {
        await syncContractEndDateWithFees(nextFees);
      } catch {
        setSavingRentalPeriod(false);
        setRentalPeriodEditError("Rental period saved, but contract end date did not sync.");
        return;
      }

      setContract((current) =>
        current ? { ...current, total_amount: nextContractTotal } : current,
      );
      await fetchContractFees();
    }

    setSavingRentalPeriod(false);
    setRentalPeriodEditTarget(null);
    setRentalPeriodEndDate("");
    setRentalPeriodAmount("");
    toast.success("Rental period updated");
  };

  const handleOpenEditModal = async () => {
    if (!contract) return;
    setEditStartDate(contract.start_date);
    setEditStartTime(formatTimeDisplay(contract.start_time));
    setEditEndDate(contract.end_date);
    setEditEndTime(formatTimeDisplay(contract.end_time));
    setEditCarId(contract.car_id);
    const { data } = await supabase
      .from("cars")
      .select("id, plate, make, model, year, status")
      .eq("status", "Available")
      .order("plate");
    setAvailableCars((data as AvailableCarRow[]) ?? []);
    setShowEditModal(true);
  };

  const handleSaveEdit = async () => {
    if (!contract) return;
    setIsSavingEdit(true);
    try {
      const conflict = await findVehicleContractOverlap(supabase, {
        carId: editCarId,
        startDate: editStartDate,
        startTime: editStartTime,
        endDate: editEndDate,
        endTime: editEndTime,
        excludeContractId: contract.id,
        operation: "contract-edit",
      });
      if (conflict) {
        setIsSavingEdit(false);
        toast.error(formatContractOverlapMessage(conflict));
        return;
      }
    } catch (error) {
      setIsSavingEdit(false);
      const message = error instanceof Error ? error.message : "Could not check vehicle availability.";
      toast.error(message);
      return;
    }
    const { error } = await supabase
      .from("contracts")
      .update({
        start_date: editStartDate,
        start_time: formatTimeForDb(editStartTime),
        end_date: editEndDate,
        end_time: formatTimeForDb(editEndTime),
        car_id: editCarId,
      } as never)
      .eq("id", contract.id);
    setIsSavingEdit(false);
    if (error) {
      toast.error("Failed to save changes");
      return;
    }
    toast.success("Contract updated");
    setShowEditModal(false);
    fetchData();
  };

  const handleAddFee = async (fee: AddFeeInlineFee) => {
    if (!contract || !user) return;

    const amount = Number(fee.amount);
    const label = fee.label.trim();
    const note = fee.note.trim();

    if (!label || !Number.isFinite(amount) || amount <= 0) {
      toast.error("Enter a fee label and amount");
      return;
    }

    setSavingFee(true);
    const { error } = await (supabase as any)
      .from("contract_fees")
      .insert({
        contract_id: contract.id,
        category: ADD_FEE_CATEGORY_TO_DB[fee.category],
        label,
        amount,
        note: note || null,
        owner_id: user.id,
      });
    setSavingFee(false);

    if (error) {
      toast.error("Failed to add fee");
      return;
    }

    toast.success("Fee added");
    setShowAddFeeInline(false);
    setFeeRefreshKey((key) => key + 1);
  };

  if (loading) {
    return (
      <DashboardLayout title="Contract">
        <div className="h-24 pt-10 text-center text-sm text-muted-foreground">Loading...</div>
      </DashboardLayout>
    );
  }

  if (!contract) {
    return (
      <DashboardLayout title="Contract not found">
        <div className="rounded-xl border border-dashed border-border bg-card p-10 text-center">
          <p className="text-sm text-muted-foreground">This contract does not exist.</p>
          <Button asChild variant="outline" size="sm" className="mt-4">
            <Link to="/contracts">Back to contracts</Link>
          </Button>
        </div>
      </DashboardLayout>
    );
  }

  const contractNumber = `CTR-${contract.id.slice(0, 8).toUpperCase()}`;
  const isContractClosed = contract.status.toLowerCase() === "closed";
  const canExtendContract = ["active", "expiring soon", "overdue"].includes(contract.status.toLowerCase());
  const InvoiceButton = (
    <Button
      variant="outline"
      size="sm"
      className="h-8 gap-1.5"
      onClick={handleDownloadInvoice}
      disabled={generatingInvoice}
    >
      <Download className="h-3.5 w-3.5" />
      {generatingInvoice ? "Generating..." : "Invoice"}
    </Button>
  );
  const rentalFeeLines = sortRentalExtensionFees(contractFees);
  const manualFeeLines = contractFees.filter((fee) => !isRentalExtensionFee(fee));
  const contractDueDateLabel = formatDate(effectiveContractEndDate);
  const grossPaymentAllocationLines: ContractPaymentAllocationLine[] = [
    {
      id: `rental-${contract.id}`,
      category: "rental",
      label: "Original Contract",
      due: Number(contract.total_amount),
      dueDate: contract.end_date,
    },
    ...manualFeeLines.map((fee) => ({
      id: `fee-${fee.id}`,
      category: "fees" as const,
      label: fee.label,
      due: Number(fee.amount),
      overdueImmediately: true,
    })),
    ...fines
      .filter((fine) => fine.status !== "Paid")
      .map((fine) => ({
        id: `fine-${fine.id}`,
        category: "fines" as const,
        label: fine.fine_number ? `${fine.fine_type} ${fine.fine_number}` : fine.fine_type,
        due: Number(fine.amount),
        overdueImmediately: true,
      })),
    ...salik
      .filter((charge) => charge.status.toLowerCase() !== "paid")
      .map((charge) => ({
        id: `salik-${charge.id}`,
        category: "salik" as const,
        label: charge.transaction_id ? `Salik ${charge.transaction_id}` : charge.toll_gate ? `Salik ${charge.toll_gate}` : "Salik",
        due: Number(charge.amount),
        overdueImmediately: true,
      })),
  ];
  const paidByLine = new Map(grossPaymentAllocationLines.map((line) => [line.id, 0]));
  const addLinePayment = (lineId: string, amountToAdd: number) => {
    const line = grossPaymentAllocationLines.find((item) => item.id === lineId);
    if (!line || amountToAdd <= 0) return 0;

    const currentPaid = paidByLine.get(lineId) ?? 0;
    const nextPaid = Math.min(line.due, currentPaid + amountToAdd);
    paidByLine.set(lineId, nextPaid);
    return nextPaid - currentPaid;
  };
  const distributePayment = (lines: PaymentAllocationLine[], amountToDistribute: number) => {
    let remaining = amountToDistribute;
    for (const line of lines) {
      if (remaining <= 0) break;
      remaining -= addLinePayment(line.id, remaining);
    }
    return amountToDistribute - remaining;
  };

  [...payments]
    .filter((payment) => payment.status.toLowerCase() === "paid")
    .sort((a, b) => new Date(a.payment_date).getTime() - new Date(b.payment_date).getTime())
    .forEach((payment) => {
      const savedAllocations = readSavedPaymentAllocations(payment.allocations);
      let applied = 0;

      if (savedAllocations?.lines && Object.keys(savedAllocations.lines).length > 0) {
        Object.entries(savedAllocations.lines).forEach(([lineId, value]) => {
          const numericValue = Number(value);
          applied += addLinePayment(lineId, numericValue);
        });
      } else if (savedAllocations) {
        (["rental", "fees", "fines", "salik"] as const).forEach((category) => {
          const value = Number(savedAllocations[category] ?? 0);
          if (value <= 0) return;
          distributePayment(
            grossPaymentAllocationLines.filter((line) => line.category === category),
            value,
          );
          applied += value;
        });
      }

      const remainder = Number(payment.amount) - applied;
      if (remainder > 0.01) {
        distributePayment(grossPaymentAllocationLines, remainder);
      }
    });
  const paymentAllocationLines = grossPaymentAllocationLines
    .map((line) => ({
      ...line,
      due: Math.max(0, Number(line.due) - (paidByLine.get(line.id) ?? 0)),
    }))
    .filter((line) => line.due > 0.01);
  const amountEditSavedAllocations =
    amountEditTarget?.type === "payment"
      ? readSavedPaymentAllocations(amountEditTarget.payment.allocations)?.lines ?? {}
      : {};
  const amountEditAllocationRows: ContractPaymentAllocationLine[] =
    amountEditTarget?.type === "payment"
      ? grossPaymentAllocationLines
          .map((line) => {
            const currentAllocation = Number(amountEditSavedAllocations[line.id] ?? 0);
            const unpaidLine = paymentAllocationLines.find((item) => item.id === line.id);
            return {
              ...line,
              due: Math.max(0, Number(unpaidLine?.due ?? 0) + currentAllocation),
            };
          })
          .filter((line) => line.due > 0.01 || Number(amountEditAllocations[line.id] ?? 0) > 0)
      : [];
  const amountEditPaymentAmount = Number(amountEditValue);
  const amountEditTotalAllocated = Object.values(amountEditAllocations).reduce(
    (sum, value) => sum + (Number(value) || 0),
    0,
  );
  const amountEditUnallocatedAmount =
    Number.isFinite(amountEditPaymentAmount)
      ? Math.round((amountEditPaymentAmount - amountEditTotalAllocated) * 100) / 100
      : 0;
  const todayDate = getTodayDateInput();
  // contract_fees, fines, and Salik do not carry due dates, so non-rental unpaid charges are treated as overdue once attached.
  const overdueBalance = paymentAllocationLines.reduce((sum, line) => {
    const isPastRentalPeriod = line.category === "rental" && Boolean(line.dueDate) && line.dueDate < todayDate;
    const isImmediateCharge = line.category !== "rental" && line.overdueImmediately;
    return isPastRentalPeriod || isImmediateCharge ? sum + Number(line.due) : sum;
  }, 0);
  const allocationOutstandingBalance = paymentAllocationLines.reduce((sum, line) => sum + Number(line.due), 0);
  const financialTotals: ContractFinancialTotals = {
    ...totals,
    outstanding: Math.max(0, allocationOutstandingBalance),
    overdue: Math.min(allocationOutstandingBalance, Math.max(0, overdueBalance)),
  };
  const isOverdue = financialTotals.overdue > 0 && contract.status !== "Cancelled";
  const closeDepositAmount = Math.max(0, Number(contract.deposit_amount) || 0);
  const closeOutstandingBalance = Math.max(0, Number(financialTotals.outstanding) || 0);
  const closeDepositApplyAmount =
    depositCloseAction === "apply_to_balance"
      ? Math.min(closeDepositAmount, closeOutstandingBalance)
      : 0;
  const closeDepositRetainedAmount =
    depositCloseAction === "retain_full"
      ? closeDepositAmount
      : depositCloseAction === "retain_partial"
        ? Math.min(closeDepositAmount, Math.max(0, Number(depositRetainedAmount) || 0))
        : 0;
  const closeDepositReturnAmount = Math.max(
    0,
    closeDepositAmount - closeDepositApplyAmount - closeDepositRetainedAmount,
  );
  const closeDepositReturnDueDate =
    closeDepositReturnAmount > 0
      ? depositReturnDueDate || (!depositReturnDueDateEdited ? addDaysToDateInput(closeReturnDate, 15) : null)
      : null;
  const closeDepositReturnDueLabel = closeDepositReturnDueDate
    ? formatDate(closeDepositReturnDueDate)
    : closeDepositReturnAmount > 0
      ? "Select date"
      : "No return due";
  const closeFinalOutstanding = Math.max(0, closeOutstandingBalance - closeDepositApplyAmount);
  const closeRetainedAmountInput = Number(depositRetainedAmount);
  const isCloseRetainPartialValid =
    depositCloseAction !== "retain_partial" ||
    (Number.isFinite(closeRetainedAmountInput) &&
      closeRetainedAmountInput > 0 &&
      closeRetainedAmountInput <= closeDepositAmount &&
      depositRetainReason.trim().length > 0);
  const isCloseRetainFullValid =
    depositCloseAction !== "retain_full" || depositRetainReason.trim().length > 0;
  const isCloseDepositReturnDateValid =
    closeDepositReturnAmount <= 0 || Boolean(closeDepositReturnDueDate);
  const isCloseConfirmDisabled =
    isClosing ||
    !isCloseRetainPartialValid ||
    !isCloseRetainFullValid ||
    !isCloseDepositReturnDateValid;
  const latestRentalPeriodEnd = getLatestRentalPeriodEnd(contract, rentalFeeLines);
  const extensionMinDate = addDaysToDateInput(latestRentalPeriodEnd, 1);
  const extensionPreviewDays = extendEndDate ? diffDays(latestRentalPeriodEnd, extendEndDate) : 0;
  const extensionPreviewCharge = Number(extendAmount);
  const extensionConfirmLabel = extendEndDate
    ? `Confirm Extension → ${formatDate(extendEndDate)}`
    : "Confirm Extension";
  const amountEditIsExtension =
    amountEditTarget?.type === "fee" && isStructuredRentalExtensionFee(amountEditTarget.fee);
  const amountEditExtensionPeriod =
    amountEditTarget?.type === "fee"
      ? parseRentalExtensionPeriod(amountEditTarget.fee.label)
      : null;
  const amountEditExtensionStartDate =
    amountEditTarget?.type === "fee"
      ? amountEditTarget.fee.extension_start ?? amountEditExtensionPeriod?.periodStart ?? null
      : null;
  const amountEditExtensionEndDisplay =
    amountEditExtensionEndDate ||
    (amountEditTarget?.type === "fee"
      ? amountEditTarget.fee.extension_end ?? amountEditExtensionPeriod?.periodEnd ?? null
      : null);

  return (
    <DashboardLayout title={contractNumber} subtitle="Contract details">
      <div className="w-[calc(100%+2rem)] max-w-[100vw] min-w-0 -mx-4 -my-6 md:w-[calc(100%+4rem)] md:-mx-8 md:-my-8">
        {/* Sticky header */}
        <div className="sticky top-0 z-20 max-w-full min-w-0 border-b border-border bg-background md:bg-background/95 md:backdrop-blur md:supports-[backdrop-filter]:bg-background/80">
          <div className="flex max-w-full min-w-0 flex-wrap items-center justify-between gap-3 px-4 py-3 md:px-8">
            <div className="flex min-w-0 items-center gap-3">
              <Button asChild variant="ghost" size="sm" className="h-8 -ml-2 gap-1.5 text-muted-foreground">
                <Link to="/contracts">
                  <ArrowLeft className="h-3.5 w-3.5" />
                  Contracts
                </Link>
              </Button>
              <div className="h-5 w-px bg-border" />
              <div className="flex min-w-0 items-center gap-2.5">
                <h2 className="min-w-0 truncate font-mono text-sm font-semibold tracking-tight text-foreground">
                  {contractNumber}
                </h2>
                <span
                  className={cn(
                    "inline-flex items-center rounded-md border px-2 py-0.5 text-[11px] font-medium",
                    statusBadgeClass(contract.status),
                  )}
                >
                  {contract.status}
                </span>
              </div>
            </div>

            <div className="flex max-w-full min-w-0 items-center gap-4">
              <div className="flex max-w-full flex-nowrap items-center gap-1.5">
                <Button
                  variant="outline"
                  size="sm"
                  className="h-8 gap-1.5"
                  onClick={async () => {
                    try {
                      await generateContractPdf(contract);
                      toast.success("Contract PDF downloaded");
                    } catch (error) {
                      toast.error("Failed to generate PDF");
                      console.error(error);
                    }
                  }}
                >
                  <FileDown className="h-3.5 w-3.5" />
                  Contract
                </Button>
                {canExtendContract && (
                  <Button variant="outline" size="sm" className="h-8 gap-1.5" onClick={openExtendModal}>
                    <CalendarPlus className="h-3.5 w-3.5" />
                    Extend
                  </Button>
                )}
                {!isContractClosed && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 gap-1.5"
                    onClick={() => {
                      const defaultCloseDate = getCurrentDateTimeInput();
                      setCloseReturnDate(defaultCloseDate);
                      setCloseReceivedBy("");
                      setCloseFinalMileage("");
                      setCloseVehicleStatus("Available");
                      setDepositCloseAction("return_full");
                      setDepositRetainedAmount("");
                      setDepositRetainReason("");
                      setDepositReturnDueDate(addDaysToDateInput(defaultCloseDate, 15));
                      setDepositReturnDueDateEdited(false);
                      setShowCloseModal(true);
                    }}
                  >
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    Close
                  </Button>
                )}
                {isContractClosed && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 gap-1.5"
                    onClick={() => setReopenConfirmOpen(true)}
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    Reopen Contract
                  </Button>
                )}
                <Button size="sm" className="h-8 gap-1.5" onClick={handleOpenEditModal}>
                  <Pencil className="h-3.5 w-3.5" />
                  Edit
                </Button>
              </div>
            </div>
          </div>
        </div>

        <Tabs defaultValue="overview" className="w-full max-w-full min-w-0 px-4 py-4 md:px-8">
          <div className="w-full max-w-full min-w-0 overflow-x-auto pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            <TabsList className="h-9 w-max min-w-max bg-muted/60 p-0.5">
              <TabsTrigger value="overview" className="h-8 gap-1.5 px-3 text-xs">
                <LayoutGrid className="h-3.5 w-3.5" />
                Overview
              </TabsTrigger>
              <TabsTrigger value="financials" className="h-8 gap-1.5 px-3 text-xs">
                <Wallet className="h-3.5 w-3.5" />
                Financials
                {ledger.length > 0 && (
                  <span className="ml-1 rounded bg-background/70 px-1.5 text-[10px] tabular-nums">
                    {ledger.length}
                  </span>
                )}
              </TabsTrigger>
              <TabsTrigger value="documents" className="h-8 gap-1.5 px-3 text-xs">
                <FileText className="h-3.5 w-3.5" />
                Documents
              </TabsTrigger>
              <TabsTrigger value="inspection" className="h-8 gap-1.5 px-3 text-xs">
                <Camera className="h-3.5 w-3.5" />
                Inspection
              </TabsTrigger>
              <TabsTrigger value="timeline" className="h-8 gap-1.5 px-3 text-xs">
                <Clock className="h-3.5 w-3.5" />
                Timeline & Notes
              </TabsTrigger>
            </TabsList>
          </div>

          {/* OVERVIEW */}
          <TabsContent value="overview" className="mt-4 max-w-full min-w-0 space-y-3">
            <div className="flex flex-wrap gap-2">
              {canExtendContract && (
                <Button size="sm" variant="outline" className="h-8 gap-1.5" onClick={openExtendModal}>
                  <CalendarPlus className="h-3.5 w-3.5" />
                  Extend Rental
                </Button>
              )}
              <Button size="sm" variant="outline" className="h-8 gap-1.5" disabled>
                <Pencil className="h-3.5 w-3.5" />
                Edit Details
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="h-8 gap-1.5"
                onClick={() => setReplaceVehicleOpen(true)}
                disabled={contract.status === "Closed"}
              >
                Replace Vehicle
              </Button>
            </div>

            <div className="grid gap-3 lg:grid-cols-3">
              <Panel
                title="Client"
                action={
                  contract.client_id && (
                    <Button asChild variant="ghost" size="sm" className="h-6 px-2 text-[11px]">
                      <Link to={`/clients/${contract.client_id}`}>View profile →</Link>
                    </Button>
                  )
                }
              >
                <div className="grid grid-cols-2 gap-x-4">
                  <Field label="Full Name" value={contract.clients?.full_name} />
                  <Field label="Type" value={contract.clients?.client_type} />
                  <Field label="Phone" value={contract.clients?.phone} />
                  <Field label="Email" value={contract.clients?.email} />
                  <Field label="Nationality" value={contract.clients?.nationality} />
                  <Field
                    label={contract.clients?.client_type === "Tourist" ? "Passport" : "Emirates ID"}
                    value={
                      contract.clients?.client_type === "Tourist"
                        ? contract.clients?.passport_number
                        : contract.clients?.emirates_id
                    }
                  />
                </div>
              </Panel>

              <Panel title="Vehicle">
                <div className="grid grid-cols-2 gap-x-4">
                  <Field label="Plate" value={contract.cars?.plate} />
                  <Field label="Year" value={contract.cars?.year} />
                  <Field
                    label="Make / Model"
                    value={contract.cars ? `${contract.cars.make} ${contract.cars.model}` : "—"}
                  />
                  <Field label="Fuel Level" value={contract.fuel_level} />
                  <Field
                    label="Initial Mileage"
                    value={`${contract.initial_mileage.toLocaleString()} km`}
                  />
                </div>
                {replacementCount > 0 && (
                  <button
                    onClick={() => setHistoryOpen(true)}
                    className="w-full flex items-center justify-between mt-3 pt-3 border-t border-white/[0.07] text-left hover:bg-white/[0.02] rounded px-0.5 transition-colors"
                  >
                    <span className="flex items-center gap-2 text-[12px] font-medium text-white/50">
                      <History className="w-4 h-4" />
                      Vehicle replacements
                      <span className="font-mono text-[10px] text-blue-400 bg-blue-400/10 border border-blue-400/20 rounded px-1.5 py-0.5">{replacementCount}</span>
                    </span>
                    <span className="text-white/30 text-xs">→</span>
                  </button>
                )}
              </Panel>

              <Panel title="Rental Period">
                <div className="grid grid-cols-2 gap-x-4">
                  <Field label="Start Date" value={formatDateWithOptionalTime(contract.start_date, contract.start_time)} />
                  <Field label="End Date" value={formatDateWithOptionalTime(effectiveContractEndDate, contract.end_time)} />
                  <Field label="Total Days" value={days} />
                  <Field label="Rate Type" value={contract.rate_type} />
                  <Field label={`${contract.rate_type} Rate`} value={fmtAed(contract.rate_amount)} />
                  <Field label="Deposit" value={fmtAed(contract.deposit_amount)} />
                </div>
              </Panel>
            </div>

            <Panel title="Financial Snapshot" icon={Wallet}>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                <div className="rounded-md border border-border bg-muted/30 px-3 py-2">
                  <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
                    Total Charges
                  </div>
                  <div className="mt-0.5 text-base font-semibold tabular-nums text-foreground">
                    {fmtAed(financialTotals.charges - Number(contract.deposit_amount))}
                  </div>
                </div>
                <div className="rounded-md border border-border bg-muted/30 px-3 py-2">
                  <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
                    Paid
                  </div>
                  <div className="mt-0.5 text-base font-semibold tabular-nums text-tint-green-foreground">
                    {fmtAed(financialTotals.credits)}
                  </div>
                </div>
                <div className="rounded-md border border-border bg-muted/30 px-3 py-2">
                  <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
                    Deposit Held
                  </div>
                  <div className="mt-0.5 text-base font-semibold tabular-nums text-foreground">
                    {fmtAed(contract.deposit_amount)}
                  </div>
                </div>
                <div
                  className={cn(
                    "rounded-md border px-3 py-2",
                    isOverdue ? "border-tint-rose-foreground/30 bg-tint-rose" : "border-border bg-muted/30",
                  )}
                >
                  <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
                    Outstanding
                  </div>
                  <div
                    className={cn(
                      "mt-0.5 text-base font-semibold tabular-nums",
                      isOverdue ? "text-tint-rose-foreground" : "text-foreground",
                    )}
                  >
                    {fmtAed(financialTotals.outstanding)}
                  </div>
                </div>
              </div>
            </Panel>
          </TabsContent>

          {/* FINANCIALS */}
          <TabsContent value="financials" className="mt-4 max-w-full min-w-0 space-y-3">
            <section className="min-w-0 rounded-lg border border-border bg-card">
              <header className="flex min-w-0 items-center justify-between gap-3 border-b border-border px-4 py-2.5">
                <h3 className="min-w-0 truncate text-xs font-semibold uppercase tracking-wide text-foreground">
                  Client Statement
                </h3>
                {InvoiceButton}
              </header>
            </section>
            <FinancialsPanel
              contract={contract}
              days={days}
              payments={payments}
              fines={fines}
              salik={salik}
              chargeImportEvidence={chargeImportEvidence}
              contractFees={contractFees}
              unpaidAllocationLines={paymentAllocationLines}
              totals={financialTotals}
              addFeeInlineOpen={showAddFeeInline}
              savingFee={savingFee}
              onAddFee={() => setShowAddFeeInline((open) => !open)}
              onCancelAddFee={() => setShowAddFeeInline(false)}
              onSaveFee={(fee) => void handleAddFee(fee)}
              onAddPayment={() => setShowPaymentModal(true)}
              onEditRentalPeriod={openRentalPeriodEditDialog}
              onEditPaymentAmount={(payment) =>
                openAmountEditDialog({
                  type: "payment",
                  label: `Payment (${payment.method})`,
                  amount: Number(payment.amount),
                  payment,
                })
              }
              onEditFeeAmount={(fee) =>
                openAmountEditDialog({
                  type: "fee",
                  label: `${fee.label} fee`,
                  amount: Number(fee.amount),
                  fee,
                })
              }
              onDeletePayment={setPaymentToDelete}
              onDeleteFee={setFeeToDelete}
              onMarkDepositReturned={handleMarkDepositReturned}
              onMarkDepositPartiallyReturned={handleMarkDepositPartiallyReturned}
              onMarkDepositForfeited={handleMarkDepositForfeited}
              markingDepositReturned={markingDepositReturned}
              onInlinePaymentRecorded={handlePaymentRecorded}
            />
            <RecordPaymentModal
              open={showPaymentModal}
              onClose={() => setShowPaymentModal(false)}
              onSuccess={handlePaymentRecorded}
              contractId={contract.id}
              balanceDue={financialTotals.outstanding}
              clientId={contract.client_id}
              allocationLines={paymentAllocationLines}
              ledgerEntries={ledger.map(e => ({
                id: e.id,
                description: e.description,
                amount: e.debit - e.credit,
                status: e.status,
                type: e.type
              }))}
            />
          </TabsContent>

          {/* DOCUMENTS */}
          <TabsContent value="documents" className="mt-4 max-w-full min-w-0">
            <Panel title="Documents" icon={FileText}>
              {contractDocuments.length === 0 ? (
                <div className="flex min-h-[140px] items-center justify-center rounded-md border border-dashed border-border bg-muted/20 px-4 py-8 text-center">
                  <p className="text-sm font-medium text-muted-foreground">No documents saved yet.</p>
                </div>
              ) : (
                <div className="divide-y divide-border overflow-hidden rounded-md border border-border">
                  {contractDocuments.map((document) => (
                    <div
                      key={document.id}
                      className="flex flex-col gap-3 bg-background px-3 py-3 sm:flex-row sm:items-center sm:justify-between"
                    >
                      <div className="min-w-0 space-y-1">
                        <div className="truncate text-sm font-medium text-foreground">
                          {document.title}
                        </div>
                        <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-muted-foreground">
                          <span>{getContractDocumentLabel(document.document_type)}</span>
                          <span aria-hidden>-</span>
                          <span className="font-mono tabular-nums">
                            {formatDubaiDateTime(document.created_at)}
                          </span>
                        </div>
                      </div>
                      <div className="flex shrink-0 flex-wrap items-center gap-2">
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          className="h-8 gap-1.5 text-xs"
                          onClick={() => openContractDocument(document)}
                        >
                          <Download className="h-3.5 w-3.5" />
                          Download
                        </Button>
                        {document.public_url && (
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            className="h-8 gap-1.5 text-xs"
                            onClick={() => shareContractDocumentOnWhatsApp(document)}
                          >
                            <ExternalLink className="h-3.5 w-3.5" />
                            WhatsApp
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Panel>
          </TabsContent>

          {/* INSPECTION */}
          <TabsContent value="inspection" className="mt-4 max-w-full min-w-0">
            <InspectionPhotosTab contractId={contract.id} uploadedBy={user?.id ?? null} />
          </TabsContent>

          {/* TIMELINE & NOTES */}
          <TabsContent value="timeline" className="mt-4 grid max-w-full min-w-0 gap-3 lg:grid-cols-2">
            <Panel
              title="Notes"
              icon={Pencil}
              action={
                editingNotes ? (
                  <div className="flex items-center gap-1.5">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-7 gap-1 text-xs"
                      onClick={() => {
                        setNotesDraft(contract.notes ?? "");
                        setEditingNotes(false);
                      }}
                    >
                      <X className="h-3.5 w-3.5" />
                      Cancel
                    </Button>
                    <Button
                      size="sm"
                      className="h-7 gap-1 text-xs"
                      onClick={saveNotes}
                      disabled={savingNotes}
                    >
                      <Save className="h-3.5 w-3.5" />
                      {savingNotes ? "Saving..." : "Save"}
                    </Button>
                  </div>
                ) : (
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 gap-1 text-xs"
                    onClick={() => setEditingNotes(true)}
                  >
                    <Pencil className="h-3.5 w-3.5" />
                    Edit
                  </Button>
                )
              }
            >
              {editingNotes ? (
                <Textarea
                  rows={6}
                  value={notesDraft}
                  onChange={(e) => setNotesDraft(e.target.value)}
                  placeholder="Add notes about this contract..."
                  className="text-sm"
                />
              ) : contract.notes ? (
                <p className="whitespace-pre-wrap text-sm text-foreground">{contract.notes}</p>
              ) : (
                <EmptyState
                  icon={Pencil}
                  title="No notes yet"
                  description="Click Edit to add internal notes about this contract."
                />
              )}
            </Panel>

            <Panel title="Activity Timeline" icon={Clock}>
              <ol className="relative space-y-3 border-l border-border pl-4">
                <li className="relative">
                  <span className="absolute -left-[21px] top-1 h-2.5 w-2.5 rounded-full border-2 border-background bg-tint-blue-foreground" />
                  <div className="text-xs text-muted-foreground">{formatDate(contract.created_at)}</div>
                  <div className="text-sm font-medium text-foreground">Contract created</div>
                </li>
                <li className="relative">
                  <span className="absolute -left-[21px] top-1 h-2.5 w-2.5 rounded-full border-2 border-background bg-tint-green-foreground" />
                  <div className="text-xs text-muted-foreground">{formatDate(contract.start_date)}</div>
                  <div className="text-sm font-medium text-foreground">Rental period started</div>
                </li>
                <li className="relative">
                  <span
                    className={cn(
                      "absolute -left-[21px] top-1 h-2.5 w-2.5 rounded-full border-2 border-background",
                      new Date(effectiveContractEndDate) < new Date()
                        ? "bg-muted-foreground"
                        : "bg-tint-amber-foreground",
                    )}
                  />
                  <div className="text-xs text-muted-foreground">{formatDate(effectiveContractEndDate)}</div>
                  <div className="text-sm font-medium text-foreground">
                    {new Date(effectiveContractEndDate) < new Date() ? "Rental ended" : "Scheduled end date"}
                  </div>
                </li>
                {isOverdue && (
                  <li className="relative">
                    <span className="absolute -left-[21px] top-1 h-2.5 w-2.5 rounded-full border-2 border-background bg-tint-rose-foreground" />
                    <div className="text-xs text-muted-foreground">Now</div>
                    <div className="flex items-center gap-1.5 text-sm font-medium text-tint-rose-foreground">
                      <AlertCircle className="h-3.5 w-3.5" />
                      Outstanding balance: {fmtAed(financialTotals.outstanding)}
                    </div>
                  </li>
                )}
              </ol>
            </Panel>
          </TabsContent>
        </Tabs>
        <div className="mt-8 pb-8 text-right">
          <Button
            variant="ghost"
            size="sm"
            className="text-red-500 hover:bg-red-500/10 hover:text-red-600 gap-1.5"
            onClick={() => setDeleteConfirmOpen(true)}
          >
            <Trash2 className="h-3.5 w-3.5" />
            Delete Contract
          </Button>
        </div>
      </div>

      <AlertDialog open={reopenConfirmOpen} onOpenChange={setReopenConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Reopen this contract?</AlertDialogTitle>
            <AlertDialogDescription>
              Reopen this contract? The status will be changed back to Active.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isReopening}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleReopenContract} disabled={isReopening}>
              Confirm
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this contract?</AlertDialogTitle>
            <AlertDialogDescription>
              Delete this contract and all its payments? This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteContract}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete Contract
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog
        open={amountEditTarget !== null}
        onOpenChange={(open) => {
          if (!open) closeAmountEditDialog();
        }}
      >
        <DialogContent className={cn("sm:max-w-[420px]", amountEditTarget?.type === "payment" && "sm:max-w-[560px]")}>
          <DialogHeader>
            <DialogTitle>
              {amountEditTarget?.type === "payment"
                ? "Edit Payment"
                : amountEditIsExtension
                  ? "Edit Rental Period"
                  : "Edit Amount"}
            </DialogTitle>
            <DialogDescription className="text-xs">
              {amountEditIsExtension ? (
                <>
                  <span className="block">Rental Period</span>
                  <span className="mt-1 block font-mono text-[11px]">
                    {formatDate(amountEditExtensionStartDate)} → {formatDate(amountEditExtensionEndDisplay)}
                  </span>
                </>
              ) : amountEditTarget?.type === "payment" ? (
                amountEditTarget.label
              ) : (
                amountEditTarget?.label ?? "Financial entry"
              )}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            {amountEditIsExtension && (
              <div className="space-y-2">
                <Label htmlFor="edit-extension-end-date" className="text-xs">
                  End date
                </Label>
                <Input
                  id="edit-extension-end-date"
                  type="date"
                  value={amountEditExtensionEndDate}
                  onChange={(event) => setAmountEditExtensionEndDate(event.target.value)}
                />
              </div>
            )}
            {amountEditTarget?.type === "payment" ? (
              <>
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="edit-financial-amount" className="text-xs">
                      Amount (AED)
                    </Label>
                    <Input
                      id="edit-financial-amount"
                      type="number"
                      min="0"
                      step="0.01"
                      inputMode="decimal"
                      value={amountEditValue}
                      onChange={(event) => {
                        setAmountEditValue(event.target.value);
                        setAmountEditAllocationError("");
                      }}
                      className="font-mono tabular-nums"
                      placeholder="0.00"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs">Payment Method</Label>
                    <Select
                      value={amountEditPaymentMethod}
                      onValueChange={(value) => setAmountEditPaymentMethod(value as PaymentMethod)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Cash">Cash</SelectItem>
                        <SelectItem value="Card">Card</SelectItem>
                        <SelectItem value="Transfer">Transfer</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-3">
                    <Label className="text-xs uppercase tracking-wide text-muted-foreground">
                      Allocate Payment
                    </Label>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="h-7 px-2 text-[10px] uppercase"
                      onClick={() => {
                        let remaining = Number(amountEditValue) || 0;
                        const nextAllocations: Record<string, number> = {};
                        for (const row of amountEditAllocationRows) {
                          if (remaining <= 0) break;
                          const value = Math.min(remaining, Number(row.due));
                          if (value > 0) nextAllocations[row.id] = Math.round(value * 100) / 100;
                          remaining -= value;
                        }
                        setAmountEditAllocations(nextAllocations);
                        setAmountEditAllocationError("");
                      }}
                    >
                      Fill all unpaid
                    </Button>
                  </div>

                  <div className="max-h-[240px] space-y-3 overflow-y-auto rounded-md border border-border p-3 [scrollbar-width:thin]">
                    {amountEditAllocationRows.length === 0 ? (
                      <div className="py-6 text-center text-xs text-muted-foreground">
                        No unpaid allocation lines
                      </div>
                    ) : (
                      amountEditAllocationRows.map((row) => (
                        <div key={row.id} className="flex items-center gap-3 text-xs">
                          <div className="min-w-0 flex-1">
                            <p className="truncate font-medium text-foreground">{row.label}</p>
                            <p className="font-mono text-[10px] tabular-nums text-muted-foreground">
                              Due: {fmtAed(row.due)}
                            </p>
                          </div>
                          <div className="relative w-32 shrink-0">
                            <span className="absolute left-2 top-1/2 -translate-y-1/2 text-[10px] text-muted-foreground">
                              AED
                            </span>
                            <Input
                              type="number"
                              min="0"
                              step="0.01"
                              inputMode="decimal"
                              max={row.due}
                              value={amountEditAllocations[row.id] ?? ""}
                              onChange={(event) => {
                                const value = Math.min(
                                  Number(row.due),
                                  Math.max(0, Number(event.target.value) || 0),
                                );
                                setAmountEditAllocations((prev) => ({
                                  ...prev,
                                  [row.id]: Math.round(value * 100) / 100,
                                }));
                                setAmountEditAllocationError("");
                              }}
                              className="h-8 pl-8 text-right font-mono text-xs tabular-nums"
                              placeholder="0.00"
                            />
                          </div>
                        </div>
                      ))
                    )}
                  </div>

                  <div className="flex items-center justify-between gap-3 px-1 text-xs">
                    <span
                      className={cn(
                        "font-semibold",
                        Math.abs(amountEditUnallocatedAmount) > 0.01
                          ? "text-destructive"
                          : "text-tint-green-foreground",
                      )}
                    >
                      Unallocated: <span className="font-mono tabular-nums">{fmtAed(amountEditUnallocatedAmount)}</span>
                    </span>
                    {amountEditAllocationError ? (
                      <span className="text-right text-destructive">{amountEditAllocationError}</span>
                    ) : null}
                  </div>
                </div>
              </>
            ) : (
              <div className="space-y-2">
                <Label htmlFor="edit-financial-amount" className="text-xs">
                  {amountEditIsExtension ? "Amount" : "Amount (AED)"}
                </Label>
                <Input
                  id="edit-financial-amount"
                  type="number"
                  min="0"
                  step="0.01"
                  inputMode="decimal"
                  value={amountEditValue}
                  onChange={(event) => setAmountEditValue(event.target.value)}
                  className="font-mono tabular-nums"
                  placeholder="0.00"
                />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={closeAmountEditDialog}
              disabled={savingAmountEdit}
            >
              Cancel
            </Button>
            <Button
              type="button"
              onClick={handleSaveAmountEdit}
              disabled={savingAmountEdit}
            >
              {savingAmountEdit ? "Saving..." : "Save"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog
        open={rentalPeriodEditTarget !== null}
        onOpenChange={(open) => {
          if (!open) closeRentalPeriodEditDialog();
        }}
      >
        <DialogContent className="sm:max-w-[420px]">
          <DialogHeader>
            <DialogTitle>Edit Rental Period</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div className="grid gap-1.5">
              <Label htmlFor="rental-period-start-date" className="text-xs">
                Start Date
              </Label>
              <Input
                id="rental-period-start-date"
                type="date"
                value={rentalPeriodEditTarget?.startDate ?? ""}
                readOnly
                aria-readonly="true"
                className="bg-muted/40"
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="rental-period-end-date" className="text-xs">
                End Date
              </Label>
              <Input
                id="rental-period-end-date"
                type="date"
                min={rentalPeriodEditTarget?.startDate}
                value={rentalPeriodEndDate}
                onChange={(event) => {
                  setRentalPeriodEndDate(event.target.value);
                  setRentalPeriodEditError("");
                }}
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="rental-period-amount" className="text-xs">
                Amount (AED)
              </Label>
              <Input
                id="rental-period-amount"
                type="number"
                min="0"
                step="0.01"
                inputMode="decimal"
                value={rentalPeriodAmount}
                onChange={(event) => {
                  setRentalPeriodAmount(event.target.value);
                  setRentalPeriodEditError("");
                }}
                className="font-mono tabular-nums"
              />
            </div>
            {rentalPeriodEditError ? (
              <p className="text-xs text-destructive">{rentalPeriodEditError}</p>
            ) : null}
          </div>
          <DialogFooter className="flex-col-reverse gap-2 sm:flex-row">
            <Button
              type="button"
              variant="outline"
              onClick={closeRentalPeriodEditDialog}
              disabled={savingRentalPeriod}
              className="w-full sm:w-auto"
            >
              Cancel
            </Button>
            <Button
              type="button"
              onClick={handleSaveRentalPeriod}
              disabled={savingRentalPeriod || !rentalPeriodEndDate || rentalPeriodAmount === ""}
              className="w-full sm:w-auto"
            >
              {savingRentalPeriod ? "Saving..." : "Save"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={paymentToDelete !== null}
        onOpenChange={(open) => {
          if (!open && !deletingPayment) setPaymentToDelete(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Payment</AlertDialogTitle>
            <AlertDialogDescription>
              Delete payment of {paymentToDelete ? fmtAed(Number(paymentToDelete.amount)) : "AED 0"}? This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deletingPayment}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              disabled={deletingPayment}
              onClick={(event) => {
                event.preventDefault();
                void handleConfirmDeletePayment();
              }}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deletingPayment ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog
        open={feeToDelete !== null}
        onOpenChange={(open) => {
          if (!open && !deletingFee) setFeeToDelete(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Fee</AlertDialogTitle>
            <AlertDialogDescription>
              Delete this fee? This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deletingFee}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              disabled={deletingFee}
              onClick={(event) => {
                event.preventDefault();
                void handleConfirmDeleteFee();
              }}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deletingFee ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={showEditModal} onOpenChange={(v) => !v && setShowEditModal(false)}>
        <DialogContent className="max-h-[calc(100dvh-1rem)] overflow-y-auto overscroll-contain sm:max-w-[440px]">
          <DialogHeader>
            <DialogTitle>Edit Contract</DialogTitle>
            <DialogDescription className="text-xs">
              {contract ? `CTR-${contract.id.slice(0, 8).toUpperCase()}` : ""}
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-2">
            <div className="grid gap-1.5">
              <Label className="text-xs uppercase tracking-wide text-muted-foreground">
                Start Date
              </Label>
              <input
                type="date"
                value={editStartDate}
                onChange={(e) => setEditStartDate(e.target.value)}
                className="flex h-11 w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 md:h-9 md:text-sm"
              />
            </div>

            <div className="grid gap-1.5">
              <Label className="text-xs uppercase tracking-wide text-muted-foreground">
                Start Time
              </Label>
              <input
                type="time"
                value={editStartTime}
                onChange={(e) => setEditStartTime(e.target.value)}
                className="flex h-11 w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 md:h-9 md:text-sm"
              />
            </div>

          </div>

          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setShowEditModal(false)}>
              Cancel
            </Button>
            <Button
              disabled={isSavingEdit || !editStartDate || !editStartTime || !editEndDate || !editEndTime || !editCarId}
              onClick={handleSaveEdit}
            >
              {isSavingEdit ? "Saving…" : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showExtendModal} onOpenChange={(v) => !v && setShowExtendModal(false)}>
        <DialogContent className="max-h-[calc(100dvh-1rem)] overflow-y-auto overscroll-contain sm:max-w-[440px]">
          <DialogHeader>
            <DialogTitle>Extend Contract</DialogTitle>
            <DialogDescription className="text-xs">
              {contract ? `CTR-${contract.id.slice(0, 8).toUpperCase()}` : ""}
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-2">
            <div className="grid gap-1.5">
              <Label className="text-xs uppercase tracking-wide text-muted-foreground">
                New end date
              </Label>
              <input
                type="date"
                min={extensionMinDate}
                value={extendEndDate}
                onChange={(e) => {
                  setExtendEndDate(e.target.value);
                  setExtendError("");
                }}
                className="flex h-11 w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 md:h-10 md:text-sm"
              />
            </div>

            <div className="grid gap-1.5">
              <Label htmlFor="extension-amount" className="text-xs uppercase tracking-wide text-muted-foreground">
                Amount (AED)
              </Label>
              <Input
                id="extension-amount"
                type="number"
                min="0"
                step="0.01"
                inputMode="decimal"
                value={extendAmount}
                onChange={(e) => {
                  setExtendAmount(e.target.value);
                  setExtendError("");
                }}
                className="font-mono tabular-nums"
                placeholder="0.00"
              />
            </div>

            <div className="rounded-md border border-border bg-muted/30 px-3 py-2 text-xs">
              <div className="grid gap-1 font-mono text-muted-foreground">
                <div className="flex items-center justify-between gap-3">
                  <span>Period</span>
                  <span className="text-right text-foreground">
                    {formatDate(latestRentalPeriodEnd)} {"->"} {extendEndDate ? formatDate(extendEndDate) : "Select date"}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-3">
                  <span>Days</span>
                  <span className="text-right text-foreground">{extensionPreviewDays}</span>
                </div>
                <div className="flex items-center justify-between gap-3">
                  <span>Charge</span>
                  <span className="text-right text-foreground">
                    {Number.isFinite(extensionPreviewCharge) ? fmtAed(extensionPreviewCharge) : "AED 0"}
                  </span>
                </div>
              </div>
            </div>

            {extendError && (
              <div className="rounded-md border border-tint-rose-foreground/20 bg-tint-rose px-3 py-2 text-xs text-tint-rose-foreground">
                {extendError}
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowExtendModal(false)}>
              Cancel
            </Button>
            <Button
              disabled={isExtending || !extendEndDate || !extendAmount}
              onClick={handleExtendContract}
            >
              {isExtending ? "Saving..." : extensionConfirmLabel}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showCloseModal} onOpenChange={(v) => !v && setShowCloseModal(false)}>
        <DialogContent className="max-h-[calc(100dvh-1rem)] overflow-y-auto overscroll-contain pb-[max(1.5rem,env(safe-area-inset-bottom))] sm:max-w-[520px]">
          <DialogHeader>
            <DialogTitle>Close Contract</DialogTitle>
            <DialogDescription className="text-xs">
              {contract ? `CTR-${contract.id.slice(0, 8).toUpperCase()}` : ""} · This action cannot be undone.
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-2">
            <div className="grid gap-1.5">
              <Label className="text-xs uppercase tracking-wide text-muted-foreground">
                Return Date &amp; Time
              </Label>
              <input
                type="datetime-local"
                value={closeReturnDate}
                onChange={(e) => {
                  const nextCloseDate = e.target.value;
                  setCloseReturnDate(nextCloseDate);
                  if (!depositReturnDueDateEdited) {
                    setDepositReturnDueDate(addDaysToDateInput(nextCloseDate, 15));
                  }
                }}
                className="flex h-11 w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 md:h-9 md:text-sm"
              />
              <p className="text-xs text-muted-foreground">
                Contract due date: {contractDueDateLabel}
              </p>
            </div>

            <div className="grid gap-1.5">
              <Label className="text-xs uppercase tracking-wide text-muted-foreground">
                Received By
              </Label>
              <Input
                placeholder="Staff name"
                value={closeReceivedBy}
                onChange={(e) => setCloseReceivedBy(e.target.value)}
              />
            </div>

            <div className="grid gap-1.5">
              <Label className="text-xs uppercase tracking-wide text-muted-foreground">
                Final Mileage (km)
              </Label>
              <Input
                type="number"
                min={contract?.initial_mileage ?? 0}
                value={closeFinalMileage}
                onChange={(e) => setCloseFinalMileage(e.target.value)}
              />
            </div>

            <div className="grid gap-1.5">
              <Label className="text-xs uppercase tracking-wide text-muted-foreground">
                Vehicle Status After Return
              </Label>
              <Select value={closeVehicleStatus} onValueChange={setCloseVehicleStatus}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Available">Available</SelectItem>
                  <SelectItem value="Under Service">Under Service</SelectItem>
                  <SelectItem value="Reserved">Reserved</SelectItem>
                  <SelectItem value="Unavailable">Unavailable</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {closeDepositAmount > 0 && (() => {
              const profileDepositReturnDays = Number(
                (contract as any).profiles?.deposit_return_days ??
                  (contract as any).profile?.deposit_return_days ??
                  (contract as any).deposit_return_days,
              );
              const depositReturnDays = Number.isFinite(profileDepositReturnDays)
                ? Math.max(0, profileDepositReturnDays)
                : 15;
              const calculatedDepositReturnDueDate = addDaysToDateInput(closeReturnDate, depositReturnDays);
              const calculatedDepositReturnDueLabel = formatDate(calculatedDepositReturnDueDate);

              return (
              <div className="overflow-hidden rounded-[10px] border border-[#1e2535] bg-[#1a2030]">
                <div className="flex items-center justify-between border-b border-[#1e2535] px-[14px] py-[12px]">
                  <div className="text-[10px] font-semibold uppercase tracking-widest text-[#4a5568]">
                    SECURITY DEPOSIT
                  </div>
                  <div className="font-['IBM_Plex_Mono'] text-[14px] font-semibold text-[#f0f4ff]">
                    {fmtAed(closeDepositAmount)}
                  </div>
                </div>

                <div className="flex items-center justify-between border-b border-[#1e2535] px-[14px] py-[10px] text-[12px]">
                  <div className="flex items-center gap-2">
                    <span className="text-[#6b7a99]">Held</span>
                    <span className="font-['IBM_Plex_Mono'] font-medium text-[#c8d3e8]">
                      {fmtAed(closeDepositAmount)}
                    </span>
                  </div>
                  <span className="text-[#1e2535]">│</span>
                  <div className="flex items-center gap-2">
                    <span className="text-[#6b7a99]">Outstanding balance</span>
                    <span className="font-['IBM_Plex_Mono'] font-medium text-[#f97316]">
                      {fmtAed(closeOutstandingBalance)}
                    </span>
                  </div>
                </div>

                <div className="flex flex-col gap-[8px] px-[14px] pb-[8px] pt-[12px]">
                  <div className="mb-[4px] text-[10px] font-semibold tracking-widest text-[#4a5568]">
                    WHAT TO DO WITH DEPOSIT?
                  </div>
                  <button
                    type="button"
                    onClick={() => setDepositCloseAction("return_full")}
                    className={cn(
                      "flex cursor-pointer items-center justify-between rounded-[8px] border-[1.5px] p-[11px]",
                      depositCloseAction === "return_full"
                        ? "border-[#3b6fff] bg-[rgba(59,111,255,0.08)]"
                        : "border-[#1e2535] bg-[#161b27]",
                    )}
                  >
                    <div className="flex items-center gap-3 text-left">
                      <span
                        className={cn(
                          "flex h-4 w-4 shrink-0 items-center justify-center rounded-full border",
                          depositCloseAction === "return_full" ? "border-[#3b6fff]" : "border-[#1e2535]",
                        )}
                      >
                        {depositCloseAction === "return_full" && (
                          <span className="h-[7px] w-[7px] rounded-full bg-[#3b6fff]" />
                        )}
                      </span>
                      <span className="flex flex-col">
                        <span className="text-[13px] font-medium text-[#c8d3e8]">
                          Hold deposit
                        </span>
                        <span className="text-[11px] text-[#4a5568]">
                          Return due in {depositReturnDays} days — {calculatedDepositReturnDueLabel}
                        </span>
                      </span>
                    </div>
                    <span className="font-['IBM_Plex_Mono'] text-[13px] font-semibold text-[#3b6fff]">
                      {fmtAed(closeDepositAmount)}
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setDepositCloseAction("apply_to_balance")}
                    className={cn(
                      "flex cursor-pointer items-center justify-between rounded-[8px] border-[1.5px] p-[11px]",
                      depositCloseAction === "apply_to_balance"
                        ? "border-[#22c55e] bg-[rgba(34,197,94,0.07)]"
                        : "border-[#1e2535] bg-[#161b27]",
                    )}
                  >
                    <div className="flex items-center gap-3 text-left">
                      <span
                        className={cn(
                          "flex h-4 w-4 shrink-0 items-center justify-center rounded-full border",
                          depositCloseAction === "apply_to_balance" ? "border-[#22c55e]" : "border-[#1e2535]",
                        )}
                      >
                        {depositCloseAction === "apply_to_balance" && (
                          <span className="h-[7px] w-[7px] rounded-full bg-[#22c55e]" />
                        )}
                      </span>
                      <span className="flex flex-col">
                        <span className="text-[13px] font-medium text-[#c8d3e8]">
                          Apply to outstanding balance
                        </span>
                        <span className="text-[11px] text-[#4a5568]">
                          Covers {fmtAed(closeOutstandingBalance)} debt, hold remaining{" "}
                          {fmtAed(Math.max(0, closeDepositAmount - closeOutstandingBalance))}
                        </span>
                      </span>
                    </div>
                    <span className="font-['IBM_Plex_Mono'] text-[13px] font-semibold text-[#22c55e]">
                      {fmtAed(closeOutstandingBalance)}
                    </span>
                  </button>
                </div>

                <div className="flex items-center justify-between gap-[10px] px-[14px] pb-[12px]">
                  <Label className="text-[12px] text-[#6b7a99]">Return due date</Label>
                  <div className="rounded-[6px] border border-[#1e2535] bg-[#1a2030] px-[10px] py-[7px] font-['IBM_Plex_Mono'] text-[12px] text-[#c8d3e8]">
                    {calculatedDepositReturnDueLabel}
                  </div>
                </div>

                <details
                  className="group px-[14px] pb-[12px]"
                  defaultOpen={depositCloseAction === "retain_partial" || depositCloseAction === "retain_full"}
                >
                  <summary className="cursor-pointer list-none text-[11px] text-[#4a5568] underline underline-offset-2 [&::-webkit-details-marker]:hidden">
                    ⋯ Retain partial or full deposit
                  </summary>
                  <div className="mt-3 grid gap-2">
                    <button
                      type="button"
                      onClick={() => setDepositCloseAction("retain_partial")}
                      className={cn(
                        "flex min-h-10 cursor-pointer items-center gap-3 rounded-md border px-3 py-2 text-sm",
                        depositCloseAction === "retain_partial"
                          ? "border-[#3b6fff] bg-[rgba(59,111,255,0.08)]"
                          : "border-[#1e2535] bg-[#161b27]",
                      )}
                    >
                      <span
                        className={cn(
                          "flex h-4 w-4 shrink-0 items-center justify-center rounded-full border",
                          depositCloseAction === "retain_partial" ? "border-[#3b6fff]" : "border-[#1e2535]",
                        )}
                      >
                        {depositCloseAction === "retain_partial" && (
                          <span className="h-[7px] w-[7px] rounded-full bg-[#3b6fff]" />
                        )}
                      </span>
                      <span className="flex-1 text-left text-[#c8d3e8]">Retain partial amount</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setDepositCloseAction("retain_full")}
                      className={cn(
                        "flex min-h-10 cursor-pointer items-center gap-3 rounded-md border px-3 py-2 text-sm",
                        depositCloseAction === "retain_full"
                          ? "border-[#3b6fff] bg-[rgba(59,111,255,0.08)]"
                          : "border-[#1e2535] bg-[#161b27]",
                      )}
                    >
                      <span
                        className={cn(
                          "flex h-4 w-4 shrink-0 items-center justify-center rounded-full border",
                          depositCloseAction === "retain_full" ? "border-[#3b6fff]" : "border-[#1e2535]",
                        )}
                      >
                        {depositCloseAction === "retain_full" && (
                          <span className="h-[7px] w-[7px] rounded-full bg-[#3b6fff]" />
                        )}
                      </span>
                      <span className="flex-1 text-left text-[#c8d3e8]">Retain full deposit</span>
                      <span className="font-['IBM_Plex_Mono'] text-xs font-semibold text-[#c8d3e8]">
                        {fmtAed(closeDepositAmount)}
                      </span>
                    </button>

                    {depositCloseAction === "retain_partial" && (
                      <div className="grid gap-1.5">
                        <Label className="text-xs uppercase tracking-wide text-[#4a5568]">
                          Retained Amount
                        </Label>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-[#6b7a99]">
                            AED
                          </span>
                          <Input
                            type="number"
                            min={0}
                            max={closeDepositAmount}
                            value={depositRetainedAmount}
                            onChange={(e) => setDepositRetainedAmount(e.target.value)}
                            className="border-[#1e2535] bg-[#161b27] pl-12 text-[#c8d3e8]"
                            placeholder="0.00"
                          />
                        </div>
                      </div>
                    )}

                    {(depositCloseAction === "retain_partial" || depositCloseAction === "retain_full") && (
                      <div className="grid gap-1.5">
                        <Label className="text-xs uppercase tracking-wide text-[#4a5568]">
                          Retention Reason
                        </Label>
                        <Textarea
                          value={depositRetainReason}
                          onChange={(e) => setDepositRetainReason(e.target.value)}
                          placeholder="Damage, fuel, late return, fines pending..."
                          className="min-h-[72px] border-[#1e2535] bg-[#161b27] text-[#c8d3e8]"
                        />
                      </div>
                    )}
                    {closeDepositReturnAmount > 0 &&
                      (depositCloseAction === "retain_partial" || depositCloseAction === "retain_full") && (
                        <div className="grid gap-1.5">
                          <Label className="text-xs uppercase tracking-wide text-[#4a5568]">
                            Return Due Date
                          </Label>
                          <input
                            type="date"
                            value={depositReturnDueDate}
                            onChange={(e) => {
                              setDepositReturnDueDate(e.target.value);
                              setDepositReturnDueDateEdited(true);
                            }}
                            className="flex h-11 w-full rounded-md border border-[#1e2535] bg-[#161b27] px-3 py-2 font-['IBM_Plex_Mono'] text-base text-[#c8d3e8] ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 md:h-9 md:text-sm"
                          />
                        </div>
                      )}
                  </div>
                </details>
              </div>
              );
            })()}

            <div className="grid gap-1.5 rounded-md border border-border bg-background px-3 py-2 text-xs">
              <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                Close Summary
              </div>
              <div className="flex justify-between gap-3">
                <span className="text-muted-foreground">Outstanding before deposit</span>
                <span className="font-mono font-semibold tabular-nums">
                  {fmtAed(closeOutstandingBalance)}
                </span>
              </div>
              <div className="flex justify-between gap-3">
                <span className="text-muted-foreground">Deposit held</span>
                <span className="font-mono font-semibold tabular-nums">
                  {fmtAed(closeDepositAmount)}
                </span>
              </div>
              <div className="flex justify-between gap-3">
                <span className="text-muted-foreground">Applied to balance</span>
                <span className="font-mono font-semibold tabular-nums">
                  {fmtAed(closeDepositApplyAmount)}
                </span>
              </div>
              <div className="flex justify-between gap-3">
                <span className="text-muted-foreground">Retained</span>
                <span className="font-mono font-semibold tabular-nums">
                  {fmtAed(closeDepositRetainedAmount)}
                </span>
              </div>
              <div className="flex justify-between gap-3">
                <span className="text-muted-foreground">Pending return</span>
                <span className="font-mono font-semibold tabular-nums">
                  {fmtAed(closeDepositReturnAmount)}
                </span>
              </div>
              <div className="flex justify-between gap-3">
                <span className="text-muted-foreground">Return due date</span>
                <span className="font-mono font-semibold tabular-nums">
                  {closeDepositReturnDueLabel}
                </span>
              </div>
              <div className="flex justify-between gap-3">
                <span className="text-muted-foreground">Final outstanding after closing</span>
                <span className="font-mono font-semibold tabular-nums">
                  {fmtAed(closeFinalOutstanding)}
                </span>
              </div>
              <div className="flex justify-between gap-3">
                <span className="text-muted-foreground">Vehicle status after return</span>
                <span className="font-medium text-foreground">{closeVehicleStatus}</span>
              </div>
            </div>
          </div>

          {closeFinalOutstanding > 0 && (
            <div className="rounded-md border border-tint-amber-foreground/25 bg-tint-amber px-3 py-2 text-xs font-medium text-tint-amber-foreground">
              Contract will close with {fmtAed(closeFinalOutstanding)} still outstanding.
            </div>
          )}

          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setShowCloseModal(false)}>
              Cancel
            </Button>
            <Button variant="destructive" disabled={isCloseConfirmDisabled} onClick={handleCloseContract}>
              {isClosing ? "Closing…" : "Confirm Close"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <ReplaceVehicleModal
        contractId={contract.id}
        currentCarId={contract.car_id}
        contractStartDate={contract.start_date}
        isOpen={replaceVehicleOpen}
        onClose={() => setReplaceVehicleOpen(false)}
        onSuccess={() => {
          setReplaceVehicleOpen(false);
          fetchData();
        }}
      />
      <VehicleHistorySheet contractId={contract.id} open={historyOpen} onClose={() => setHistoryOpen(false)} />
    </DashboardLayout>
  );
};

export default ContractDetail;
